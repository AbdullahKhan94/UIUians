package uk.co.senab.photoview.scrollerproxy;

import android.annotation.TargetApi;
import android.content.Context;

@TargetApi(14)
public class IcsScroller extends GingerScroller {
    public IcsScroller(Context context) {
        super(context);
    }

    @Override // uk.co.senab.photoview.scrollerproxy.ScrollerProxy, uk.co.senab.photoview.scrollerproxy.GingerScroller
    public boolean computeScrollOffset() {
        return this.mScroller.computeScrollOffset();
    }
}

package okhttp3.internal.http2;

import java.io.IOException;

public final class ConnectionShutdownException extends IOException {
}

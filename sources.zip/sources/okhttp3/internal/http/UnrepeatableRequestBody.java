package okhttp3.internal.http;

public interface UnrepeatableRequestBody {
}

package io.fabric.sdk.android;

public final class BuildConfig {
    public static final String APPLICATION_ID = "io.fabric.sdk.android";
    public static final String ARTIFACT_ID = "fabric";
    public static final String BUILD_NUMBER = "27";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String DEVELOPER_TOKEN = "470fa2b4ae81cd56ecbcda9735803434cec591fa";
    public static final String FLAVOR = "";
    public static final String GROUP = "io.fabric.sdk.android";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.4.4";
}

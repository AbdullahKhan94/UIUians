package io.fabric.sdk.android.services.events;

public interface EventsStorageListener {
    void onRollOver(String str);
}

package io.fabric.sdk.android.services.concurrency;

public abstract class PriorityRunnable extends PriorityTask implements Runnable {
}

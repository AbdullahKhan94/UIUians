package io.fabric.sdk.android.services.common;

/* access modifiers changed from: package-private */
public interface FirebaseApp {
    boolean isDataCollectionDefaultEnabled();
}

package io.fabric.sdk.android.services.common;

public interface CurrentTimeProvider {
    long getCurrentTimeMillis();
}

package io.fabric.sdk.android.services.settings;

interface AppSpiCall {
    boolean invoke(AppRequestData appRequestData);
}

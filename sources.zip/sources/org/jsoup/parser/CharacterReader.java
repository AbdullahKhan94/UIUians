package org.jsoup.parser;

import java.util.Arrays;
import java.util.Locale;
import org.jsoup.helper.Validate;

/* access modifiers changed from: package-private */
public final class CharacterReader {
    static final char EOF = 65535;
    private static final int maxCacheLen = 12;
    private final char[] input;
    private final int length;
    private int mark = 0;
    private int pos = 0;
    private final String[] stringCache = new String[512];

    CharacterReader(String str) {
        Validate.notNull(str);
        this.input = str.toCharArray();
        this.length = this.input.length;
    }

    /* access modifiers changed from: package-private */
    public int pos() {
        return this.pos;
    }

    /* access modifiers changed from: package-private */
    public boolean isEmpty() {
        return this.pos >= this.length;
    }

    /* access modifiers changed from: package-private */
    public char current() {
        return this.pos >= this.length ? EOF : this.input[this.pos];
    }

    /* access modifiers changed from: package-private */
    public char consume() {
        char c = this.pos >= this.length ? EOF : this.input[this.pos];
        this.pos++;
        return c;
    }

    /* access modifiers changed from: package-private */
    public void unconsume() {
        this.pos--;
    }

    /* access modifiers changed from: package-private */
    public void advance() {
        this.pos++;
    }

    /* access modifiers changed from: package-private */
    public void mark() {
        this.mark = this.pos;
    }

    /* access modifiers changed from: package-private */
    public void rewindToMark() {
        this.pos = this.mark;
    }

    /* access modifiers changed from: package-private */
    public String consumeAsString() {
        char[] cArr = this.input;
        int i = this.pos;
        this.pos = i + 1;
        return new String(cArr, i, 1);
    }

    /* access modifiers changed from: package-private */
    public int nextIndexOf(char c) {
        for (int i = this.pos; i < this.length; i++) {
            if (c == this.input[i]) {
                return i - this.pos;
            }
        }
        return -1;
    }

    /* access modifiers changed from: package-private */
    public int nextIndexOf(CharSequence charSequence) {
        char charAt = charSequence.charAt(0);
        int i = this.pos;
        while (i < this.length) {
            if (charAt != this.input[i]) {
                do {
                    i++;
                    if (i >= this.length) {
                        break;
                    }
                } while (charAt != this.input[i]);
            }
            int i2 = i + 1;
            int length2 = (charSequence.length() + i2) - 1;
            if (i < this.length && length2 <= this.length) {
                int i3 = i2;
                int i4 = 1;
                while (i3 < length2 && charSequence.charAt(i4) == this.input[i3]) {
                    i3++;
                    i4++;
                }
                if (i3 == length2) {
                    return i - this.pos;
                }
            }
            i = i2;
        }
        return -1;
    }

    /* access modifiers changed from: package-private */
    public String consumeTo(char c) {
        int nextIndexOf = nextIndexOf(c);
        if (nextIndexOf == -1) {
            return consumeToEnd();
        }
        String cacheString = cacheString(this.pos, nextIndexOf);
        this.pos += nextIndexOf;
        return cacheString;
    }

    /* access modifiers changed from: package-private */
    public String consumeTo(String str) {
        int nextIndexOf = nextIndexOf(str);
        if (nextIndexOf == -1) {
            return consumeToEnd();
        }
        String cacheString = cacheString(this.pos, nextIndexOf);
        this.pos += nextIndexOf;
        return cacheString;
    }

    /* access modifiers changed from: package-private */
    public String consumeToAny(char... cArr) {
        int i = this.pos;
        int i2 = this.length;
        loop0:
        while (this.pos < i2) {
            for (char c : cArr) {
                if (this.input[this.pos] == c) {
                    break loop0;
                }
            }
            this.pos++;
        }
        return this.pos > i ? cacheString(i, this.pos - i) : "";
    }

    /* access modifiers changed from: package-private */
    public String consumeToAnySorted(char... cArr) {
        int i = this.pos;
        int i2 = this.length;
        char[] cArr2 = this.input;
        while (this.pos < i2 && Arrays.binarySearch(cArr, cArr2[this.pos]) < 0) {
            this.pos++;
        }
        return this.pos > i ? cacheString(i, this.pos - i) : "";
    }

    /* access modifiers changed from: package-private */
    public String consumeData() {
        int i = this.pos;
        int i2 = this.length;
        char[] cArr = this.input;
        while (this.pos < i2 && (r3 = cArr[this.pos]) != '&' && r3 != '<' && r3 != 0) {
            this.pos++;
        }
        return this.pos > i ? cacheString(i, this.pos - i) : "";
    }

    /* access modifiers changed from: package-private */
    public String consumeTagName() {
        int i = this.pos;
        int i2 = this.length;
        char[] cArr = this.input;
        while (this.pos < i2 && (r3 = cArr[this.pos]) != '\t' && r3 != '\n' && r3 != '\r' && r3 != '\f' && r3 != ' ' && r3 != '/' && r3 != '>' && r3 != 0) {
            this.pos++;
        }
        return this.pos > i ? cacheString(i, this.pos - i) : "";
    }

    /* access modifiers changed from: package-private */
    public String consumeToEnd() {
        String cacheString = cacheString(this.pos, this.length - this.pos);
        this.pos = this.length;
        return cacheString;
    }

    /* access modifiers changed from: package-private */
    public String consumeLetterSequence() {
        int i = this.pos;
        while (this.pos < this.length && (((r1 = this.input[this.pos]) >= 'A' && r1 <= 'Z') || (r1 >= 'a' && r1 <= 'z'))) {
            this.pos++;
        }
        return cacheString(i, this.pos - i);
    }

    /* access modifiers changed from: package-private */
    public String consumeLetterThenDigitSequence() {
        int i = this.pos;
        while (this.pos < this.length && (((r1 = this.input[this.pos]) >= 'A' && r1 <= 'Z') || (r1 >= 'a' && r1 <= 'z'))) {
            this.pos++;
        }
        while (!isEmpty() && (r1 = this.input[this.pos]) >= '0' && r1 <= '9') {
            this.pos++;
        }
        return cacheString(i, this.pos - i);
    }

    /* access modifiers changed from: package-private */
    public String consumeHexSequence() {
        int i = this.pos;
        while (this.pos < this.length && (((r1 = this.input[this.pos]) >= '0' && r1 <= '9') || ((r1 >= 'A' && r1 <= 'F') || (r1 >= 'a' && r1 <= 'f')))) {
            this.pos++;
        }
        return cacheString(i, this.pos - i);
    }

    /* access modifiers changed from: package-private */
    public String consumeDigitSequence() {
        int i = this.pos;
        while (this.pos < this.length && (r1 = this.input[this.pos]) >= '0' && r1 <= '9') {
            this.pos++;
        }
        return cacheString(i, this.pos - i);
    }

    /* access modifiers changed from: package-private */
    public boolean matches(char c) {
        return !isEmpty() && this.input[this.pos] == c;
    }

    /* access modifiers changed from: package-private */
    public boolean matches(String str) {
        int length2 = str.length();
        if (length2 > this.length - this.pos) {
            return false;
        }
        for (int i = 0; i < length2; i++) {
            if (str.charAt(i) != this.input[this.pos + i]) {
                return false;
            }
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    public boolean matchesIgnoreCase(String str) {
        int length2 = str.length();
        if (length2 > this.length - this.pos) {
            return false;
        }
        for (int i = 0; i < length2; i++) {
            if (Character.toUpperCase(str.charAt(i)) != Character.toUpperCase(this.input[this.pos + i])) {
                return false;
            }
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    public boolean matchesAny(char... cArr) {
        if (isEmpty()) {
            return false;
        }
        char c = this.input[this.pos];
        for (char c2 : cArr) {
            if (c2 == c) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    public boolean matchesAnySorted(char[] cArr) {
        return !isEmpty() && Arrays.binarySearch(cArr, this.input[this.pos]) >= 0;
    }

    /* access modifiers changed from: package-private */
    public boolean matchesLetter() {
        if (isEmpty()) {
            return false;
        }
        char c = this.input[this.pos];
        if ((c < 'A' || c > 'Z') && (c < 'a' || c > 'z')) {
            return false;
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    public boolean matchesDigit() {
        char c;
        if (!isEmpty() && (c = this.input[this.pos]) >= '0' && c <= '9') {
            return true;
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    public boolean matchConsume(String str) {
        if (!matches(str)) {
            return false;
        }
        this.pos += str.length();
        return true;
    }

    /* access modifiers changed from: package-private */
    public boolean matchConsumeIgnoreCase(String str) {
        if (!matchesIgnoreCase(str)) {
            return false;
        }
        this.pos += str.length();
        return true;
    }

    /* access modifiers changed from: package-private */
    public boolean containsIgnoreCase(String str) {
        return nextIndexOf(str.toLowerCase(Locale.ENGLISH)) > -1 || nextIndexOf(str.toUpperCase(Locale.ENGLISH)) > -1;
    }

    public String toString() {
        return new String(this.input, this.pos, this.length - this.pos);
    }

    private String cacheString(int i, int i2) {
        char[] cArr = this.input;
        String[] strArr = this.stringCache;
        if (i2 > 12) {
            return new String(cArr, i, i2);
        }
        int i3 = 0;
        int i4 = i;
        int i5 = 0;
        while (i3 < i2) {
            i5 = (i5 * 31) + cArr[i4];
            i3++;
            i4++;
        }
        int length2 = (strArr.length - 1) & i5;
        String str = strArr[length2];
        if (str == null) {
            String str2 = new String(cArr, i, i2);
            strArr[length2] = str2;
            return str2;
        } else if (rangeEquals(i, i2, str)) {
            return str;
        } else {
            return new String(cArr, i, i2);
        }
    }

    /* access modifiers changed from: package-private */
    public boolean rangeEquals(int i, int i2, String str) {
        if (i2 != str.length()) {
            return false;
        }
        char[] cArr = this.input;
        int i3 = 0;
        while (true) {
            int i4 = i2 - 1;
            if (i2 == 0) {
                return true;
            }
            int i5 = i + 1;
            int i6 = i3 + 1;
            if (cArr[i] != str.charAt(i3)) {
                return false;
            }
            i = i5;
            i2 = i4;
            i3 = i6;
        }
    }
}

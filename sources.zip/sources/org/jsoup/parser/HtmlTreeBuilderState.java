package org.jsoup.parser;

import com.google.android.exoplayer2.text.ttml.TtmlNode;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.thedaw.uiuians.providers.soundcloud.helpers.SoundCloudArtworkHelper;
import io.fabric.sdk.android.services.settings.SettingsJsonConstants;
import java.util.ArrayList;
import java.util.Iterator;
import org.jsoup.helper.StringUtil;
import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.DocumentType;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.FormElement;
import org.jsoup.nodes.Node;
import org.jsoup.parser.Token;

/* access modifiers changed from: package-private */
public enum HtmlTreeBuilderState {
    Initial {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (HtmlTreeBuilderState.isWhitespace(token)) {
                return true;
            }
            if (token.isComment()) {
                htmlTreeBuilder.insert(token.asComment());
            } else if (token.isDoctype()) {
                Token.Doctype asDoctype = token.asDoctype();
                htmlTreeBuilder.getDocument().appendChild(new DocumentType(asDoctype.getName(), asDoctype.getPublicIdentifier(), asDoctype.getSystemIdentifier(), htmlTreeBuilder.getBaseUri()));
                if (asDoctype.isForceQuirks()) {
                    htmlTreeBuilder.getDocument().quirksMode(Document.QuirksMode.quirks);
                }
                htmlTreeBuilder.transition(BeforeHtml);
            } else {
                htmlTreeBuilder.transition(BeforeHtml);
                return htmlTreeBuilder.process(token);
            }
            return true;
        }
    },
    BeforeHtml {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (token.isDoctype()) {
                htmlTreeBuilder.error(this);
                return false;
            }
            if (token.isComment()) {
                htmlTreeBuilder.insert(token.asComment());
            } else if (HtmlTreeBuilderState.isWhitespace(token)) {
                return true;
            } else {
                if (!token.isStartTag() || !token.asStartTag().name().equals("html")) {
                    if (token.isEndTag()) {
                        if (StringUtil.in(token.asEndTag().name(), TtmlNode.TAG_HEAD, TtmlNode.TAG_BODY, "html", TtmlNode.TAG_BR)) {
                            return anythingElse(token, htmlTreeBuilder);
                        }
                    }
                    if (!token.isEndTag()) {
                        return anythingElse(token, htmlTreeBuilder);
                    }
                    htmlTreeBuilder.error(this);
                    return false;
                }
                htmlTreeBuilder.insert(token.asStartTag());
                htmlTreeBuilder.transition(BeforeHead);
            }
            return true;
        }

        private boolean anythingElse(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            htmlTreeBuilder.insertStartTag("html");
            htmlTreeBuilder.transition(BeforeHead);
            return htmlTreeBuilder.process(token);
        }
    },
    BeforeHead {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (HtmlTreeBuilderState.isWhitespace(token)) {
                return true;
            }
            if (token.isComment()) {
                htmlTreeBuilder.insert(token.asComment());
            } else if (token.isDoctype()) {
                htmlTreeBuilder.error(this);
                return false;
            } else if (token.isStartTag() && token.asStartTag().name().equals("html")) {
                return InBody.process(token, htmlTreeBuilder);
            } else {
                if (!token.isStartTag() || !token.asStartTag().name().equals(TtmlNode.TAG_HEAD)) {
                    if (token.isEndTag()) {
                        if (StringUtil.in(token.asEndTag().name(), TtmlNode.TAG_HEAD, TtmlNode.TAG_BODY, "html", TtmlNode.TAG_BR)) {
                            htmlTreeBuilder.processStartTag(TtmlNode.TAG_HEAD);
                            return htmlTreeBuilder.process(token);
                        }
                    }
                    if (token.isEndTag()) {
                        htmlTreeBuilder.error(this);
                        return false;
                    }
                    htmlTreeBuilder.processStartTag(TtmlNode.TAG_HEAD);
                    return htmlTreeBuilder.process(token);
                }
                htmlTreeBuilder.setHeadElement(htmlTreeBuilder.insert(token.asStartTag()));
                htmlTreeBuilder.transition(InHead);
            }
            return true;
        }
    },
    InHead {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (HtmlTreeBuilderState.isWhitespace(token)) {
                htmlTreeBuilder.insert(token.asCharacter());
                return true;
            }
            switch (token.type) {
                case Comment:
                    htmlTreeBuilder.insert(token.asComment());
                    break;
                case Doctype:
                    htmlTreeBuilder.error(this);
                    return false;
                case StartTag:
                    Token.StartTag asStartTag = token.asStartTag();
                    String name = asStartTag.name();
                    if (name.equals("html")) {
                        return InBody.process(token, htmlTreeBuilder);
                    }
                    if (StringUtil.in(name, "base", "basefont", "bgsound", "command", "link")) {
                        Element insertEmpty = htmlTreeBuilder.insertEmpty(asStartTag);
                        if (name.equals("base") && insertEmpty.hasAttr("href")) {
                            htmlTreeBuilder.maybeSetBaseUri(insertEmpty);
                            break;
                        }
                    } else if (name.equals("meta")) {
                        htmlTreeBuilder.insertEmpty(asStartTag);
                        break;
                    } else if (name.equals("title")) {
                        HtmlTreeBuilderState.handleRcData(asStartTag, htmlTreeBuilder);
                        break;
                    } else {
                        if (StringUtil.in(name, "noframes", TtmlNode.TAG_STYLE)) {
                            HtmlTreeBuilderState.handleRawtext(asStartTag, htmlTreeBuilder);
                            break;
                        } else if (name.equals("noscript")) {
                            htmlTreeBuilder.insert(asStartTag);
                            htmlTreeBuilder.transition(InHeadNoscript);
                            break;
                        } else if (name.equals("script")) {
                            htmlTreeBuilder.tokeniser.transition(TokeniserState.ScriptData);
                            htmlTreeBuilder.markInsertionMode();
                            htmlTreeBuilder.transition(Text);
                            htmlTreeBuilder.insert(asStartTag);
                            break;
                        } else if (!name.equals(TtmlNode.TAG_HEAD)) {
                            return anythingElse(token, htmlTreeBuilder);
                        } else {
                            htmlTreeBuilder.error(this);
                            return false;
                        }
                    }
                case EndTag:
                    String name2 = token.asEndTag().name();
                    if (name2.equals(TtmlNode.TAG_HEAD)) {
                        htmlTreeBuilder.pop();
                        htmlTreeBuilder.transition(AfterHead);
                        break;
                    } else {
                        if (StringUtil.in(name2, TtmlNode.TAG_BODY, "html", TtmlNode.TAG_BR)) {
                            return anythingElse(token, htmlTreeBuilder);
                        }
                        htmlTreeBuilder.error(this);
                        return false;
                    }
                default:
                    return anythingElse(token, htmlTreeBuilder);
            }
            return true;
        }

        private boolean anythingElse(Token token, TreeBuilder treeBuilder) {
            treeBuilder.processEndTag(TtmlNode.TAG_HEAD);
            return treeBuilder.process(token);
        }
    },
    InHeadNoscript {
        /* access modifiers changed from: package-private */
        /* JADX WARNING: Code restructure failed: missing block: B:22:0x0085, code lost:
            if (org.jsoup.helper.StringUtil.in(r8.asStartTag().name(), "basefont", "bgsound", "link", "meta", "noframes", com.google.android.exoplayer2.text.ttml.TtmlNode.TAG_STYLE) != false) goto L_0x00d0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:0x00bf, code lost:
            if (org.jsoup.helper.StringUtil.in(r8.asStartTag().name(), com.google.android.exoplayer2.text.ttml.TtmlNode.TAG_HEAD, "noscript") == false) goto L_0x00c1;
         */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (token.isDoctype()) {
                htmlTreeBuilder.error(this);
            } else if (token.isStartTag() && token.asStartTag().name().equals("html")) {
                return htmlTreeBuilder.process(token, InBody);
            } else {
                if (!token.isEndTag() || !token.asEndTag().name().equals("noscript")) {
                    if (!HtmlTreeBuilderState.isWhitespace(token) && !token.isComment()) {
                        if (token.isStartTag()) {
                        }
                        if (token.isEndTag() && token.asEndTag().name().equals(TtmlNode.TAG_BR)) {
                            return anythingElse(token, htmlTreeBuilder);
                        }
                        if (token.isStartTag()) {
                        }
                        if (!token.isEndTag()) {
                            return anythingElse(token, htmlTreeBuilder);
                        }
                        htmlTreeBuilder.error(this);
                        return false;
                    }
                    return htmlTreeBuilder.process(token, InHead);
                }
                htmlTreeBuilder.pop();
                htmlTreeBuilder.transition(InHead);
            }
            return true;
        }

        private boolean anythingElse(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            htmlTreeBuilder.error(this);
            htmlTreeBuilder.insert(new Token.Character().data(token.toString()));
            return true;
        }
    },
    AfterHead {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (HtmlTreeBuilderState.isWhitespace(token)) {
                htmlTreeBuilder.insert(token.asCharacter());
            } else if (token.isComment()) {
                htmlTreeBuilder.insert(token.asComment());
            } else if (token.isDoctype()) {
                htmlTreeBuilder.error(this);
            } else if (token.isStartTag()) {
                Token.StartTag asStartTag = token.asStartTag();
                String name = asStartTag.name();
                if (name.equals("html")) {
                    return htmlTreeBuilder.process(token, InBody);
                }
                if (name.equals(TtmlNode.TAG_BODY)) {
                    htmlTreeBuilder.insert(asStartTag);
                    htmlTreeBuilder.framesetOk(false);
                    htmlTreeBuilder.transition(InBody);
                } else if (name.equals("frameset")) {
                    htmlTreeBuilder.insert(asStartTag);
                    htmlTreeBuilder.transition(InFrameset);
                } else {
                    if (StringUtil.in(name, "base", "basefont", "bgsound", "link", "meta", "noframes", "script", TtmlNode.TAG_STYLE, "title")) {
                        htmlTreeBuilder.error(this);
                        Element headElement = htmlTreeBuilder.getHeadElement();
                        htmlTreeBuilder.push(headElement);
                        htmlTreeBuilder.process(token, InHead);
                        htmlTreeBuilder.removeFromStack(headElement);
                    } else if (name.equals(TtmlNode.TAG_HEAD)) {
                        htmlTreeBuilder.error(this);
                        return false;
                    } else {
                        anythingElse(token, htmlTreeBuilder);
                    }
                }
            } else if (token.isEndTag()) {
                if (StringUtil.in(token.asEndTag().name(), TtmlNode.TAG_BODY, "html")) {
                    anythingElse(token, htmlTreeBuilder);
                } else {
                    htmlTreeBuilder.error(this);
                    return false;
                }
            } else {
                anythingElse(token, htmlTreeBuilder);
            }
            return true;
        }

        private boolean anythingElse(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            htmlTreeBuilder.processStartTag(TtmlNode.TAG_BODY);
            htmlTreeBuilder.framesetOk(true);
            return htmlTreeBuilder.process(token);
        }
    },
    InBody {
        /* access modifiers changed from: package-private */
        /* JADX WARNING: Removed duplicated region for block: B:65:0x0124  */
        /* JADX WARNING: Removed duplicated region for block: B:69:0x0131  */
        /* JADX WARNING: Removed duplicated region for block: B:75:0x0169 A[LOOP:3: B:74:0x0167->B:75:0x0169, LOOP_END] */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            Element element;
            boolean z = true;
            switch (token.type) {
                case Comment:
                    htmlTreeBuilder.insert(token.asComment());
                    break;
                case Doctype:
                    htmlTreeBuilder.error(this);
                    return false;
                case StartTag:
                    Token.StartTag asStartTag = token.asStartTag();
                    String name = asStartTag.name();
                    if (!name.equals("a")) {
                        if (!StringUtil.inSorted(name, Constants.InBodyStartEmptyFormatters)) {
                            if (!StringUtil.inSorted(name, Constants.InBodyStartPClosers)) {
                                if (!name.equals(TtmlNode.TAG_SPAN)) {
                                    if (!name.equals("li")) {
                                        if (name.equals("html")) {
                                            htmlTreeBuilder.error(this);
                                            Element element2 = htmlTreeBuilder.getStack().get(0);
                                            Iterator<Attribute> it = asStartTag.getAttributes().iterator();
                                            while (it.hasNext()) {
                                                Attribute next = it.next();
                                                if (!element2.hasAttr(next.getKey())) {
                                                    element2.attributes().put(next);
                                                }
                                            }
                                            break;
                                        } else if (StringUtil.inSorted(name, Constants.InBodyStartToHead)) {
                                            return htmlTreeBuilder.process(token, InHead);
                                        } else {
                                            if (name.equals(TtmlNode.TAG_BODY)) {
                                                htmlTreeBuilder.error(this);
                                                ArrayList<Element> stack = htmlTreeBuilder.getStack();
                                                if (stack.size() != 1 && (stack.size() <= 2 || stack.get(1).nodeName().equals(TtmlNode.TAG_BODY))) {
                                                    htmlTreeBuilder.framesetOk(false);
                                                    Element element3 = stack.get(1);
                                                    Iterator<Attribute> it2 = asStartTag.getAttributes().iterator();
                                                    while (it2.hasNext()) {
                                                        Attribute next2 = it2.next();
                                                        if (!element3.hasAttr(next2.getKey())) {
                                                            element3.attributes().put(next2);
                                                        }
                                                    }
                                                    break;
                                                } else {
                                                    return false;
                                                }
                                            } else if (!name.equals("frameset")) {
                                                if (!StringUtil.inSorted(name, Constants.Headings)) {
                                                    if (StringUtil.inSorted(name, Constants.InBodyStartPreListing)) {
                                                        if (htmlTreeBuilder.inButtonScope(TtmlNode.TAG_P)) {
                                                            htmlTreeBuilder.processEndTag(TtmlNode.TAG_P);
                                                        }
                                                        htmlTreeBuilder.insert(asStartTag);
                                                        htmlTreeBuilder.framesetOk(false);
                                                        break;
                                                    } else if (!name.equals("form")) {
                                                        if (!StringUtil.inSorted(name, Constants.DdDt)) {
                                                            if (!name.equals("plaintext")) {
                                                                if (name.equals("button")) {
                                                                    if (htmlTreeBuilder.inButtonScope("button")) {
                                                                        htmlTreeBuilder.error(this);
                                                                        htmlTreeBuilder.processEndTag("button");
                                                                        htmlTreeBuilder.process(asStartTag);
                                                                        break;
                                                                    } else {
                                                                        htmlTreeBuilder.reconstructFormattingElements();
                                                                        htmlTreeBuilder.insert(asStartTag);
                                                                        htmlTreeBuilder.framesetOk(false);
                                                                        break;
                                                                    }
                                                                } else if (!StringUtil.inSorted(name, Constants.Formatters)) {
                                                                    if (!name.equals("nobr")) {
                                                                        if (!StringUtil.inSorted(name, Constants.InBodyStartApplets)) {
                                                                            if (!name.equals("table")) {
                                                                                if (!name.equals("input")) {
                                                                                    if (!StringUtil.inSorted(name, Constants.InBodyStartMedia)) {
                                                                                        if (name.equals("hr")) {
                                                                                            if (htmlTreeBuilder.inButtonScope(TtmlNode.TAG_P)) {
                                                                                                htmlTreeBuilder.processEndTag(TtmlNode.TAG_P);
                                                                                            }
                                                                                            htmlTreeBuilder.insertEmpty(asStartTag);
                                                                                            htmlTreeBuilder.framesetOk(false);
                                                                                            break;
                                                                                        } else if (!name.equals("image")) {
                                                                                            if (!name.equals("isindex")) {
                                                                                                if (!name.equals("textarea")) {
                                                                                                    if (!name.equals("xmp")) {
                                                                                                        if (!name.equals("iframe")) {
                                                                                                            if (!name.equals("noembed")) {
                                                                                                                if (!name.equals("select")) {
                                                                                                                    if (!StringUtil.inSorted(name, Constants.InBodyStartOptions)) {
                                                                                                                        if (StringUtil.inSorted(name, Constants.InBodyStartRuby)) {
                                                                                                                            if (htmlTreeBuilder.inScope("ruby")) {
                                                                                                                                htmlTreeBuilder.generateImpliedEndTags();
                                                                                                                                if (!htmlTreeBuilder.currentElement().nodeName().equals("ruby")) {
                                                                                                                                    htmlTreeBuilder.error(this);
                                                                                                                                    htmlTreeBuilder.popStackToBefore("ruby");
                                                                                                                                }
                                                                                                                                htmlTreeBuilder.insert(asStartTag);
                                                                                                                                break;
                                                                                                                            }
                                                                                                                        } else if (!name.equals("math")) {
                                                                                                                            if (name.equals("svg")) {
                                                                                                                                htmlTreeBuilder.reconstructFormattingElements();
                                                                                                                                htmlTreeBuilder.insert(asStartTag);
                                                                                                                                htmlTreeBuilder.tokeniser.acknowledgeSelfClosingFlag();
                                                                                                                                break;
                                                                                                                            } else if (!StringUtil.inSorted(name, Constants.InBodyStartDrop)) {
                                                                                                                                htmlTreeBuilder.reconstructFormattingElements();
                                                                                                                                htmlTreeBuilder.insert(asStartTag);
                                                                                                                                break;
                                                                                                                            } else {
                                                                                                                                htmlTreeBuilder.error(this);
                                                                                                                                return false;
                                                                                                                            }
                                                                                                                        } else {
                                                                                                                            htmlTreeBuilder.reconstructFormattingElements();
                                                                                                                            htmlTreeBuilder.insert(asStartTag);
                                                                                                                            htmlTreeBuilder.tokeniser.acknowledgeSelfClosingFlag();
                                                                                                                            break;
                                                                                                                        }
                                                                                                                    } else {
                                                                                                                        if (htmlTreeBuilder.currentElement().nodeName().equals("option")) {
                                                                                                                            htmlTreeBuilder.processEndTag("option");
                                                                                                                        }
                                                                                                                        htmlTreeBuilder.reconstructFormattingElements();
                                                                                                                        htmlTreeBuilder.insert(asStartTag);
                                                                                                                        break;
                                                                                                                    }
                                                                                                                } else {
                                                                                                                    htmlTreeBuilder.reconstructFormattingElements();
                                                                                                                    htmlTreeBuilder.insert(asStartTag);
                                                                                                                    htmlTreeBuilder.framesetOk(false);
                                                                                                                    HtmlTreeBuilderState state = htmlTreeBuilder.state();
                                                                                                                    if (!state.equals(InTable) && !state.equals(InCaption) && !state.equals(InTableBody) && !state.equals(InRow) && !state.equals(InCell)) {
                                                                                                                        htmlTreeBuilder.transition(InSelect);
                                                                                                                        break;
                                                                                                                    } else {
                                                                                                                        htmlTreeBuilder.transition(InSelectInTable);
                                                                                                                        break;
                                                                                                                    }
                                                                                                                }
                                                                                                            } else {
                                                                                                                HtmlTreeBuilderState.handleRawtext(asStartTag, htmlTreeBuilder);
                                                                                                                break;
                                                                                                            }
                                                                                                        } else {
                                                                                                            htmlTreeBuilder.framesetOk(false);
                                                                                                            HtmlTreeBuilderState.handleRawtext(asStartTag, htmlTreeBuilder);
                                                                                                            break;
                                                                                                        }
                                                                                                    } else {
                                                                                                        if (htmlTreeBuilder.inButtonScope(TtmlNode.TAG_P)) {
                                                                                                            htmlTreeBuilder.processEndTag(TtmlNode.TAG_P);
                                                                                                        }
                                                                                                        htmlTreeBuilder.reconstructFormattingElements();
                                                                                                        htmlTreeBuilder.framesetOk(false);
                                                                                                        HtmlTreeBuilderState.handleRawtext(asStartTag, htmlTreeBuilder);
                                                                                                        break;
                                                                                                    }
                                                                                                } else {
                                                                                                    htmlTreeBuilder.insert(asStartTag);
                                                                                                    htmlTreeBuilder.tokeniser.transition(TokeniserState.Rcdata);
                                                                                                    htmlTreeBuilder.markInsertionMode();
                                                                                                    htmlTreeBuilder.framesetOk(false);
                                                                                                    htmlTreeBuilder.transition(Text);
                                                                                                    break;
                                                                                                }
                                                                                            } else {
                                                                                                htmlTreeBuilder.error(this);
                                                                                                if (htmlTreeBuilder.getFormElement() == null) {
                                                                                                    htmlTreeBuilder.tokeniser.acknowledgeSelfClosingFlag();
                                                                                                    htmlTreeBuilder.processStartTag("form");
                                                                                                    if (asStartTag.attributes.hasKey("action")) {
                                                                                                        htmlTreeBuilder.getFormElement().attr("action", asStartTag.attributes.get("action"));
                                                                                                    }
                                                                                                    htmlTreeBuilder.processStartTag("hr");
                                                                                                    htmlTreeBuilder.processStartTag("label");
                                                                                                    htmlTreeBuilder.process(new Token.Character().data(asStartTag.attributes.hasKey(SettingsJsonConstants.PROMPT_KEY) ? asStartTag.attributes.get(SettingsJsonConstants.PROMPT_KEY) : "This is a searchable index. Enter search keywords: "));
                                                                                                    Attributes attributes = new Attributes();
                                                                                                    Iterator<Attribute> it3 = asStartTag.attributes.iterator();
                                                                                                    while (it3.hasNext()) {
                                                                                                        Attribute next3 = it3.next();
                                                                                                        if (!StringUtil.inSorted(next3.getKey(), Constants.InBodyStartInputAttribs)) {
                                                                                                            attributes.put(next3);
                                                                                                        }
                                                                                                    }
                                                                                                    attributes.put("name", "isindex");
                                                                                                    htmlTreeBuilder.processStartTag("input", attributes);
                                                                                                    htmlTreeBuilder.processEndTag("label");
                                                                                                    htmlTreeBuilder.processStartTag("hr");
                                                                                                    htmlTreeBuilder.processEndTag("form");
                                                                                                    break;
                                                                                                } else {
                                                                                                    return false;
                                                                                                }
                                                                                            }
                                                                                        } else if (htmlTreeBuilder.getFromStack("svg") != null) {
                                                                                            htmlTreeBuilder.insert(asStartTag);
                                                                                            break;
                                                                                        } else {
                                                                                            return htmlTreeBuilder.process(asStartTag.name("img"));
                                                                                        }
                                                                                    } else {
                                                                                        htmlTreeBuilder.insertEmpty(asStartTag);
                                                                                        break;
                                                                                    }
                                                                                } else {
                                                                                    htmlTreeBuilder.reconstructFormattingElements();
                                                                                    if (!htmlTreeBuilder.insertEmpty(asStartTag).attr("type").equalsIgnoreCase("hidden")) {
                                                                                        htmlTreeBuilder.framesetOk(false);
                                                                                        break;
                                                                                    }
                                                                                }
                                                                            } else {
                                                                                if (htmlTreeBuilder.getDocument().quirksMode() != Document.QuirksMode.quirks && htmlTreeBuilder.inButtonScope(TtmlNode.TAG_P)) {
                                                                                    htmlTreeBuilder.processEndTag(TtmlNode.TAG_P);
                                                                                }
                                                                                htmlTreeBuilder.insert(asStartTag);
                                                                                htmlTreeBuilder.framesetOk(false);
                                                                                htmlTreeBuilder.transition(InTable);
                                                                                break;
                                                                            }
                                                                        } else {
                                                                            htmlTreeBuilder.reconstructFormattingElements();
                                                                            htmlTreeBuilder.insert(asStartTag);
                                                                            htmlTreeBuilder.insertMarkerToFormattingElements();
                                                                            htmlTreeBuilder.framesetOk(false);
                                                                            break;
                                                                        }
                                                                    } else {
                                                                        htmlTreeBuilder.reconstructFormattingElements();
                                                                        if (htmlTreeBuilder.inScope("nobr")) {
                                                                            htmlTreeBuilder.error(this);
                                                                            htmlTreeBuilder.processEndTag("nobr");
                                                                            htmlTreeBuilder.reconstructFormattingElements();
                                                                        }
                                                                        htmlTreeBuilder.pushActiveFormattingElements(htmlTreeBuilder.insert(asStartTag));
                                                                        break;
                                                                    }
                                                                } else {
                                                                    htmlTreeBuilder.reconstructFormattingElements();
                                                                    htmlTreeBuilder.pushActiveFormattingElements(htmlTreeBuilder.insert(asStartTag));
                                                                    break;
                                                                }
                                                            } else {
                                                                if (htmlTreeBuilder.inButtonScope(TtmlNode.TAG_P)) {
                                                                    htmlTreeBuilder.processEndTag(TtmlNode.TAG_P);
                                                                }
                                                                htmlTreeBuilder.insert(asStartTag);
                                                                htmlTreeBuilder.tokeniser.transition(TokeniserState.PLAINTEXT);
                                                                break;
                                                            }
                                                        } else {
                                                            htmlTreeBuilder.framesetOk(false);
                                                            ArrayList<Element> stack2 = htmlTreeBuilder.getStack();
                                                            int size = stack2.size() - 1;
                                                            while (true) {
                                                                if (size > 0) {
                                                                    Element element4 = stack2.get(size);
                                                                    if (StringUtil.inSorted(element4.nodeName(), Constants.DdDt)) {
                                                                        htmlTreeBuilder.processEndTag(element4.nodeName());
                                                                    } else if (!htmlTreeBuilder.isSpecial(element4) || StringUtil.inSorted(element4.nodeName(), Constants.InBodyStartLiBreakers)) {
                                                                        size--;
                                                                    }
                                                                }
                                                            }
                                                            if (htmlTreeBuilder.inButtonScope(TtmlNode.TAG_P)) {
                                                                htmlTreeBuilder.processEndTag(TtmlNode.TAG_P);
                                                            }
                                                            htmlTreeBuilder.insert(asStartTag);
                                                            break;
                                                        }
                                                    } else if (htmlTreeBuilder.getFormElement() != null) {
                                                        htmlTreeBuilder.error(this);
                                                        return false;
                                                    } else {
                                                        if (htmlTreeBuilder.inButtonScope(TtmlNode.TAG_P)) {
                                                            htmlTreeBuilder.processEndTag(TtmlNode.TAG_P);
                                                        }
                                                        htmlTreeBuilder.insertForm(asStartTag, true);
                                                        return true;
                                                    }
                                                } else {
                                                    if (htmlTreeBuilder.inButtonScope(TtmlNode.TAG_P)) {
                                                        htmlTreeBuilder.processEndTag(TtmlNode.TAG_P);
                                                    }
                                                    if (StringUtil.inSorted(htmlTreeBuilder.currentElement().nodeName(), Constants.Headings)) {
                                                        htmlTreeBuilder.error(this);
                                                        htmlTreeBuilder.pop();
                                                    }
                                                    htmlTreeBuilder.insert(asStartTag);
                                                    break;
                                                }
                                            } else {
                                                htmlTreeBuilder.error(this);
                                                ArrayList<Element> stack3 = htmlTreeBuilder.getStack();
                                                if (stack3.size() != 1 && ((stack3.size() <= 2 || stack3.get(1).nodeName().equals(TtmlNode.TAG_BODY)) && htmlTreeBuilder.framesetOk())) {
                                                    Element element5 = stack3.get(1);
                                                    if (element5.parent() != null) {
                                                        element5.remove();
                                                    }
                                                    for (int i = 1; stack3.size() > i; i = 1) {
                                                        stack3.remove(stack3.size() - i);
                                                    }
                                                    htmlTreeBuilder.insert(asStartTag);
                                                    htmlTreeBuilder.transition(InFrameset);
                                                    break;
                                                } else {
                                                    return false;
                                                }
                                            }
                                        }
                                    } else {
                                        htmlTreeBuilder.framesetOk(false);
                                        ArrayList<Element> stack4 = htmlTreeBuilder.getStack();
                                        int size2 = stack4.size() - 1;
                                        while (true) {
                                            if (size2 > 0) {
                                                Element element6 = stack4.get(size2);
                                                if (element6.nodeName().equals("li")) {
                                                    htmlTreeBuilder.processEndTag("li");
                                                } else if (!htmlTreeBuilder.isSpecial(element6) || StringUtil.inSorted(element6.nodeName(), Constants.InBodyStartLiBreakers)) {
                                                    size2--;
                                                }
                                            }
                                        }
                                        if (htmlTreeBuilder.inButtonScope(TtmlNode.TAG_P)) {
                                            htmlTreeBuilder.processEndTag(TtmlNode.TAG_P);
                                        }
                                        htmlTreeBuilder.insert(asStartTag);
                                        break;
                                    }
                                } else {
                                    htmlTreeBuilder.reconstructFormattingElements();
                                    htmlTreeBuilder.insert(asStartTag);
                                    break;
                                }
                            } else {
                                if (htmlTreeBuilder.inButtonScope(TtmlNode.TAG_P)) {
                                    htmlTreeBuilder.processEndTag(TtmlNode.TAG_P);
                                }
                                htmlTreeBuilder.insert(asStartTag);
                                break;
                            }
                        } else {
                            htmlTreeBuilder.reconstructFormattingElements();
                            htmlTreeBuilder.insertEmpty(asStartTag);
                            htmlTreeBuilder.framesetOk(false);
                            break;
                        }
                    } else {
                        if (htmlTreeBuilder.getActiveFormattingElement("a") != null) {
                            htmlTreeBuilder.error(this);
                            htmlTreeBuilder.processEndTag("a");
                            Element fromStack = htmlTreeBuilder.getFromStack("a");
                            if (fromStack != null) {
                                htmlTreeBuilder.removeFromActiveFormattingElements(fromStack);
                                htmlTreeBuilder.removeFromStack(fromStack);
                            }
                        }
                        htmlTreeBuilder.reconstructFormattingElements();
                        htmlTreeBuilder.pushActiveFormattingElements(htmlTreeBuilder.insert(asStartTag));
                        break;
                    }
                    break;
                case EndTag:
                    Token.EndTag asEndTag = token.asEndTag();
                    String name2 = asEndTag.name();
                    if (StringUtil.inSorted(name2, Constants.InBodyEndAdoptionFormatters)) {
                        int i2 = 0;
                        while (i2 < 8) {
                            Element activeFormattingElement = htmlTreeBuilder.getActiveFormattingElement(name2);
                            if (activeFormattingElement == null) {
                                return anyOtherEndTag(token, htmlTreeBuilder);
                            }
                            if (!htmlTreeBuilder.onStack(activeFormattingElement)) {
                                htmlTreeBuilder.error(this);
                                htmlTreeBuilder.removeFromActiveFormattingElements(activeFormattingElement);
                                return z;
                            } else if (!htmlTreeBuilder.inScope(activeFormattingElement.nodeName())) {
                                htmlTreeBuilder.error(this);
                                return false;
                            } else {
                                if (htmlTreeBuilder.currentElement() != activeFormattingElement) {
                                    htmlTreeBuilder.error(this);
                                }
                                ArrayList<Element> stack5 = htmlTreeBuilder.getStack();
                                int size3 = stack5.size();
                                Element element7 = null;
                                int i3 = 0;
                                boolean z2 = false;
                                while (true) {
                                    if (i3 >= size3 || i3 >= 64) {
                                        element = null;
                                    } else {
                                        element = stack5.get(i3);
                                        if (element == activeFormattingElement) {
                                            element7 = stack5.get(i3 - 1);
                                            z2 = true;
                                        } else if (z2 && htmlTreeBuilder.isSpecial(element)) {
                                        }
                                        i3++;
                                    }
                                }
                                element = null;
                                if (element == null) {
                                    htmlTreeBuilder.popStackToClose(activeFormattingElement.nodeName());
                                    htmlTreeBuilder.removeFromActiveFormattingElements(activeFormattingElement);
                                    return z;
                                }
                                Element element8 = element;
                                Element element9 = element8;
                                for (int i4 = 0; i4 < 3; i4++) {
                                    if (htmlTreeBuilder.onStack(element8)) {
                                        element8 = htmlTreeBuilder.aboveOnStack(element8);
                                    }
                                    if (!htmlTreeBuilder.isInActiveFormattingElements(element8)) {
                                        htmlTreeBuilder.removeFromStack(element8);
                                    } else if (element8 == activeFormattingElement) {
                                        if (!StringUtil.inSorted(element7.nodeName(), Constants.InBodyEndTableFosters)) {
                                            if (element9.parent() != null) {
                                                element9.remove();
                                            }
                                            htmlTreeBuilder.insertInFosterParent(element9);
                                        } else {
                                            if (element9.parent() != null) {
                                                element9.remove();
                                            }
                                            element7.appendChild(element9);
                                        }
                                        Element element10 = new Element(activeFormattingElement.tag(), htmlTreeBuilder.getBaseUri());
                                        element10.attributes().addAll(activeFormattingElement.attributes());
                                        for (Node node : (Node[]) element.childNodes().toArray(new Node[element.childNodeSize()])) {
                                            element10.appendChild(node);
                                        }
                                        element.appendChild(element10);
                                        htmlTreeBuilder.removeFromActiveFormattingElements(activeFormattingElement);
                                        htmlTreeBuilder.removeFromStack(activeFormattingElement);
                                        htmlTreeBuilder.insertOnStackAfter(element, element10);
                                        i2++;
                                        z = true;
                                    } else {
                                        Element element11 = new Element(Tag.valueOf(element8.nodeName()), htmlTreeBuilder.getBaseUri());
                                        htmlTreeBuilder.replaceActiveFormattingElement(element8, element11);
                                        htmlTreeBuilder.replaceOnStack(element8, element11);
                                        if (element9.parent() != null) {
                                            element9.remove();
                                        }
                                        element11.appendChild(element9);
                                        element8 = element11;
                                        element9 = element8;
                                    }
                                }
                                if (!StringUtil.inSorted(element7.nodeName(), Constants.InBodyEndTableFosters)) {
                                }
                                Element element102 = new Element(activeFormattingElement.tag(), htmlTreeBuilder.getBaseUri());
                                element102.attributes().addAll(activeFormattingElement.attributes());
                                while (r11 < r10) {
                                }
                                element.appendChild(element102);
                                htmlTreeBuilder.removeFromActiveFormattingElements(activeFormattingElement);
                                htmlTreeBuilder.removeFromStack(activeFormattingElement);
                                htmlTreeBuilder.insertOnStackAfter(element, element102);
                                i2++;
                                z = true;
                            }
                        }
                        break;
                    } else if (StringUtil.inSorted(name2, Constants.InBodyEndClosers)) {
                        if (htmlTreeBuilder.inScope(name2)) {
                            htmlTreeBuilder.generateImpliedEndTags();
                            if (!htmlTreeBuilder.currentElement().nodeName().equals(name2)) {
                                htmlTreeBuilder.error(this);
                            }
                            htmlTreeBuilder.popStackToClose(name2);
                            break;
                        } else {
                            htmlTreeBuilder.error(this);
                            return false;
                        }
                    } else if (name2.equals(TtmlNode.TAG_SPAN)) {
                        return anyOtherEndTag(token, htmlTreeBuilder);
                    } else {
                        if (name2.equals("li")) {
                            if (htmlTreeBuilder.inListItemScope(name2)) {
                                htmlTreeBuilder.generateImpliedEndTags(name2);
                                if (!htmlTreeBuilder.currentElement().nodeName().equals(name2)) {
                                    htmlTreeBuilder.error(this);
                                }
                                htmlTreeBuilder.popStackToClose(name2);
                                break;
                            } else {
                                htmlTreeBuilder.error(this);
                                return false;
                            }
                        } else if (name2.equals(TtmlNode.TAG_BODY)) {
                            if (htmlTreeBuilder.inScope(TtmlNode.TAG_BODY)) {
                                htmlTreeBuilder.transition(AfterBody);
                                break;
                            } else {
                                htmlTreeBuilder.error(this);
                                return false;
                            }
                        } else if (name2.equals("html")) {
                            if (htmlTreeBuilder.processEndTag(TtmlNode.TAG_BODY)) {
                                return htmlTreeBuilder.process(asEndTag);
                            }
                        } else if (name2.equals("form")) {
                            FormElement formElement = htmlTreeBuilder.getFormElement();
                            htmlTreeBuilder.setFormElement(null);
                            if (formElement != null && htmlTreeBuilder.inScope(name2)) {
                                htmlTreeBuilder.generateImpliedEndTags();
                                if (!htmlTreeBuilder.currentElement().nodeName().equals(name2)) {
                                    htmlTreeBuilder.error(this);
                                }
                                htmlTreeBuilder.removeFromStack(formElement);
                                break;
                            } else {
                                htmlTreeBuilder.error(this);
                                return false;
                            }
                        } else if (name2.equals(TtmlNode.TAG_P)) {
                            if (htmlTreeBuilder.inButtonScope(name2)) {
                                htmlTreeBuilder.generateImpliedEndTags(name2);
                                if (!htmlTreeBuilder.currentElement().nodeName().equals(name2)) {
                                    htmlTreeBuilder.error(this);
                                }
                                htmlTreeBuilder.popStackToClose(name2);
                                break;
                            } else {
                                htmlTreeBuilder.error(this);
                                htmlTreeBuilder.processStartTag(name2);
                                return htmlTreeBuilder.process(asEndTag);
                            }
                        } else if (StringUtil.inSorted(name2, Constants.DdDt)) {
                            if (htmlTreeBuilder.inScope(name2)) {
                                htmlTreeBuilder.generateImpliedEndTags(name2);
                                if (!htmlTreeBuilder.currentElement().nodeName().equals(name2)) {
                                    htmlTreeBuilder.error(this);
                                }
                                htmlTreeBuilder.popStackToClose(name2);
                                break;
                            } else {
                                htmlTreeBuilder.error(this);
                                return false;
                            }
                        } else if (StringUtil.inSorted(name2, Constants.Headings)) {
                            if (htmlTreeBuilder.inScope(Constants.Headings)) {
                                htmlTreeBuilder.generateImpliedEndTags(name2);
                                if (!htmlTreeBuilder.currentElement().nodeName().equals(name2)) {
                                    htmlTreeBuilder.error(this);
                                }
                                htmlTreeBuilder.popStackToClose(Constants.Headings);
                                break;
                            } else {
                                htmlTreeBuilder.error(this);
                                return false;
                            }
                        } else if (name2.equals("sarcasm")) {
                            return anyOtherEndTag(token, htmlTreeBuilder);
                        } else {
                            if (StringUtil.inSorted(name2, Constants.InBodyStartApplets)) {
                                if (!htmlTreeBuilder.inScope("name")) {
                                    if (htmlTreeBuilder.inScope(name2)) {
                                        htmlTreeBuilder.generateImpliedEndTags();
                                        if (!htmlTreeBuilder.currentElement().nodeName().equals(name2)) {
                                            htmlTreeBuilder.error(this);
                                        }
                                        htmlTreeBuilder.popStackToClose(name2);
                                        htmlTreeBuilder.clearFormattingElementsToLastMarker();
                                        break;
                                    } else {
                                        htmlTreeBuilder.error(this);
                                        return false;
                                    }
                                }
                            } else if (!name2.equals(TtmlNode.TAG_BR)) {
                                return anyOtherEndTag(token, htmlTreeBuilder);
                            } else {
                                htmlTreeBuilder.error(this);
                                htmlTreeBuilder.processStartTag(TtmlNode.TAG_BR);
                                return false;
                            }
                        }
                    }
                    break;
                case Character:
                    Token.Character asCharacter = token.asCharacter();
                    if (!asCharacter.getData().equals(HtmlTreeBuilderState.nullString)) {
                        if (!htmlTreeBuilder.framesetOk() || !HtmlTreeBuilderState.isWhitespace(asCharacter)) {
                            htmlTreeBuilder.reconstructFormattingElements();
                            htmlTreeBuilder.insert(asCharacter);
                            htmlTreeBuilder.framesetOk(false);
                            break;
                        } else {
                            htmlTreeBuilder.reconstructFormattingElements();
                            htmlTreeBuilder.insert(asCharacter);
                            break;
                        }
                    } else {
                        htmlTreeBuilder.error(this);
                        return false;
                    }
                    break;
            }
            return true;
        }

        /* access modifiers changed from: package-private */
        public boolean anyOtherEndTag(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            String name = token.asEndTag().name();
            ArrayList<Element> stack = htmlTreeBuilder.getStack();
            int size = stack.size() - 1;
            while (true) {
                if (size < 0) {
                    break;
                }
                Element element = stack.get(size);
                if (element.nodeName().equals(name)) {
                    htmlTreeBuilder.generateImpliedEndTags(name);
                    if (!name.equals(htmlTreeBuilder.currentElement().nodeName())) {
                        htmlTreeBuilder.error(this);
                    }
                    htmlTreeBuilder.popStackToClose(name);
                } else if (htmlTreeBuilder.isSpecial(element)) {
                    htmlTreeBuilder.error(this);
                    return false;
                } else {
                    size--;
                }
            }
            return true;
        }
    },
    Text {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (token.isCharacter()) {
                htmlTreeBuilder.insert(token.asCharacter());
                return true;
            } else if (token.isEOF()) {
                htmlTreeBuilder.error(this);
                htmlTreeBuilder.pop();
                htmlTreeBuilder.transition(htmlTreeBuilder.originalState());
                return htmlTreeBuilder.process(token);
            } else if (!token.isEndTag()) {
                return true;
            } else {
                htmlTreeBuilder.pop();
                htmlTreeBuilder.transition(htmlTreeBuilder.originalState());
                return true;
            }
        }
    },
    InTable {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (token.isCharacter()) {
                htmlTreeBuilder.newPendingTableCharacters();
                htmlTreeBuilder.markInsertionMode();
                htmlTreeBuilder.transition(InTableText);
                return htmlTreeBuilder.process(token);
            } else if (token.isComment()) {
                htmlTreeBuilder.insert(token.asComment());
                return true;
            } else if (token.isDoctype()) {
                htmlTreeBuilder.error(this);
                return false;
            } else if (token.isStartTag()) {
                Token.StartTag asStartTag = token.asStartTag();
                String name = asStartTag.name();
                if (name.equals("caption")) {
                    htmlTreeBuilder.clearStackToTableContext();
                    htmlTreeBuilder.insertMarkerToFormattingElements();
                    htmlTreeBuilder.insert(asStartTag);
                    htmlTreeBuilder.transition(InCaption);
                } else if (name.equals("colgroup")) {
                    htmlTreeBuilder.clearStackToTableContext();
                    htmlTreeBuilder.insert(asStartTag);
                    htmlTreeBuilder.transition(InColumnGroup);
                } else if (name.equals("col")) {
                    htmlTreeBuilder.processStartTag("colgroup");
                    return htmlTreeBuilder.process(token);
                } else {
                    if (StringUtil.in(name, "tbody", "tfoot", "thead")) {
                        htmlTreeBuilder.clearStackToTableContext();
                        htmlTreeBuilder.insert(asStartTag);
                        htmlTreeBuilder.transition(InTableBody);
                    } else {
                        if (StringUtil.in(name, "td", "th", "tr")) {
                            htmlTreeBuilder.processStartTag("tbody");
                            return htmlTreeBuilder.process(token);
                        } else if (name.equals("table")) {
                            htmlTreeBuilder.error(this);
                            if (htmlTreeBuilder.processEndTag("table")) {
                                return htmlTreeBuilder.process(token);
                            }
                        } else {
                            if (StringUtil.in(name, TtmlNode.TAG_STYLE, "script")) {
                                return htmlTreeBuilder.process(token, InHead);
                            }
                            if (name.equals("input")) {
                                if (!asStartTag.attributes.get("type").equalsIgnoreCase("hidden")) {
                                    return anythingElse(token, htmlTreeBuilder);
                                }
                                htmlTreeBuilder.insertEmpty(asStartTag);
                            } else if (!name.equals("form")) {
                                return anythingElse(token, htmlTreeBuilder);
                            } else {
                                htmlTreeBuilder.error(this);
                                if (htmlTreeBuilder.getFormElement() != null) {
                                    return false;
                                }
                                htmlTreeBuilder.insertForm(asStartTag, false);
                            }
                        }
                    }
                }
                return true;
            } else if (token.isEndTag()) {
                String name2 = token.asEndTag().name();
                if (!name2.equals("table")) {
                    if (!StringUtil.in(name2, TtmlNode.TAG_BODY, "caption", "col", "colgroup", "html", "tbody", "td", "tfoot", "th", "thead", "tr")) {
                        return anythingElse(token, htmlTreeBuilder);
                    }
                    htmlTreeBuilder.error(this);
                    return false;
                } else if (!htmlTreeBuilder.inTableScope(name2)) {
                    htmlTreeBuilder.error(this);
                    return false;
                } else {
                    htmlTreeBuilder.popStackToClose("table");
                    htmlTreeBuilder.resetInsertionMode();
                    return true;
                }
            } else if (!token.isEOF()) {
                return anythingElse(token, htmlTreeBuilder);
            } else {
                if (htmlTreeBuilder.currentElement().nodeName().equals("html")) {
                    htmlTreeBuilder.error(this);
                }
                return true;
            }
        }

        /* access modifiers changed from: package-private */
        public boolean anythingElse(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            htmlTreeBuilder.error(this);
            if (!StringUtil.in(htmlTreeBuilder.currentElement().nodeName(), "table", "tbody", "tfoot", "thead", "tr")) {
                return htmlTreeBuilder.process(token, InBody);
            }
            htmlTreeBuilder.setFosterInserts(true);
            boolean process = htmlTreeBuilder.process(token, InBody);
            htmlTreeBuilder.setFosterInserts(false);
            return process;
        }
    },
    InTableText {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (AnonymousClass24.$SwitchMap$org$jsoup$parser$Token$TokenType[token.type.ordinal()] != 5) {
                if (htmlTreeBuilder.getPendingTableCharacters().size() > 0) {
                    for (String str : htmlTreeBuilder.getPendingTableCharacters()) {
                        if (!HtmlTreeBuilderState.isWhitespace(str)) {
                            htmlTreeBuilder.error(this);
                            if (StringUtil.in(htmlTreeBuilder.currentElement().nodeName(), "table", "tbody", "tfoot", "thead", "tr")) {
                                htmlTreeBuilder.setFosterInserts(true);
                                htmlTreeBuilder.process(new Token.Character().data(str), InBody);
                                htmlTreeBuilder.setFosterInserts(false);
                            } else {
                                htmlTreeBuilder.process(new Token.Character().data(str), InBody);
                            }
                        } else {
                            htmlTreeBuilder.insert(new Token.Character().data(str));
                        }
                    }
                    htmlTreeBuilder.newPendingTableCharacters();
                }
                htmlTreeBuilder.transition(htmlTreeBuilder.originalState());
                return htmlTreeBuilder.process(token);
            }
            Token.Character asCharacter = token.asCharacter();
            if (asCharacter.getData().equals(HtmlTreeBuilderState.nullString)) {
                htmlTreeBuilder.error(this);
                return false;
            }
            htmlTreeBuilder.getPendingTableCharacters().add(asCharacter.getData());
            return true;
        }
    },
    InCaption {
        /* access modifiers changed from: package-private */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x0090, code lost:
            if (org.jsoup.helper.StringUtil.in(r14.asStartTag().name(), "caption", "col", "colgroup", "tbody", "td", "tfoot", "th", "thead", "tr") == false) goto L_0x0092;
         */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (!token.isEndTag() || !token.asEndTag().name().equals("caption")) {
                if (token.isStartTag()) {
                }
                if (!token.isEndTag() || !token.asEndTag().name().equals("table")) {
                    if (token.isEndTag()) {
                        if (StringUtil.in(token.asEndTag().name(), TtmlNode.TAG_BODY, "col", "colgroup", "html", "tbody", "td", "tfoot", "th", "thead", "tr")) {
                            htmlTreeBuilder.error(this);
                            return false;
                        }
                    }
                    return htmlTreeBuilder.process(token, InBody);
                }
                htmlTreeBuilder.error(this);
                if (htmlTreeBuilder.processEndTag("caption")) {
                    return htmlTreeBuilder.process(token);
                }
            } else if (!htmlTreeBuilder.inTableScope(token.asEndTag().name())) {
                htmlTreeBuilder.error(this);
                return false;
            } else {
                htmlTreeBuilder.generateImpliedEndTags();
                if (!htmlTreeBuilder.currentElement().nodeName().equals("caption")) {
                    htmlTreeBuilder.error(this);
                }
                htmlTreeBuilder.popStackToClose("caption");
                htmlTreeBuilder.clearFormattingElementsToLastMarker();
                htmlTreeBuilder.transition(InTable);
            }
            return true;
        }
    },
    InColumnGroup {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (HtmlTreeBuilderState.isWhitespace(token)) {
                htmlTreeBuilder.insert(token.asCharacter());
                return true;
            }
            int i = AnonymousClass24.$SwitchMap$org$jsoup$parser$Token$TokenType[token.type.ordinal()];
            if (i != 6) {
                switch (i) {
                    case 1:
                        htmlTreeBuilder.insert(token.asComment());
                        break;
                    case 2:
                        htmlTreeBuilder.error(this);
                        break;
                    case 3:
                        Token.StartTag asStartTag = token.asStartTag();
                        String name = asStartTag.name();
                        if (name.equals("html")) {
                            return htmlTreeBuilder.process(token, InBody);
                        }
                        if (name.equals("col")) {
                            htmlTreeBuilder.insertEmpty(asStartTag);
                            break;
                        } else {
                            return anythingElse(token, htmlTreeBuilder);
                        }
                    case 4:
                        if (token.asEndTag().name().equals("colgroup")) {
                            if (!htmlTreeBuilder.currentElement().nodeName().equals("html")) {
                                htmlTreeBuilder.pop();
                                htmlTreeBuilder.transition(InTable);
                                break;
                            } else {
                                htmlTreeBuilder.error(this);
                                return false;
                            }
                        } else {
                            return anythingElse(token, htmlTreeBuilder);
                        }
                    default:
                        return anythingElse(token, htmlTreeBuilder);
                }
                return true;
            } else if (htmlTreeBuilder.currentElement().nodeName().equals("html")) {
                return true;
            } else {
                return anythingElse(token, htmlTreeBuilder);
            }
        }

        private boolean anythingElse(Token token, TreeBuilder treeBuilder) {
            if (treeBuilder.processEndTag("colgroup")) {
                return treeBuilder.process(token);
            }
            return true;
        }
    },
    InTableBody {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            switch (AnonymousClass24.$SwitchMap$org$jsoup$parser$Token$TokenType[token.type.ordinal()]) {
                case 3:
                    Token.StartTag asStartTag = token.asStartTag();
                    String name = asStartTag.name();
                    if (name.equals("tr")) {
                        htmlTreeBuilder.clearStackToTableBodyContext();
                        htmlTreeBuilder.insert(asStartTag);
                        htmlTreeBuilder.transition(InRow);
                        break;
                    } else {
                        if (StringUtil.in(name, "th", "td")) {
                            htmlTreeBuilder.error(this);
                            htmlTreeBuilder.processStartTag("tr");
                            return htmlTreeBuilder.process(asStartTag);
                        }
                        if (StringUtil.in(name, "caption", "col", "colgroup", "tbody", "tfoot", "thead")) {
                            return exitTableBody(token, htmlTreeBuilder);
                        }
                        return anythingElse(token, htmlTreeBuilder);
                    }
                case 4:
                    String name2 = token.asEndTag().name();
                    if (StringUtil.in(name2, "tbody", "tfoot", "thead")) {
                        if (htmlTreeBuilder.inTableScope(name2)) {
                            htmlTreeBuilder.clearStackToTableBodyContext();
                            htmlTreeBuilder.pop();
                            htmlTreeBuilder.transition(InTable);
                            break;
                        } else {
                            htmlTreeBuilder.error(this);
                            return false;
                        }
                    } else if (name2.equals("table")) {
                        return exitTableBody(token, htmlTreeBuilder);
                    } else {
                        if (!StringUtil.in(name2, TtmlNode.TAG_BODY, "caption", "col", "colgroup", "html", "td", "th", "tr")) {
                            return anythingElse(token, htmlTreeBuilder);
                        }
                        htmlTreeBuilder.error(this);
                        return false;
                    }
                default:
                    return anythingElse(token, htmlTreeBuilder);
            }
            return true;
        }

        private boolean exitTableBody(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (htmlTreeBuilder.inTableScope("tbody") || htmlTreeBuilder.inTableScope("thead") || htmlTreeBuilder.inScope("tfoot")) {
                htmlTreeBuilder.clearStackToTableBodyContext();
                htmlTreeBuilder.processEndTag(htmlTreeBuilder.currentElement().nodeName());
                return htmlTreeBuilder.process(token);
            }
            htmlTreeBuilder.error(this);
            return false;
        }

        private boolean anythingElse(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            return htmlTreeBuilder.process(token, InTable);
        }
    },
    InRow {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (token.isStartTag()) {
                Token.StartTag asStartTag = token.asStartTag();
                String name = asStartTag.name();
                if (StringUtil.in(name, "th", "td")) {
                    htmlTreeBuilder.clearStackToTableRowContext();
                    htmlTreeBuilder.insert(asStartTag);
                    htmlTreeBuilder.transition(InCell);
                    htmlTreeBuilder.insertMarkerToFormattingElements();
                } else {
                    if (StringUtil.in(name, "caption", "col", "colgroup", "tbody", "tfoot", "thead", "tr")) {
                        return handleMissingTr(token, htmlTreeBuilder);
                    }
                    return anythingElse(token, htmlTreeBuilder);
                }
            } else if (!token.isEndTag()) {
                return anythingElse(token, htmlTreeBuilder);
            } else {
                String name2 = token.asEndTag().name();
                if (name2.equals("tr")) {
                    if (!htmlTreeBuilder.inTableScope(name2)) {
                        htmlTreeBuilder.error(this);
                        return false;
                    }
                    htmlTreeBuilder.clearStackToTableRowContext();
                    htmlTreeBuilder.pop();
                    htmlTreeBuilder.transition(InTableBody);
                } else if (name2.equals("table")) {
                    return handleMissingTr(token, htmlTreeBuilder);
                } else {
                    if (!StringUtil.in(name2, "tbody", "tfoot", "thead")) {
                        if (!StringUtil.in(name2, TtmlNode.TAG_BODY, "caption", "col", "colgroup", "html", "td", "th")) {
                            return anythingElse(token, htmlTreeBuilder);
                        }
                        htmlTreeBuilder.error(this);
                        return false;
                    } else if (!htmlTreeBuilder.inTableScope(name2)) {
                        htmlTreeBuilder.error(this);
                        return false;
                    } else {
                        htmlTreeBuilder.processEndTag("tr");
                        return htmlTreeBuilder.process(token);
                    }
                }
            }
            return true;
        }

        private boolean anythingElse(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            return htmlTreeBuilder.process(token, InTable);
        }

        private boolean handleMissingTr(Token token, TreeBuilder treeBuilder) {
            if (treeBuilder.processEndTag("tr")) {
                return treeBuilder.process(token);
            }
            return false;
        }
    },
    InCell {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (token.isEndTag()) {
                String name = token.asEndTag().name();
                if (!StringUtil.in(name, "td", "th")) {
                    if (StringUtil.in(name, TtmlNode.TAG_BODY, "caption", "col", "colgroup", "html")) {
                        htmlTreeBuilder.error(this);
                        return false;
                    }
                    if (!StringUtil.in(name, "table", "tbody", "tfoot", "thead", "tr")) {
                        return anythingElse(token, htmlTreeBuilder);
                    }
                    if (!htmlTreeBuilder.inTableScope(name)) {
                        htmlTreeBuilder.error(this);
                        return false;
                    }
                    closeCell(htmlTreeBuilder);
                    return htmlTreeBuilder.process(token);
                } else if (!htmlTreeBuilder.inTableScope(name)) {
                    htmlTreeBuilder.error(this);
                    htmlTreeBuilder.transition(InRow);
                    return false;
                } else {
                    htmlTreeBuilder.generateImpliedEndTags();
                    if (!htmlTreeBuilder.currentElement().nodeName().equals(name)) {
                        htmlTreeBuilder.error(this);
                    }
                    htmlTreeBuilder.popStackToClose(name);
                    htmlTreeBuilder.clearFormattingElementsToLastMarker();
                    htmlTreeBuilder.transition(InRow);
                    return true;
                }
            } else {
                if (token.isStartTag()) {
                    if (StringUtil.in(token.asStartTag().name(), "caption", "col", "colgroup", "tbody", "td", "tfoot", "th", "thead", "tr")) {
                        if (htmlTreeBuilder.inTableScope("td") || htmlTreeBuilder.inTableScope("th")) {
                            closeCell(htmlTreeBuilder);
                            return htmlTreeBuilder.process(token);
                        }
                        htmlTreeBuilder.error(this);
                        return false;
                    }
                }
                return anythingElse(token, htmlTreeBuilder);
            }
        }

        private boolean anythingElse(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            return htmlTreeBuilder.process(token, InBody);
        }

        private void closeCell(HtmlTreeBuilder htmlTreeBuilder) {
            if (htmlTreeBuilder.inTableScope("td")) {
                htmlTreeBuilder.processEndTag("td");
            } else {
                htmlTreeBuilder.processEndTag("th");
            }
        }
    },
    InSelect {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            switch (AnonymousClass24.$SwitchMap$org$jsoup$parser$Token$TokenType[token.type.ordinal()]) {
                case 1:
                    htmlTreeBuilder.insert(token.asComment());
                    break;
                case 2:
                    htmlTreeBuilder.error(this);
                    return false;
                case 3:
                    Token.StartTag asStartTag = token.asStartTag();
                    String name = asStartTag.name();
                    if (name.equals("html")) {
                        return htmlTreeBuilder.process(asStartTag, InBody);
                    }
                    if (name.equals("option")) {
                        htmlTreeBuilder.processEndTag("option");
                        htmlTreeBuilder.insert(asStartTag);
                        break;
                    } else if (name.equals("optgroup")) {
                        if (htmlTreeBuilder.currentElement().nodeName().equals("option")) {
                            htmlTreeBuilder.processEndTag("option");
                        } else if (htmlTreeBuilder.currentElement().nodeName().equals("optgroup")) {
                            htmlTreeBuilder.processEndTag("optgroup");
                        }
                        htmlTreeBuilder.insert(asStartTag);
                        break;
                    } else if (name.equals("select")) {
                        htmlTreeBuilder.error(this);
                        return htmlTreeBuilder.processEndTag("select");
                    } else {
                        if (StringUtil.in(name, "input", "keygen", "textarea")) {
                            htmlTreeBuilder.error(this);
                            if (!htmlTreeBuilder.inSelectScope("select")) {
                                return false;
                            }
                            htmlTreeBuilder.processEndTag("select");
                            return htmlTreeBuilder.process(asStartTag);
                        } else if (name.equals("script")) {
                            return htmlTreeBuilder.process(token, InHead);
                        } else {
                            return anythingElse(token, htmlTreeBuilder);
                        }
                    }
                case 4:
                    String name2 = token.asEndTag().name();
                    if (name2.equals("optgroup")) {
                        if (htmlTreeBuilder.currentElement().nodeName().equals("option") && htmlTreeBuilder.aboveOnStack(htmlTreeBuilder.currentElement()) != null && htmlTreeBuilder.aboveOnStack(htmlTreeBuilder.currentElement()).nodeName().equals("optgroup")) {
                            htmlTreeBuilder.processEndTag("option");
                        }
                        if (!htmlTreeBuilder.currentElement().nodeName().equals("optgroup")) {
                            htmlTreeBuilder.error(this);
                            break;
                        } else {
                            htmlTreeBuilder.pop();
                            break;
                        }
                    } else if (name2.equals("option")) {
                        if (!htmlTreeBuilder.currentElement().nodeName().equals("option")) {
                            htmlTreeBuilder.error(this);
                            break;
                        } else {
                            htmlTreeBuilder.pop();
                            break;
                        }
                    } else if (name2.equals("select")) {
                        if (htmlTreeBuilder.inSelectScope(name2)) {
                            htmlTreeBuilder.popStackToClose(name2);
                            htmlTreeBuilder.resetInsertionMode();
                            break;
                        } else {
                            htmlTreeBuilder.error(this);
                            return false;
                        }
                    } else {
                        return anythingElse(token, htmlTreeBuilder);
                    }
                case 5:
                    Token.Character asCharacter = token.asCharacter();
                    if (!asCharacter.getData().equals(HtmlTreeBuilderState.nullString)) {
                        htmlTreeBuilder.insert(asCharacter);
                        break;
                    } else {
                        htmlTreeBuilder.error(this);
                        return false;
                    }
                case 6:
                    if (!htmlTreeBuilder.currentElement().nodeName().equals("html")) {
                        htmlTreeBuilder.error(this);
                        break;
                    }
                    break;
                default:
                    return anythingElse(token, htmlTreeBuilder);
            }
            return true;
        }

        private boolean anythingElse(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            htmlTreeBuilder.error(this);
            return false;
        }
    },
    InSelectInTable {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (token.isStartTag()) {
                if (StringUtil.in(token.asStartTag().name(), "caption", "table", "tbody", "tfoot", "thead", "tr", "td", "th")) {
                    htmlTreeBuilder.error(this);
                    htmlTreeBuilder.processEndTag("select");
                    return htmlTreeBuilder.process(token);
                }
            }
            if (token.isEndTag()) {
                if (StringUtil.in(token.asEndTag().name(), "caption", "table", "tbody", "tfoot", "thead", "tr", "td", "th")) {
                    htmlTreeBuilder.error(this);
                    if (!htmlTreeBuilder.inTableScope(token.asEndTag().name())) {
                        return false;
                    }
                    htmlTreeBuilder.processEndTag("select");
                    return htmlTreeBuilder.process(token);
                }
            }
            return htmlTreeBuilder.process(token, InSelect);
        }
    },
    AfterBody {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (HtmlTreeBuilderState.isWhitespace(token)) {
                return htmlTreeBuilder.process(token, InBody);
            }
            if (token.isComment()) {
                htmlTreeBuilder.insert(token.asComment());
                return true;
            } else if (token.isDoctype()) {
                htmlTreeBuilder.error(this);
                return false;
            } else if (token.isStartTag() && token.asStartTag().name().equals("html")) {
                return htmlTreeBuilder.process(token, InBody);
            } else {
                if (!token.isEndTag() || !token.asEndTag().name().equals("html")) {
                    if (token.isEOF()) {
                        return true;
                    }
                    htmlTreeBuilder.error(this);
                    htmlTreeBuilder.transition(InBody);
                    return htmlTreeBuilder.process(token);
                } else if (htmlTreeBuilder.isFragmentParsing()) {
                    htmlTreeBuilder.error(this);
                    return false;
                } else {
                    htmlTreeBuilder.transition(AfterAfterBody);
                    return true;
                }
            }
        }
    },
    InFrameset {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (HtmlTreeBuilderState.isWhitespace(token)) {
                htmlTreeBuilder.insert(token.asCharacter());
            } else if (token.isComment()) {
                htmlTreeBuilder.insert(token.asComment());
            } else if (token.isDoctype()) {
                htmlTreeBuilder.error(this);
                return false;
            } else if (token.isStartTag()) {
                Token.StartTag asStartTag = token.asStartTag();
                String name = asStartTag.name();
                if (name.equals("html")) {
                    return htmlTreeBuilder.process(asStartTag, InBody);
                }
                if (name.equals("frameset")) {
                    htmlTreeBuilder.insert(asStartTag);
                } else if (name.equals("frame")) {
                    htmlTreeBuilder.insertEmpty(asStartTag);
                } else if (name.equals("noframes")) {
                    return htmlTreeBuilder.process(asStartTag, InHead);
                } else {
                    htmlTreeBuilder.error(this);
                    return false;
                }
            } else if (!token.isEndTag() || !token.asEndTag().name().equals("frameset")) {
                if (!token.isEOF()) {
                    htmlTreeBuilder.error(this);
                    return false;
                } else if (!htmlTreeBuilder.currentElement().nodeName().equals("html")) {
                    htmlTreeBuilder.error(this);
                    return true;
                }
            } else if (htmlTreeBuilder.currentElement().nodeName().equals("html")) {
                htmlTreeBuilder.error(this);
                return false;
            } else {
                htmlTreeBuilder.pop();
                if (!htmlTreeBuilder.isFragmentParsing() && !htmlTreeBuilder.currentElement().nodeName().equals("frameset")) {
                    htmlTreeBuilder.transition(AfterFrameset);
                }
            }
            return true;
        }
    },
    AfterFrameset {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (HtmlTreeBuilderState.isWhitespace(token)) {
                htmlTreeBuilder.insert(token.asCharacter());
                return true;
            } else if (token.isComment()) {
                htmlTreeBuilder.insert(token.asComment());
                return true;
            } else if (token.isDoctype()) {
                htmlTreeBuilder.error(this);
                return false;
            } else if (token.isStartTag() && token.asStartTag().name().equals("html")) {
                return htmlTreeBuilder.process(token, InBody);
            } else {
                if (token.isEndTag() && token.asEndTag().name().equals("html")) {
                    htmlTreeBuilder.transition(AfterAfterFrameset);
                    return true;
                } else if (token.isStartTag() && token.asStartTag().name().equals("noframes")) {
                    return htmlTreeBuilder.process(token, InHead);
                } else {
                    if (token.isEOF()) {
                        return true;
                    }
                    htmlTreeBuilder.error(this);
                    return false;
                }
            }
        }
    },
    AfterAfterBody {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (token.isComment()) {
                htmlTreeBuilder.insert(token.asComment());
                return true;
            } else if (token.isDoctype() || HtmlTreeBuilderState.isWhitespace(token) || (token.isStartTag() && token.asStartTag().name().equals("html"))) {
                return htmlTreeBuilder.process(token, InBody);
            } else {
                if (token.isEOF()) {
                    return true;
                }
                htmlTreeBuilder.error(this);
                htmlTreeBuilder.transition(InBody);
                return htmlTreeBuilder.process(token);
            }
        }
    },
    AfterAfterFrameset {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            if (token.isComment()) {
                htmlTreeBuilder.insert(token.asComment());
                return true;
            } else if (token.isDoctype() || HtmlTreeBuilderState.isWhitespace(token) || (token.isStartTag() && token.asStartTag().name().equals("html"))) {
                return htmlTreeBuilder.process(token, InBody);
            } else {
                if (token.isEOF()) {
                    return true;
                }
                if (token.isStartTag() && token.asStartTag().name().equals("noframes")) {
                    return htmlTreeBuilder.process(token, InHead);
                }
                htmlTreeBuilder.error(this);
                return false;
            }
        }
    },
    ForeignContent {
        /* access modifiers changed from: package-private */
        @Override // org.jsoup.parser.HtmlTreeBuilderState
        public boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder) {
            return true;
        }
    };
    
    private static String nullString = String.valueOf((char) 0);

    /* access modifiers changed from: package-private */
    public abstract boolean process(Token token, HtmlTreeBuilder htmlTreeBuilder);

    /* access modifiers changed from: private */
    public static boolean isWhitespace(Token token) {
        if (token.isCharacter()) {
            return isWhitespace(token.asCharacter().getData());
        }
        return false;
    }

    /* access modifiers changed from: private */
    public static boolean isWhitespace(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (!StringUtil.isWhitespace(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /* access modifiers changed from: private */
    public static void handleRcData(Token.StartTag startTag, HtmlTreeBuilder htmlTreeBuilder) {
        htmlTreeBuilder.insert(startTag);
        htmlTreeBuilder.tokeniser.transition(TokeniserState.Rcdata);
        htmlTreeBuilder.markInsertionMode();
        htmlTreeBuilder.transition(Text);
    }

    /* access modifiers changed from: private */
    public static void handleRawtext(Token.StartTag startTag, HtmlTreeBuilder htmlTreeBuilder) {
        htmlTreeBuilder.insert(startTag);
        htmlTreeBuilder.tokeniser.transition(TokeniserState.Rawtext);
        htmlTreeBuilder.markInsertionMode();
        htmlTreeBuilder.transition(Text);
    }

    private static final class Constants {
        private static final String[] DdDt = {"dd", "dt"};
        private static final String[] Formatters = {"b", "big", "code", "em", "font", "i", "s", SoundCloudArtworkHelper.SMALL, "strike", "strong", TtmlNode.TAG_TT, "u"};
        private static final String[] Headings = {"h1", "h2", "h3", "h4", "h5", "h6"};
        private static final String[] InBodyEndAdoptionFormatters = {"a", "b", "big", "code", "em", "font", "i", "nobr", "s", SoundCloudArtworkHelper.SMALL, "strike", "strong", TtmlNode.TAG_TT, "u"};
        private static final String[] InBodyEndClosers = {"address", "article", "aside", "blockquote", "button", TtmlNode.CENTER, "details", "dir", TtmlNode.TAG_DIV, "dl", "fieldset", "figcaption", "figure", "footer", "header", "hgroup", "listing", "menu", "nav", "ol", "pre", "section", "summary", "ul"};
        private static final String[] InBodyEndTableFosters = {"table", "tbody", "tfoot", "thead", "tr"};
        private static final String[] InBodyStartApplets = {"applet", "marquee", "object"};
        private static final String[] InBodyStartDrop = {"caption", "col", "colgroup", "frame", TtmlNode.TAG_HEAD, "tbody", "td", "tfoot", "th", "thead", "tr"};
        private static final String[] InBodyStartEmptyFormatters = {"area", TtmlNode.TAG_BR, "embed", "img", "keygen", "wbr"};
        private static final String[] InBodyStartInputAttribs = {"name", "action", SettingsJsonConstants.PROMPT_KEY};
        private static final String[] InBodyStartLiBreakers = {"address", TtmlNode.TAG_DIV, TtmlNode.TAG_P};
        private static final String[] InBodyStartMedia = {"param", FirebaseAnalytics.Param.SOURCE, "track"};
        private static final String[] InBodyStartOptions = {"optgroup", "option"};
        private static final String[] InBodyStartPClosers = {"address", "article", "aside", "blockquote", TtmlNode.CENTER, "details", "dir", TtmlNode.TAG_DIV, "dl", "fieldset", "figcaption", "figure", "footer", "header", "hgroup", "menu", "nav", "ol", TtmlNode.TAG_P, "section", "summary", "ul"};
        private static final String[] InBodyStartPreListing = {"pre", "listing"};
        private static final String[] InBodyStartRuby = {"rp", "rt"};
        private static final String[] InBodyStartToHead = {"base", "basefont", "bgsound", "command", "link", "meta", "noframes", "script", TtmlNode.TAG_STYLE, "title"};

        private Constants() {
        }
    }
}

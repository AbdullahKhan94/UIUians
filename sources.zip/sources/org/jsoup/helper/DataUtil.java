package org.jsoup.helper;

import com.google.firebase.analytics.FirebaseAnalytics;
import io.fabric.sdk.android.services.network.HttpRequest;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.IllegalCharsetNameException;
import java.util.Locale;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;

public final class DataUtil {
    private static final int UNICODE_BOM = 65279;
    static final int boundaryLength = 32;
    private static final int bufferSize = 131072;
    private static final Pattern charsetPattern = Pattern.compile("(?i)\\bcharset=\\s*(?:\"|')?([^\\s,;\"']*)");
    static final String defaultCharset = "UTF-8";
    private static final char[] mimeBoundaryChars = "-_1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();

    private DataUtil() {
    }

    public static Document load(File file, String str, String str2) throws IOException {
        return parseByteData(readFileToByteBuffer(file), str, str2, Parser.htmlParser());
    }

    public static Document load(InputStream inputStream, String str, String str2) throws IOException {
        return parseByteData(readToByteBuffer(inputStream), str, str2, Parser.htmlParser());
    }

    public static Document load(InputStream inputStream, String str, String str2, Parser parser) throws IOException {
        return parseByteData(readToByteBuffer(inputStream), str, str2, parser);
    }

    static void crossStreams(InputStream inputStream, OutputStream outputStream) throws IOException {
        byte[] bArr = new byte[131072];
        while (true) {
            int read = inputStream.read(bArr);
            if (read != -1) {
                outputStream.write(bArr, 0, read);
            } else {
                return;
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x00bf  */
    /* JADX WARNING: Removed duplicated region for block: B:36:? A[RETURN, SYNTHETIC] */
    static Document parseByteData(ByteBuffer byteBuffer, String str, String str2, Parser parser) {
        Document document;
        String str3;
        String str4;
        Document document2 = null;
        if (str == null) {
            str3 = Charset.forName("UTF-8").decode(byteBuffer).toString();
            document = parser.parseInput(str3, str2);
            Element first = document.select("meta[http-equiv=content-type], meta[charset]").first();
            if (first != null) {
                String charsetFromContentType = first.hasAttr("http-equiv") ? getCharsetFromContentType(first.attr(FirebaseAnalytics.Param.CONTENT)) : null;
                if (charsetFromContentType == null && first.hasAttr(HttpRequest.PARAM_CHARSET)) {
                    try {
                        if (Charset.isSupported(first.attr(HttpRequest.PARAM_CHARSET))) {
                            str4 = first.attr(HttpRequest.PARAM_CHARSET);
                            if (!(str4 == null || str4.length() == 0 || str4.equals("UTF-8"))) {
                                str = str4.trim().replaceAll("[\"']", "");
                                byteBuffer.rewind();
                                str3 = Charset.forName(str).decode(byteBuffer).toString();
                            }
                        }
                    } catch (IllegalCharsetNameException unused) {
                        str4 = null;
                    }
                }
                str4 = charsetFromContentType;
                str = str4.trim().replaceAll("[\"']", "");
                byteBuffer.rewind();
                str3 = Charset.forName(str).decode(byteBuffer).toString();
            }
            if (str3.length() > 0 || str3.charAt(0) != UNICODE_BOM) {
                document2 = document;
            } else {
                byteBuffer.rewind();
                str3 = Charset.forName("UTF-8").decode(byteBuffer).toString().substring(1);
                str = "UTF-8";
            }
            if (document2 == null) {
                return document2;
            }
            Document parseInput = parser.parseInput(str3, str2);
            parseInput.outputSettings().charset(str);
            return parseInput;
        }
        Validate.notEmpty(str, "Must set charset arg to character set of file to parse. Set to null to attempt to detect from HTML");
        str3 = Charset.forName(str).decode(byteBuffer).toString();
        document = null;
        if (str3.length() > 0) {
        }
        document2 = document;
        if (document2 == null) {
        }
    }

    static ByteBuffer readToByteBuffer(InputStream inputStream, int i) throws IOException {
        boolean z = true;
        Validate.isTrue(i >= 0, "maxSize must be 0 (unlimited) or larger");
        if (i <= 0) {
            z = false;
        }
        byte[] bArr = new byte[131072];
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(131072);
        while (true) {
            int read = inputStream.read(bArr);
            if (read == -1) {
                break;
            }
            if (z) {
                if (read > i) {
                    byteArrayOutputStream.write(bArr, 0, i);
                    break;
                }
                i -= read;
            }
            byteArrayOutputStream.write(bArr, 0, read);
        }
        return ByteBuffer.wrap(byteArrayOutputStream.toByteArray());
    }

    static ByteBuffer readToByteBuffer(InputStream inputStream) throws IOException {
        return readToByteBuffer(inputStream, 0);
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0022  */
    static ByteBuffer readFileToByteBuffer(File file) throws IOException {
        Throwable th;
        RandomAccessFile randomAccessFile;
        try {
            randomAccessFile = new RandomAccessFile(file, "r");
            try {
                byte[] bArr = new byte[((int) randomAccessFile.length())];
                randomAccessFile.readFully(bArr);
                ByteBuffer wrap = ByteBuffer.wrap(bArr);
                if (randomAccessFile != null) {
                    randomAccessFile.close();
                }
                return wrap;
            } catch (Throwable th2) {
                th = th2;
                if (randomAccessFile != null) {
                    randomAccessFile.close();
                }
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            randomAccessFile = null;
            if (randomAccessFile != null) {
            }
            throw th;
        }
    }

    static ByteBuffer emptyByteBuffer() {
        return ByteBuffer.allocate(0);
    }

    static String getCharsetFromContentType(String str) {
        if (str == null) {
            return null;
        }
        Matcher matcher = charsetPattern.matcher(str);
        if (matcher.find()) {
            String replace = matcher.group(1).trim().replace("charset=", "");
            if (replace.length() == 0) {
                return null;
            }
            try {
                if (Charset.isSupported(replace)) {
                    return replace;
                }
                String upperCase = replace.toUpperCase(Locale.ENGLISH);
                if (Charset.isSupported(upperCase)) {
                    return upperCase;
                }
            } catch (IllegalCharsetNameException unused) {
                return null;
            }
        }
        return null;
    }

    static String mimeBoundary() {
        StringBuilder sb = new StringBuilder(32);
        Random random = new Random();
        for (int i = 0; i < 32; i++) {
            sb.append(mimeBoundaryChars[random.nextInt(mimeBoundaryChars.length)]);
        }
        return sb.toString();
    }
}

package com.thedaw.uiuians;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class SplashScreen extends AppCompatActivity {
    /* access modifiers changed from: protected */
    @Override // android.support.v7.app.AppCompatActivity, android.support.v4.app.SupportActivity, android.support.v4.app.FragmentActivity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash_screen);
        new Thread() {
            /* class com.thedaw.uiuians.SplashScreen.AnonymousClass1 */

            public void run() {
                try {
                    sleep(3000);
                    SplashScreen.this.startActivity(new Intent(SplashScreen.this.getApplicationContext(), MainActivity.class));
                    SplashScreen.this.finish();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
}

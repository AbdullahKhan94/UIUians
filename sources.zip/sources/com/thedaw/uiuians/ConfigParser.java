package com.thedaw.uiuians;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import com.thedaw.uiuians.drawer.NavItem;
import com.thedaw.uiuians.drawer.SimpleMenu;
import com.thedaw.uiuians.drawer.SimpleSubMenu;
import com.thedaw.uiuians.providers.CustomIntent;
import com.thedaw.uiuians.providers.facebook.FacebookFragment;
import com.thedaw.uiuians.providers.flickr.ui.FlickrFragment;
import com.thedaw.uiuians.providers.instagram.InstagramFragment;
import com.thedaw.uiuians.providers.maps.MapsFragment;
import com.thedaw.uiuians.providers.overview.ui.OverviewFragment;
import com.thedaw.uiuians.providers.pinterest.PinterestFragment;
import com.thedaw.uiuians.providers.radio.ui.RadioFragment;
import com.thedaw.uiuians.providers.rss.ui.RssFragment;
import com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment;
import com.thedaw.uiuians.providers.tumblr.ui.TumblrFragment;
import com.thedaw.uiuians.providers.tv.TvFragment;
import com.thedaw.uiuians.providers.twitter.ui.TweetsFragment;
import com.thedaw.uiuians.providers.web.WebviewFragment;
import com.thedaw.uiuians.providers.woocommerce.ui.OrdersFragment;
import com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment;
import com.thedaw.uiuians.providers.wordpress.ui.WordpressFragment;
import com.thedaw.uiuians.providers.youtube.ui.YoutubeFragment;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ConfigParser extends AsyncTask<Void, Void, Void> {
    private static String CACHE_FILE = "menuCache.srl";
    private static JSONArray jsonMenu;
    final long MAX_FILE_AGE = 172800000;
    private CallBack callback;
    private Activity context;
    private boolean facedException;
    private SimpleMenu menu;
    private String sourceLocation;

    public interface CallBack {
        void configLoaded(boolean z);
    }

    public ConfigParser(String str, SimpleMenu simpleMenu, Activity activity, CallBack callBack) {
        this.sourceLocation = str;
        this.context = activity;
        this.menu = simpleMenu;
        this.callback = callBack;
    }

    /* access modifiers changed from: protected */
    public void onPreExecute() {
        super.onPreExecute();
    }

    /* access modifiers changed from: protected */
    public Void doInBackground(Void... voidArr) {
        if (jsonMenu == null) {
            try {
                if (this.sourceLocation.contains("http")) {
                    jsonMenu = getJSONFromCache();
                    if (getJSONFromCache() == null) {
                        Log.v("INFO", "Loading Menu Config from url.");
                        String dataFromUrl = Helper.getDataFromUrl(this.sourceLocation);
                        jsonMenu = new JSONArray(dataFromUrl);
                        saveJSONToCache(dataFromUrl);
                    } else {
                        Log.v("INFO", "Loading Menu Config from cache.");
                    }
                } else {
                    jsonMenu = new JSONArray(Helper.loadJSONFromAsset(this.context, this.sourceLocation));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        if (jsonMenu != null) {
            final JSONArray jSONArray = jsonMenu;
            this.context.runOnUiThread(new Runnable() {
                /* class com.thedaw.uiuians.ConfigParser.AnonymousClass1 */

                public void run() {
                    SimpleSubMenu simpleSubMenu = null;
                    for (int i = 0; i < jSONArray.length(); i++) {
                        try {
                            JSONObject jSONObject = jSONArray.getJSONObject(i);
                            String string = jSONObject.getString("title");
                            int drawableByName = (!jSONObject.has("drawable") || jSONObject.getString("drawable") == null || jSONObject.getString("drawable").isEmpty() || jSONObject.getString("drawable").equals("0")) ? 0 : ConfigParser.getDrawableByName(ConfigParser.this.context, jSONObject.getString("drawable"));
                            if (!jSONObject.has("submenu") || jSONObject.getString("submenu") == null || jSONObject.getString("submenu").isEmpty()) {
                                simpleSubMenu = null;
                            } else {
                                String string2 = jSONObject.getString("submenu");
                                if (simpleSubMenu == null || !simpleSubMenu.getSubMenuTitle().equals(string2)) {
                                    simpleSubMenu = new SimpleSubMenu(ConfigParser.this.menu, string2);
                                }
                            }
                            boolean z = jSONObject.has("iap") && jSONObject.getBoolean("iap");
                            ArrayList arrayList = new ArrayList();
                            JSONArray jSONArray = jSONObject.getJSONArray("tabs");
                            for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                                arrayList.add(ConfigParser.navItemFromJSON(ConfigParser.this.context, jSONArray.getJSONObject(i2)));
                            }
                            if (simpleSubMenu != null) {
                                simpleSubMenu.add(string, drawableByName, arrayList, z);
                            } else {
                                ConfigParser.this.menu.add(string, drawableByName, arrayList, z);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.e("INFO", "JSON was invalid");
                            ConfigParser.this.facedException = true;
                            return;
                        }
                    }
                }
            });
            return null;
        }
        Log.e("INFO", "JSON Could not be retrieved");
        this.facedException = true;
        return null;
    }

    public static NavItem navItemFromJSON(Context context2, JSONObject jSONObject) throws JSONException {
        Class cls;
        String string = jSONObject.getString("title");
        String string2 = jSONObject.getString("provider");
        JSONArray jSONArray = jSONObject.getJSONArray("arguments");
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            arrayList.add(jSONArray.getString(i));
        }
        if (string2.equals("wordpress")) {
            cls = WordpressFragment.class;
        } else if (string2.equals("facebook")) {
            cls = FacebookFragment.class;
        } else if (string2.equals("rss")) {
            cls = RssFragment.class;
        } else if (string2.equals("youtube")) {
            cls = YoutubeFragment.class;
        } else if (string2.equals("instagram")) {
            cls = InstagramFragment.class;
        } else if (string2.equals("webview")) {
            cls = WebviewFragment.class;
        } else if (string2.equals("tumblr")) {
            cls = TumblrFragment.class;
        } else if (string2.equals("flickr")) {
            cls = FlickrFragment.class;
        } else if (string2.equals("stream")) {
            cls = TvFragment.class;
        } else if (string2.equals("soundcloud") || string2.equals("wordpress_audio")) {
            if (string2.equals("wordpress_audio")) {
                arrayList.add("wordpress");
            }
            cls = SoundCloudFragment.class;
        } else if (string2.equals("maps")) {
            cls = MapsFragment.class;
        } else if (string2.equals("twitter")) {
            cls = TweetsFragment.class;
        } else if (string2.equals("radio")) {
            cls = RadioFragment.class;
        } else if (string2.equals("pinterest")) {
            cls = PinterestFragment.class;
        } else if (string2.equals("woocommerce") && jSONArray.get(0) != null && jSONArray.get(0).equals("orders")) {
            cls = OrdersFragment.class;
        } else if (string2.equals("woocommerce")) {
            cls = WooCommerceFragment.class;
        } else if (string2.equals("custom")) {
            cls = CustomIntent.class;
        } else if (string2.equals("overview")) {
            cls = OverviewFragment.class;
        } else {
            throw new RuntimeException("Invalid type specified for tab");
        }
        NavItem navItem = new NavItem(string, cls, (String[]) arrayList.toArray(new String[0]));
        if (jSONObject.has("image") && jSONObject.getString("image") != null && !jSONObject.getString("image").isEmpty()) {
            if (!jSONObject.getString("image").startsWith("http")) {
                navItem.setTabIcon(getDrawableByName(context2, jSONObject.getString("image")));
            } else {
                navItem.setCategoryImageUrl(jSONObject.getString("image"));
            }
        }
        return navItem;
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(Void r2) {
        if (this.callback != null) {
            this.callback.configLoaded(this.facedException);
        }
    }

    /* access modifiers changed from: private */
    public static int getDrawableByName(Context context2, String str) {
        return context2.getResources().getIdentifier(str, "drawable", context2.getPackageName());
    }

    public void saveJSONToCache(String str) {
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(new File(this.context.getCacheDir(), "") + CACHE_FILE));
            objectOutputStream.writeObject(str);
            objectOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private JSONArray getJSONFromCache() {
        try {
            File file = new File(new File(this.context.getCacheDir(), "") + CACHE_FILE);
            ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(file));
            String str = (String) objectInputStream.readObject();
            objectInputStream.close();
            if (file.lastModified() + 172800000 > System.currentTimeMillis()) {
                return new JSONArray(str);
            }
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (ClassNotFoundException e2) {
            e2.printStackTrace();
            return null;
        } catch (JSONException e3) {
            e3.printStackTrace();
            return null;
        }
    }
}

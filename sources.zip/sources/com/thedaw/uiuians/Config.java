package com.thedaw.uiuians;

import com.thedaw.uiuians.ConfigParser;
import com.thedaw.uiuians.drawer.SimpleMenu;

public class Config {
    public static final boolean ADMOB_YOUTUBE = false;
    public static int BACKGROUND_IMAGE_ID = 2131230940;
    public static boolean BOTTOM_TABS = false;
    public static final String CONFIG_URL = "";
    public static final boolean DRAWER_OPEN_START = false;
    public static final boolean EDITABLE_VIEWMODE = false;
    public static final boolean FORCE_HIDE_NAVIGATION = true;
    public static final boolean HIDE_DRAWER = false;
    public static final boolean HIDE_TOOLBAR = false;
    public static final int INTERSTITIAL_INTERVAL = 2;
    public static boolean LIGHT_TOOLBAR_THEME = false;
    public static final boolean OPEN_EXPLICIT_EXTERNAL = false;
    public static final boolean OPEN_INLINE_EXTERNAL = false;
    public static final int RSS_ROW_MODE = 2;
    public static final boolean TABLET_LAYOUT = true;
    public static boolean USE_HARDCODED_CONFIG = false;
    public static boolean VISUALIZER_ENABLED = true;
    public static final boolean WC_CHIPS = true;
    public static final String WC_CURRENCY = "$";
    public static final int WC_ROW_MODE = 1;
    public static final boolean WEBVIEW_GEOLOCATION = false;
    public static final boolean WP_ATTACHMENTS_BUTTON = false;
    public static final boolean WP_CHIPS = true;
    public static final int WP_ROW_MODE = 1;
    public static final int YT_ROW_MODE = 1;

    public static void configureMenu(SimpleMenu simpleMenu, ConfigParser.CallBack callBack) {
        callBack.configLoaded(false);
    }
}

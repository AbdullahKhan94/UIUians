package com.thedaw.uiuians;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceCategory;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.support.v4.preference.PreferenceFragment;
import android.text.Html;
import android.widget.Toast;
import com.google.android.gms.oss.licenses.OssLicensesMenuActivity;
import com.thedaw.uiuians.billing.BillingProcessor;
import com.thedaw.uiuians.billing.TransactionDetails;
import com.thedaw.uiuians.util.Log;

public class SettingsFragment extends PreferenceFragment implements BillingProcessor.IBillingHandler {
    private static String PRODUCT_ID_BOUGHT = "item_1_bought";
    public static String SHOW_DIALOG = "show_dialog";
    boolean HIDE_RATE_MY_APP = false;
    private BillingProcessor bp;
    private AlertDialog dialog;
    private Preference preferencepurchase;

    @Override // com.thedaw.uiuians.billing.BillingProcessor.IBillingHandler
    public void onBillingInitialized() {
    }

    @Override // android.support.v4.preference.PreferenceFragment, android.support.v4.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        addPreferencesFromResource(R.xml.activity_settings);
        findPreference("rate").setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            /* class com.thedaw.uiuians.SettingsFragment.AnonymousClass1 */

            public boolean onPreferenceClick(Preference preference) {
                try {
                    SettingsFragment.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + SettingsFragment.this.getActivity().getPackageName())));
                    return true;
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(SettingsFragment.this.getActivity(), "Could not open Play Store", 0).show();
                    return true;
                }
            }
        });
        findPreference("about").setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            /* class com.thedaw.uiuians.SettingsFragment.AnonymousClass2 */

            public boolean onPreferenceClick(Preference preference) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SettingsFragment.this.getActivity());
                builder.setMessage(Html.fromHtml(SettingsFragment.this.getResources().getString(R.string.about_text)));
                builder.setPositiveButton(SettingsFragment.this.getResources().getString(R.string.ok), (DialogInterface.OnClickListener) null);
                builder.setTitle(SettingsFragment.this.getResources().getString(R.string.about_header));
                builder.show();
                return true;
            }
        });
        findPreference("licenses").setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            /* class com.thedaw.uiuians.SettingsFragment.AnonymousClass3 */

            public boolean onPreferenceClick(Preference preference) {
                SettingsFragment.this.startActivity(new Intent(SettingsFragment.this.getActivity(), OssLicensesMenuActivity.class));
                return true;
            }
        });
        ((PreferenceScreen) findPreference("preferenceScreen")).removePreference(findPreference("menuOpenOnStart"));
        this.preferencepurchase = findPreference("purchase");
        String string = getResources().getString(R.string.google_play_license);
        if (string == null || string.equals("")) {
            ((PreferenceScreen) findPreference("preferenceScreen")).removePreference((PreferenceCategory) findPreference("billing"));
        } else {
            this.bp = new BillingProcessor(getActivity(), string, this);
            this.bp.loadOwnedPurchasesFromGoogle();
            this.preferencepurchase.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                /* class com.thedaw.uiuians.SettingsFragment.AnonymousClass4 */

                public boolean onPreferenceClick(Preference preference) {
                    SettingsFragment.this.bp.purchase(SettingsFragment.this.getActivity(), SettingsFragment.this.PRODUCT_ID());
                    return true;
                }
            });
            if (getIsPurchased(getActivity())) {
                this.preferencepurchase.setIcon(R.drawable.ic_action_action_done);
            }
        }
        String[] stringArray = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        if (!(stringArray == null || stringArray.length == 0 || !stringArray[0].equals(SHOW_DIALOG))) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setPositiveButton(R.string.settings_purchase, new DialogInterface.OnClickListener() {
                /* class com.thedaw.uiuians.SettingsFragment.AnonymousClass5 */

                public void onClick(DialogInterface dialogInterface, int i) {
                    SettingsFragment.this.bp.purchase(SettingsFragment.this.getActivity(), SettingsFragment.this.PRODUCT_ID());
                }
            });
            builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                /* class com.thedaw.uiuians.SettingsFragment.AnonymousClass6 */

                public void onClick(DialogInterface dialogInterface, int i) {
                }
            });
            builder.setTitle(getResources().getString(R.string.dialog_purchase_title));
            builder.setMessage(getResources().getString(R.string.dialog_purchase));
            this.dialog = builder.create();
            this.dialog.show();
        }
        if (this.HIDE_RATE_MY_APP) {
            ((PreferenceCategory) findPreference("other")).removePreference(findPreference("rate"));
        }
    }

    @Override // com.thedaw.uiuians.billing.BillingProcessor.IBillingHandler
    public void onProductPurchased(String str, TransactionDetails transactionDetails) {
        if (str.equals(PRODUCT_ID())) {
            setIsPurchased(true, getActivity());
            this.preferencepurchase.setIcon(R.drawable.ic_action_action_done);
            Toast.makeText(getActivity(), getResources().getString(R.string.settings_purchase_success), 1).show();
        }
        Log.v("INFO", "Purchase purchased");
    }

    @Override // com.thedaw.uiuians.billing.BillingProcessor.IBillingHandler
    public void onBillingError(int i, Throwable th) {
        Toast.makeText(getActivity(), getResources().getString(R.string.settings_purchase_fail), 1).show();
        Log.v("INFO", "Error");
    }

    @Override // com.thedaw.uiuians.billing.BillingProcessor.IBillingHandler
    public void onPurchaseHistoryRestored() {
        if (this.bp.isPurchased(PRODUCT_ID())) {
            setIsPurchased(true, getActivity());
            Log.v("INFO", "Purchase actually restored");
            this.preferencepurchase.setIcon(R.drawable.ic_action_action_done);
            if (this.dialog != null) {
                this.dialog.cancel();
            }
            Toast.makeText(getActivity(), getResources().getString(R.string.settings_restore_purchase_success), 1).show();
        }
        Log.v("INFO", "Purchase restored called");
    }

    public void setIsPurchased(boolean z, Context context) {
        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(context).edit();
        edit.putBoolean(PRODUCT_ID_BOUGHT, z);
        edit.apply();
    }

    public static boolean getIsPurchased(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context).getBoolean(PRODUCT_ID_BOUGHT, false);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private String PRODUCT_ID() {
        return getResources().getString(R.string.product_id);
    }

    @Override // android.support.v4.preference.PreferenceFragment, android.support.v4.app.Fragment
    public void onActivityResult(int i, int i2, Intent intent) {
        this.bp.handleActivityResult(i, i2, intent);
    }

    @Override // android.support.v4.preference.PreferenceFragment, android.support.v4.app.Fragment
    public void onDestroy() {
        if (this.bp != null) {
            this.bp.release();
        }
        super.onDestroy();
    }
}

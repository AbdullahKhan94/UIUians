package com.thedaw.uiuians;

import android.util.Log;
import io.fabric.sdk.android.services.network.HttpRequest;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

/* access modifiers changed from: package-private */
public class HttpHandler {
    private static final String TAG = "HttpHandler";

    public String makeServiceCall(String str) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection.setRequestMethod(HttpRequest.METHOD_GET);
            return convertStreamToString(new BufferedInputStream(httpURLConnection.getInputStream()));
        } catch (MalformedURLException e) {
            String str2 = TAG;
            Log.e(str2, "MalformedURLException: " + e.getMessage());
        } catch (ProtocolException e2) {
            String str3 = TAG;
            Log.e(str3, "ProtocolException: " + e2.getMessage());
        } catch (IOException e3) {
            String str4 = TAG;
            Log.e(str4, "IOException: " + e3.getMessage());
        } catch (Exception e4) {
            String str5 = TAG;
            Log.e(str5, "Exception: " + e4.getMessage());
        }
        return null;
    }

    private String convertStreamToString(InputStream inputStream) {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder sb = new StringBuilder();
        while (true) {
            try {
                String readLine = bufferedReader.readLine();
                if (readLine != null) {
                    sb.append(readLine);
                    sb.append('\n');
                } else {
                    try {
                        break;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } catch (IOException e2) {
                e2.printStackTrace();
                inputStream.close();
            } catch (Throwable th) {
                try {
                    inputStream.close();
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
                throw th;
            }
        }
        inputStream.close();
        return sb.toString();
    }
}

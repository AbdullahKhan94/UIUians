package com.thedaw.uiuians.providers.soundcloud.api;

import com.thedaw.uiuians.attachmentviewer.model.MediaAttachment;
import com.thedaw.uiuians.providers.soundcloud.api.object.CommentObject;
import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import com.thedaw.uiuians.providers.wordpress.api.JsonApiPostLoader;
import com.thedaw.uiuians.providers.wordpress.api.RestApiPostLoader;
import com.thedaw.uiuians.providers.wordpress.api.WordpressGetTaskInfo;
import com.thedaw.uiuians.providers.wordpress.api.providers.RestApiProvider;
import com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider;
import java.util.ArrayList;
import java.util.Iterator;
import org.jsoup.helper.StringUtil;

public class WordpressClient {
    private String apiUrl;
    private int maxPages;

    public ArrayList<CommentObject> getListCommentObject(long j) {
        return null;
    }

    public ArrayList<TrackObject> getListTrackObjectsByQuery(String str, int i, int i2) {
        return null;
    }

    public WordpressClient(String str) {
        this.apiUrl = str;
    }

    public ArrayList<TrackObject> getRecentTracks(int i) {
        return getTracksInCategory("", i);
    }

    public ArrayList<TrackObject> getTracksInCategory(String str, int i) {
        String str2;
        MediaAttachment mediaAttachment;
        WordpressGetTaskInfo wordpressGetTaskInfo = new WordpressGetTaskInfo(null, null, this.apiUrl, false);
        WordpressProvider wordpressProvider = wordpressGetTaskInfo.provider;
        StringBuilder sb = new StringBuilder();
        if (StringUtil.isBlank(str)) {
            str2 = wordpressGetTaskInfo.provider.getRecentPosts(wordpressGetTaskInfo);
        } else {
            str2 = wordpressGetTaskInfo.provider.getCategoryPosts(wordpressGetTaskInfo, str);
        }
        sb.append(str2);
        sb.append(i);
        ArrayList<PostItem> parsePostsFromUrl = wordpressProvider.parsePostsFromUrl(wordpressGetTaskInfo, sb.toString());
        if (wordpressGetTaskInfo.pages == null || parsePostsFromUrl == null) {
            return null;
        }
        this.maxPages = wordpressGetTaskInfo.pages.intValue();
        final ArrayList<TrackObject> arrayList = new ArrayList<>();
        Iterator<PostItem> it = parsePostsFromUrl.iterator();
        while (it.hasNext()) {
            final PostItem next = it.next();
            if (wordpressGetTaskInfo.provider instanceof RestApiProvider) {
                new RestApiPostLoader(next, this.apiUrl, new JsonApiPostLoader.BackgroundPostCompleterListener() {
                    /* class com.thedaw.uiuians.providers.soundcloud.api.WordpressClient.AnonymousClass1 */

                    @Override // com.thedaw.uiuians.providers.wordpress.api.JsonApiPostLoader.BackgroundPostCompleterListener
                    public void completed(PostItem postItem) {
                        if (next.getAttachments().size() > 0) {
                            MediaAttachment mediaAttachment = null;
                            Iterator<MediaAttachment> it = next.getAttachments().iterator();
                            while (true) {
                                if (!it.hasNext()) {
                                    break;
                                }
                                MediaAttachment next = it.next();
                                if (next.getMime().contains(MediaAttachment.MIME_PATTERN_AUDIO)) {
                                    mediaAttachment = next;
                                    break;
                                }
                            }
                            if (mediaAttachment != null) {
                                TrackObject trackObject = new TrackObject(next.getId().longValue(), next.getDate(), 0, mediaAttachment.getDuration(), null, null, null, next.getTitle(), next.getContent(), mediaAttachment.getArtist(), null, next.getUrl(), next.getThumbnailCandidate(), null, 0, 0, next.getCommentCount().longValue(), mediaAttachment.getUrl());
                                trackObject.setStreamAble(true);
                                arrayList.add(trackObject);
                            }
                        }
                    }
                }).run();
            } else {
                Iterator<MediaAttachment> it2 = next.getAttachments().iterator();
                while (true) {
                    if (!it2.hasNext()) {
                        mediaAttachment = null;
                        break;
                    }
                    mediaAttachment = it2.next();
                    if (mediaAttachment.getMime().contains(MediaAttachment.MIME_PATTERN_AUDIO)) {
                        break;
                    }
                }
                if (mediaAttachment != null) {
                    TrackObject trackObject = new TrackObject(next.getId().longValue(), next.getDate(), 0, 0, null, null, null, next.getTitle(), next.getContent(), next.getAuthor(), null, next.getUrl(), next.getThumbnailCandidate(), null, 0, 0, next.getCommentCount().longValue(), mediaAttachment.getUrl());
                    trackObject.setStreamAble(true);
                    arrayList.add(trackObject);
                }
            }
        }
        return arrayList;
    }

    public int getMaxPages() {
        return this.maxPages;
    }
}

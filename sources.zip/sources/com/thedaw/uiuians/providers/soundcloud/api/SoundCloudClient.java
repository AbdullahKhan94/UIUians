package com.thedaw.uiuians.providers.soundcloud.api;

import com.thedaw.uiuians.providers.soundcloud.api.object.CommentObject;
import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;
import com.thedaw.uiuians.util.Helper;
import java.util.ArrayList;

public class SoundCloudClient {
    public static final String BASEURL = "http://api.soundcloud.com/";
    public static final String COMMENTS = "comments";
    public static final String FORMAT_CLIENT_ID = "?client_id=%1$s";
    public static final String FORMAT_FILTER_QUERY = "&q=%1$s";
    public static final String FORMAT_OFFSET = "&offset=%1$s&limit=%2$s";
    public static final String FORMAT_STREAM = "https://api.soundcloud.com/tracks/%1$s/stream?client_id=%2$s";
    public static final String JSON_PREFIX = ".json";
    public static final String PLAYLISTS = "playlists";
    public static final String TRACKS = "tracks";
    public static final String USER = "users";
    private String clientId;
    private String mPrefixClientId;

    public SoundCloudClient(String str) {
        this.clientId = str;
        this.mPrefixClientId = String.format(FORMAT_CLIENT_ID, str);
    }

    public ArrayList<TrackObject> getListTrackObjectsByQuery(String str, int i, int i2) {
        return SoundCloudParser.parsingListTrackObject(Helper.getJSONArrayFromUrl(BASEURL + TRACKS + JSON_PREFIX + this.mPrefixClientId + String.format(FORMAT_FILTER_QUERY, str) + String.format(FORMAT_OFFSET, String.valueOf(i), String.valueOf(i2))), this);
    }

    public ArrayList<TrackObject> getListTrackObjectsOfUser(long j, int i, int i2) {
        StringBuilder sb = new StringBuilder();
        sb.append(BASEURL);
        sb.append("users/");
        sb.append(String.valueOf(j) + "/");
        sb.append(TRACKS);
        sb.append(JSON_PREFIX);
        sb.append(this.mPrefixClientId);
        sb.append(String.format(FORMAT_OFFSET, String.valueOf(i), String.valueOf(i2)));
        return SoundCloudParser.parsingListTrackObject(Helper.getJSONArrayFromUrl(sb.toString()), this);
    }

    public ArrayList<TrackObject> getListTrackObjectsOfPlaylist(long j, int i, int i2) {
        StringBuilder sb = new StringBuilder();
        sb.append(BASEURL);
        sb.append("playlists/");
        sb.append(String.valueOf(j) + "/");
        sb.append(TRACKS);
        sb.append(JSON_PREFIX);
        sb.append(this.mPrefixClientId);
        sb.append(String.format(FORMAT_OFFSET, String.valueOf(i), String.valueOf(i2)));
        return SoundCloudParser.parsingListTrackObject(Helper.getJSONArrayFromUrl(sb.toString()), this);
    }

    public ArrayList<CommentObject> getListCommentObject(long j) {
        StringBuilder sb = new StringBuilder();
        sb.append(BASEURL);
        sb.append("tracks/");
        sb.append(String.valueOf(j) + "/");
        sb.append(COMMENTS);
        sb.append(JSON_PREFIX);
        sb.append(this.mPrefixClientId);
        return SoundCloudParser.parsingListCommentObject(Helper.getJSONArrayFromUrl(sb.toString()));
    }

    public String getClientId() {
        return this.clientId;
    }
}

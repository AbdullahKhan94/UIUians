package com.thedaw.uiuians.providers.soundcloud.api.object;

import java.util.Date;

public class CommentObject {
    private String avatarUrl;
    private String body;
    private Date createdAt;
    private long id;
    private int timeStamp;
    private long trackid;
    private long userId;
    private String username;

    public CommentObject(long j, long j2, long j3, Date date, int i, String str, String str2, String str3) {
        this.id = j;
        this.trackid = j2;
        this.userId = j3;
        this.createdAt = date;
        this.timeStamp = i;
        this.body = str;
        this.username = str2;
        this.avatarUrl = str3;
    }

    public int getTimeStamp() {
        return this.timeStamp;
    }

    public long getId() {
        return this.id;
    }

    public Date getCreatedAt() {
        return this.createdAt;
    }

    public long getUserId() {
        return this.userId;
    }

    public long getTrackid() {
        return this.trackid;
    }

    public String getBody() {
        return this.body;
    }

    public String getUsername() {
        return this.username;
    }

    public String getAvatarUrl() {
        return this.avatarUrl;
    }
}

package com.thedaw.uiuians.providers.soundcloud.api.object;

import java.io.Serializable;
import java.util.Date;

public class TrackObject implements Serializable {
    private String artworkUrl;
    private String avatarUrl;
    private long commentCount;
    private Date createdDate;
    private String description;
    private long duration;
    private long favoriteCount;
    private String genre;
    private long id;
    private String linkStream;
    private String permalinkUrl;
    private long playbackCount;
    private String sharing;
    private boolean streamAble;
    private String tagList;
    private String title;
    private long userId;
    private String username;
    private String waveForm;

    public TrackObject(long j, Date date, long j2, long j3, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, long j4, long j5, long j6, String str11) {
        this.id = j;
        this.createdDate = date;
        this.userId = j2;
        this.duration = j3;
        this.sharing = str;
        this.tagList = str2;
        this.genre = str3;
        this.title = str4;
        this.description = str5;
        this.username = str6;
        this.avatarUrl = str7;
        this.permalinkUrl = str8;
        this.artworkUrl = str9;
        this.waveForm = str10;
        this.playbackCount = j4;
        this.favoriteCount = j5;
        this.commentCount = j6;
        this.linkStream = str11;
    }

    public TrackObject() {
    }

    public long getId() {
        return this.id;
    }

    public Date getCreatedDate() {
        return this.createdDate;
    }

    public long getUserId() {
        return this.userId;
    }

    public long getDuration() {
        return this.duration;
    }

    public String getSharing() {
        return this.sharing;
    }

    public String getTagList() {
        return this.tagList;
    }

    public String getGenre() {
        return this.genre;
    }

    public String getTitle() {
        return this.title;
    }

    public String getDescription() {
        return this.description;
    }

    public String getUsername() {
        return this.username;
    }

    public String getAvatarUrl() {
        return this.avatarUrl;
    }

    public String getPermalinkUrl() {
        return this.permalinkUrl;
    }

    public String getArtworkUrl() {
        return this.artworkUrl;
    }

    public String getWaveForm() {
        return this.waveForm;
    }

    public long getPlaybackCount() {
        return this.playbackCount;
    }

    public long getFavoriteCount() {
        return this.favoriteCount;
    }

    public long getCommentCount() {
        return this.commentCount;
    }

    public String getLinkStream() {
        return this.linkStream;
    }

    public boolean isStreamAble() {
        return this.streamAble;
    }

    public void setStreamAble(boolean z) {
        this.streamAble = z;
    }

    public void setDuration(long j) {
        this.duration = j;
    }
}

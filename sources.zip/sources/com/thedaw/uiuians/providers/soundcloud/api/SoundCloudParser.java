package com.thedaw.uiuians.providers.soundcloud.api;

import com.google.android.exoplayer2.text.ttml.TtmlNode;
import com.google.android.gms.measurement.AppMeasurement;
import com.thedaw.uiuians.billing.Constants;
import com.thedaw.uiuians.providers.soundcloud.api.object.CommentObject;
import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;
import com.thedaw.uiuians.util.Log;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SoundCloudParser {
    public static final String TAG = "SoundCloudParser";

    public static TrackObject parsingTrackObject(JSONObject jSONObject, SoundCloudClient soundCloudClient) {
        Date date;
        if (jSONObject != null) {
            try {
                long j = jSONObject.getLong(TtmlNode.ATTR_ID);
                try {
                    date = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss Z").parse(jSONObject.getString("created_at"));
                } catch (ParseException e) {
                    Log.printStackTrace(e);
                    date = null;
                }
                long j2 = jSONObject.getLong("user_id");
                long j3 = jSONObject.getLong("duration");
                String string = jSONObject.getString("sharing");
                String string2 = jSONObject.getString("tag_list");
                String string3 = jSONObject.getString("genre");
                String string4 = jSONObject.getString("title");
                String string5 = jSONObject.getString(Constants.RESPONSE_DESCRIPTION);
                JSONObject jSONObject2 = jSONObject.getJSONObject("user");
                String string6 = jSONObject2.getString("username");
                String string7 = jSONObject2.getString("avatar_url");
                String string8 = jSONObject.getString("permalink_url");
                String string9 = jSONObject.getString("artwork_url");
                String string10 = jSONObject.getString("waveform_url");
                long j4 = jSONObject.getLong("playback_count");
                long j5 = jSONObject.getLong("favoritings_count");
                long j6 = jSONObject.getLong("comment_count");
                boolean z = jSONObject.getBoolean("streamable");
                TrackObject trackObject = new TrackObject(j, date, j2, j3, string, string2, string3, string4, string5, string6, string7, string8, string9, string10, j4, j5, j6, String.format(SoundCloudClient.FORMAT_STREAM, Long.valueOf(j), soundCloudClient.getClientId()));
                trackObject.setStreamAble(z);
                return trackObject;
            } catch (JSONException e2) {
                Log.printStackTrace(e2);
            }
        }
        return null;
    }

    public static ArrayList<TrackObject> parsingListTrackObject(JSONArray jSONArray, SoundCloudClient soundCloudClient) {
        try {
            int length = jSONArray.length();
            ArrayList<TrackObject> arrayList = new ArrayList<>();
            if (length > 0) {
                for (int i = 0; i < length; i++) {
                    TrackObject parsingTrackObject = parsingTrackObject(jSONArray.getJSONObject(i), soundCloudClient);
                    if (parsingTrackObject != null) {
                        arrayList.add(parsingTrackObject);
                    }
                }
            }
            return arrayList;
        } catch (Exception e) {
            Log.printStackTrace(e);
            return null;
        }
    }

    private static CommentObject parsingCommentObject(JSONObject jSONObject) {
        Date date;
        try {
            long j = jSONObject.getLong(TtmlNode.ATTR_ID);
            try {
                date = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss Z").parse(jSONObject.getString("created_at"));
            } catch (ParseException e) {
                Log.printStackTrace(e);
                date = null;
            }
            long j2 = jSONObject.getLong("user_id");
            long j3 = jSONObject.getLong("track_id");
            int i = jSONObject.getInt(AppMeasurement.Param.TIMESTAMP);
            String string = jSONObject.getString(TtmlNode.TAG_BODY);
            JSONObject jSONObject2 = jSONObject.getJSONObject("user");
            return new CommentObject(j, j3, j2, date, i, string, jSONObject2.getString("username"), jSONObject2.getString("avatar_url"));
        } catch (JSONException e2) {
            Log.printStackTrace(e2);
            return null;
        }
    }

    public static ArrayList<CommentObject> parsingListCommentObject(JSONArray jSONArray) {
        try {
            int length = jSONArray.length();
            if (length <= 0) {
                return null;
            }
            ArrayList<CommentObject> arrayList = new ArrayList<>();
            for (int i = 0; i < length; i++) {
                CommentObject parsingCommentObject = parsingCommentObject(jSONArray.getJSONObject(i));
                if (parsingCommentObject != null) {
                    arrayList.add(parsingCommentObject);
                }
            }
            return arrayList;
        } catch (Exception e) {
            Log.printStackTrace(e);
            return null;
        }
    }
}

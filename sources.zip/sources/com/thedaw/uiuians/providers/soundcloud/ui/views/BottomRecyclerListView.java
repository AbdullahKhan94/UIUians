package com.thedaw.uiuians.providers.soundcloud.ui.views;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class BottomRecyclerListView extends RecyclerView {
    public BottomRecyclerListView(Context context) {
        super(context);
    }

    public BottomRecyclerListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public BottomRecyclerListView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    @Override // android.support.v7.widget.RecyclerView
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean onTouchEvent = super.onTouchEvent(motionEvent);
        View childAt = getChildAt(0);
        if (childAt == null || motionEvent.getY() < childAt.getY()) {
            return false;
        }
        return onTouchEvent;
    }
}

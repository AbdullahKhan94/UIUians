package com.thedaw.uiuians.providers.soundcloud.ui.views;

import android.content.Context;
import android.graphics.PorterDuff;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;
import com.thedaw.uiuians.providers.soundcloud.helpers.SoundCloudArtworkHelper;
import com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayer;
import com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener;

public class PlaybackView extends FrameLayout implements View.OnClickListener, CheerleaderPlayerListener, SeekBar.OnSeekBarChangeListener {
    private static Listener sDummyListener = new Listener() {
        /* class com.thedaw.uiuians.providers.soundcloud.ui.views.PlaybackView.AnonymousClass1 */

        @Override // com.thedaw.uiuians.providers.soundcloud.ui.views.PlaybackView.Listener
        public void onNextPressed() {
        }

        @Override // com.thedaw.uiuians.providers.soundcloud.ui.views.PlaybackView.Listener
        public void onPreviousPressed() {
        }

        @Override // com.thedaw.uiuians.providers.soundcloud.ui.views.PlaybackView.Listener
        public void onSeekToRequested(int i) {
        }

        @Override // com.thedaw.uiuians.providers.soundcloud.ui.views.PlaybackView.Listener
        public void onTogglePlayPressed() {
        }
    };
    private TextView mArtist;
    private ImageView mArtwork;
    private TextView mCurrentTime;
    private TextView mDuration;
    private Listener mListener = sDummyListener;
    private ProgressBar mLoader;
    private ImageView mPlayPause;
    private SeekBar mSeekBar;
    private boolean mSeeking;
    private TextView mTitle;

    public interface Listener {
        void onNextPressed();

        void onPreviousPressed();

        void onSeekToRequested(int i);

        void onTogglePlayPressed();
    }

    public PlaybackView(Context context) {
        super(context);
        if (!isInEditMode()) {
            init(context);
        }
    }

    public PlaybackView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        if (!isInEditMode()) {
            init(context);
        }
    }

    public PlaybackView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        if (!isInEditMode()) {
            init(context);
        }
    }

    public void setListener(Listener listener) {
        if (listener == null) {
            this.mListener = sDummyListener;
        } else {
            this.mListener = listener;
        }
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.playback_view_next:
                this.mListener.onNextPressed();
                return;
            case R.id.playback_view_previous:
                this.mListener.onPreviousPressed();
                return;
            case R.id.playback_view_seekbar:
            default:
                return;
            case R.id.playback_view_toggle_play:
                this.mListener.onTogglePlayPressed();
                return;
        }
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onPlayerPlay(TrackObject trackObject, int i) {
        setTrack(trackObject);
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onPlayerPause() {
        this.mPlayPause.setImageResource(R.drawable.ic_play_white);
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onPlayerSeekTo(int i) {
        this.mSeekBar.setProgress(i);
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onPlayerDestroyed() {
        this.mPlayPause.setImageResource(R.drawable.ic_play_white);
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onBufferingStarted() {
        this.mLoader.setVisibility(0);
        this.mPlayPause.setVisibility(4);
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onBufferingEnded() {
        this.mLoader.setVisibility(4);
        this.mPlayPause.setVisibility(0);
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onDurationChanged(long j) {
        this.mSeekBar.setMax((int) j);
        int[] secondMinutes = getSecondMinutes(j);
        this.mDuration.setText(String.format(getResources().getString(R.string.playback_view_time), Integer.valueOf(secondMinutes[0]), Integer.valueOf(secondMinutes[1])));
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onProgressChanged(int i) {
        if (!this.mSeeking) {
            this.mSeekBar.setProgress(i);
            int[] secondMinutes = getSecondMinutes((long) i);
            this.mCurrentTime.setText(String.format(getResources().getString(R.string.playback_view_time), Integer.valueOf(secondMinutes[0]), Integer.valueOf(secondMinutes[1])));
        }
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        int[] secondMinutes = getSecondMinutes((long) i);
        this.mCurrentTime.setText(String.format(getResources().getString(R.string.playback_view_time), Integer.valueOf(secondMinutes[0]), Integer.valueOf(secondMinutes[1])));
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
        this.mSeeking = true;
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
        this.mSeeking = false;
        this.mListener.onSeekToRequested(seekBar.getProgress());
    }

    public void synchronize(CheerleaderPlayer cheerleaderPlayer) {
        setTrack(cheerleaderPlayer.getCurrentTrack());
        this.mLoader.setVisibility(4);
        this.mPlayPause.setVisibility(0);
        setPlaying(cheerleaderPlayer.isPlaying());
    }

    private void setTrack(TrackObject trackObject) {
        if (trackObject == null) {
            this.mTitle.setText("");
            this.mArtist.setText("");
            this.mArtwork.setImageDrawable(null);
            this.mPlayPause.setImageResource(R.drawable.ic_play_white);
            this.mSeekBar.setProgress(0);
            String format = String.format(getResources().getString(R.string.playback_view_time), 0, 0);
            this.mCurrentTime.setText(format);
            this.mDuration.setText(format);
            return;
        }
        Picasso.get().load(SoundCloudArtworkHelper.getArtworkUrl(trackObject, SoundCloudArtworkHelper.XLARGE)).into(this.mArtwork);
        this.mTitle.setText(trackObject.getTitle());
        this.mArtist.setText(trackObject.getUsername());
        this.mPlayPause.setImageResource(R.drawable.ic_pause_white);
        if (getTranslationY() != 0.0f) {
            animate().translationY(0.0f);
        }
        this.mSeekBar.setMax((int) trackObject.getDuration());
        String format2 = String.format(getResources().getString(R.string.playback_view_time), 0, 0);
        int[] secondMinutes = getSecondMinutes(trackObject.getDuration());
        String format3 = String.format(getResources().getString(R.string.playback_view_time), Integer.valueOf(secondMinutes[0]), Integer.valueOf(secondMinutes[1]));
        this.mCurrentTime.setText(format2);
        this.mDuration.setText(format3);
    }

    private void setPlaying(boolean z) {
        if (z) {
            this.mPlayPause.setImageResource(R.drawable.ic_pause_white);
        } else {
            this.mPlayPause.setImageResource(R.drawable.ic_play_white);
        }
    }

    private void init(Context context) {
        LayoutInflater.from(context).inflate(R.layout.soundcloud_playback_view, this);
        findViewById(R.id.playback_view_next).setOnClickListener(this);
        findViewById(R.id.playback_view_previous).setOnClickListener(this);
        this.mCurrentTime = (TextView) findViewById(R.id.playback_view_current_time);
        this.mDuration = (TextView) findViewById(R.id.playback_view_duration);
        this.mPlayPause = (ImageView) findViewById(R.id.playback_view_toggle_play);
        this.mLoader = (ProgressBar) findViewById(R.id.playback_view_loader);
        this.mPlayPause.setOnClickListener(this);
        this.mArtwork = (ImageView) findViewById(R.id.playback_view_artwork);
        this.mArtwork.setColorFilter(ContextCompat.getColor(context, R.color.playback_view_track_artwork_filter), PorterDuff.Mode.SRC_ATOP);
        this.mTitle = (TextView) findViewById(R.id.playback_view_track_title);
        this.mArtist = (TextView) findViewById(R.id.playback_view_track_artist);
        this.mSeekBar = (SeekBar) findViewById(R.id.playback_view_seekbar);
        this.mSeekBar.setPadding(0, 0, 0, 0);
        this.mSeekBar.setOnSeekBarChangeListener(this);
        this.mSeeking = false;
    }

    private int[] getSecondMinutes(long j) {
        int i = ((int) j) / 1000;
        return new int[]{i / 60, i % 60};
    }
}

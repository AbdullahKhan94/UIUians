package com.thedaw.uiuians.providers.soundcloud.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.Animation;
import android.widget.FrameLayout;
import android.widget.PopupMenu;
import android.widget.Toast;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.inherit.BackPressFragment;
import com.thedaw.uiuians.inherit.CollapseControllingFragment;
import com.thedaw.uiuians.providers.soundcloud.TracksAdapter;
import com.thedaw.uiuians.providers.soundcloud.api.SoundCloudClient;
import com.thedaw.uiuians.providers.soundcloud.api.WordpressClient;
import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;
import com.thedaw.uiuians.providers.soundcloud.helpers.EndlessRecyclerOnScrollListener;
import com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayer;
import com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlaylistListener;
import com.thedaw.uiuians.providers.soundcloud.ui.views.PlaybackView;
import com.thedaw.uiuians.providers.soundcloud.ui.views.TrackView;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import com.thedaw.uiuians.util.ThemeUtils;
import java.util.ArrayList;

public class SoundCloudFragment extends Fragment implements PlaybackView.Listener, CheerleaderPlaylistListener, BackPressFragment, CollapseControllingFragment {
    private static final int PER_PAGE = 20;
    private FrameLayout ll;
    private Activity mAct;
    private TracksAdapter mAdapter;
    private CheerleaderPlayer mCheerleaderPlayer;
    private EndlessRecyclerOnScrollListener mEndlessRecyclerOnScrollListener;
    private PlaybackView mPlaybackView;
    private TracksAdapter mPlaylistAdapter;
    private RecyclerView mPlaylistRecyclerView;
    private ArrayList<TrackObject> mPlaylistTracks;
    private TrackView.Listener mPlaylistTracksListener;
    private TrackView.Listener mRetrieveTracksListener;
    private RecyclerView mRetrieveTracksRecyclerView;
    private ArrayList<TrackObject> mRetrievedTracks;

    @Override // com.thedaw.uiuians.inherit.CollapseControllingFragment
    public boolean dynamicToolbarElevation() {
        return false;
    }

    @Override // com.thedaw.uiuians.inherit.CollapseControllingFragment
    public boolean supportsCollapse() {
        return false;
    }

    @Override // android.support.v4.app.Fragment
    @SuppressLint({"InflateParams"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreate(bundle);
        this.ll = (FrameLayout) layoutInflater.inflate(R.layout.fragment_soundcloud, viewGroup, false);
        setHasOptionsMenu(true);
        this.mRetrieveTracksRecyclerView = (RecyclerView) this.ll.findViewById(R.id.recyclerview);
        this.mPlaylistRecyclerView = (RecyclerView) this.ll.findViewById(R.id.activity_artist_playlist);
        return this.ll;
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        this.mCheerleaderPlayer = initPlayer();
        initRetrieveTracksRecyclerView();
        initPlaylistTracksRecyclerView();
        setTrackListPadding();
        ArrayList<TrackObject> tracks = this.mCheerleaderPlayer.getTracks();
        if (tracks != null) {
            this.mPlaylistTracks.addAll(tracks);
        }
        this.mPlaybackView.synchronize(this.mCheerleaderPlayer);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private CheerleaderPlayer initPlayer() {
        String[] stringArray = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        Bundle bundle = new Bundle();
        bundle.putStringArray(MainActivity.FRAGMENT_DATA, stringArray);
        bundle.putSerializable(MainActivity.FRAGMENT_CLASS, getClass());
        return new CheerleaderPlayer.Builder().from(this.mAct).with(R.string.soundcloud_id).notificationActivity(new HolderActivity()).notificationIcon(R.drawable.ic_radio_playing).notificationBundle(bundle).build();
    }

    @Override // android.support.v4.app.Fragment
    public void onResume() {
        super.onResume();
        if (this.mCheerleaderPlayer.isClosed()) {
            this.mCheerleaderPlayer = initPlayer();
        }
        this.mCheerleaderPlayer.registerPlayerListener(this.mPlaybackView);
        this.mCheerleaderPlayer.registerPlayerListener(this.mPlaylistAdapter);
        this.mCheerleaderPlayer.registerPlaylistListener(this);
    }

    @Override // android.support.v4.app.Fragment
    public void onPause() {
        super.onPause();
        try {
            this.mCheerleaderPlayer.unregisterPlayerListener(this.mPlaybackView);
            this.mCheerleaderPlayer.unregisterPlayerListener(this.mPlaylistAdapter);
            this.mCheerleaderPlayer.unregisterPlaylistListener(this);
        } catch (Exception unused) {
            Log.v("INFO", "Unable to unregister player listeners");
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onDestroy() {
        super.onDestroy();
        this.mCheerleaderPlayer.destroy();
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.ui.views.PlaybackView.Listener
    public void onTogglePlayPressed() {
        this.mCheerleaderPlayer.togglePlayback();
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.ui.views.PlaybackView.Listener
    public void onPreviousPressed() {
        this.mCheerleaderPlayer.previous();
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.ui.views.PlaybackView.Listener
    public void onNextPressed() {
        this.mCheerleaderPlayer.next();
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.ui.views.PlaybackView.Listener
    public void onSeekToRequested(int i) {
        this.mCheerleaderPlayer.seekTo(i);
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlaylistListener
    public void onTrackAdded(TrackObject trackObject) {
        if (this.mPlaylistTracks.isEmpty()) {
            this.mPlaylistRecyclerView.setVisibility(0);
            this.mPlaylistRecyclerView.animate().translationY(0.0f);
            this.mRetrieveTracksRecyclerView.setPadding(0, 0, 0, getResources().getDimensionPixelOffset(R.dimen.playback_view_height));
        }
        this.mPlaylistTracks.add(trackObject);
        this.mPlaylistAdapter.notifyDataSetChanged();
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlaylistListener
    public void onTrackRemoved(TrackObject trackObject, boolean z) {
        if (this.mPlaylistTracks.remove(trackObject)) {
            this.mPlaylistAdapter.notifyDataSetChanged();
        }
        if (z) {
            this.mPlaylistRecyclerView.animate().translationY((float) this.mPlaybackView.getHeight());
            this.mPlaylistRecyclerView.setLayoutAnimationListener(new Animation.AnimationListener() {
                /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass1 */

                public void onAnimationRepeat(Animation animation) {
                }

                public void onAnimationStart(Animation animation) {
                }

                public void onAnimationEnd(Animation animation) {
                    SoundCloudFragment.this.mPlaylistRecyclerView.setVisibility(8);
                }
            });
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.soundcloud_menu, menu);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId != R.id.play) {
            if (itemId == R.id.refresh) {
                this.mRetrievedTracks.clear();
                this.mEndlessRecyclerOnScrollListener.reset();
                loadTracks(0);
            }
            return super.onOptionsItemSelected(menuItem);
        }
        this.mCheerleaderPlayer.addTracks(this.mRetrievedTracks);
        if (!this.mCheerleaderPlayer.isPlaying()) {
            this.mCheerleaderPlayer.play();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void setTrackListPadding() {
        final AnonymousClass2 r0 = new ViewTreeObserver.OnGlobalLayoutListener() {
            /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass2 */

            public void onGlobalLayout() {
                if (SoundCloudFragment.this.getActivity() != null && SoundCloudFragment.this.isAdded()) {
                    int dimensionPixelOffset = SoundCloudFragment.this.getResources().getDimensionPixelOffset(R.dimen.playback_view_height);
                    SoundCloudFragment.this.mPlaylistRecyclerView.setPadding(0, SoundCloudFragment.this.mPlaylistRecyclerView.getMeasuredHeight() - dimensionPixelOffset, 0, 0);
                    SoundCloudFragment.this.mPlaylistRecyclerView.setAdapter(SoundCloudFragment.this.mPlaylistAdapter);
                    if (SoundCloudFragment.this.mPlaylistTracks.isEmpty()) {
                        SoundCloudFragment.this.mPlaylistRecyclerView.setVisibility(8);
                        SoundCloudFragment.this.mPlaylistRecyclerView.setTranslationY((float) dimensionPixelOffset);
                        return;
                    }
                    SoundCloudFragment.this.mRetrieveTracksRecyclerView.setPadding(0, 0, 0, dimensionPixelOffset);
                }
            }
        };
        this.mPlaylistRecyclerView.getViewTreeObserver().addOnGlobalLayoutListener(r0);
        new Handler().postDelayed(new Runnable() {
            /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass3 */

            public void run() {
                SoundCloudFragment.this.mPlaylistRecyclerView.getViewTreeObserver().removeOnGlobalLayoutListener(r0);
            }
        }, 500);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void loadTracks(int i) {
        final boolean z;
        final int i2 = i * 20;
        final boolean z2 = false;
        this.mAdapter.setFooterView(LayoutInflater.from(this.mAct).inflate(R.layout.listview_footer, (ViewGroup) this.mPlaylistRecyclerView, false));
        this.mAdapter.notifyDataSetChanged();
        final String[] stringArray = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        if (stringArray.length > 2 && stringArray[2].equals("wordpress")) {
            z2 = true;
        } else if (stringArray.length > 1 && stringArray[1].equals("playlist")) {
            z = true;
            AsyncTask.execute(new Runnable() {
                /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass4 */

                public void run() {
                    final ArrayList<TrackObject> arrayList;
                    if (SoundCloudFragment.this.getActivity() != null && SoundCloudFragment.this.isAdded()) {
                        boolean z = false;
                        if (!z2) {
                            SoundCloudClient soundCloudClient = new SoundCloudClient(SoundCloudFragment.this.getResources().getString(R.string.soundcloud_id));
                            long parseLong = Long.parseLong(stringArray[0]);
                            if (!z) {
                                arrayList = soundCloudClient.getListTrackObjectsOfUser(parseLong, i2, 20);
                            } else {
                                arrayList = soundCloudClient.getListTrackObjectsOfPlaylist(parseLong, i2, 20);
                            }
                        } else {
                            WordpressClient wordpressClient = new WordpressClient(stringArray[0]);
                            ArrayList<TrackObject> tracksInCategory = wordpressClient.getTracksInCategory(stringArray[1], i2 / 20);
                            EndlessRecyclerOnScrollListener endlessRecyclerOnScrollListener = SoundCloudFragment.this.mEndlessRecyclerOnScrollListener;
                            if (i2 / 20 >= wordpressClient.getMaxPages()) {
                                z = true;
                            }
                            endlessRecyclerOnScrollListener.forceCantLoadMore(z);
                            arrayList = tracksInCategory;
                        }
                        SoundCloudFragment.this.mAct.runOnUiThread(new Runnable() {
                            /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass4.AnonymousClass1 */

                            public void run() {
                                SoundCloudFragment.this.mAdapter.setFooterView(null);
                                if (arrayList != null) {
                                    SoundCloudFragment.this.mAdapter.setModeAndNotify(1);
                                    if (arrayList.size() > 0) {
                                        SoundCloudFragment.this.mRetrievedTracks.addAll(arrayList);
                                    }
                                } else {
                                    Helper.noConnection(SoundCloudFragment.this.mAct);
                                    SoundCloudFragment.this.mAdapter.setModeAndNotify(2);
                                }
                                SoundCloudFragment.this.mAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                }
            });
        }
        z = false;
        AsyncTask.execute(new Runnable() {
            /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass4 */

            public void run() {
                final ArrayList<TrackObject> arrayList;
                if (SoundCloudFragment.this.getActivity() != null && SoundCloudFragment.this.isAdded()) {
                    boolean z = false;
                    if (!z2) {
                        SoundCloudClient soundCloudClient = new SoundCloudClient(SoundCloudFragment.this.getResources().getString(R.string.soundcloud_id));
                        long parseLong = Long.parseLong(stringArray[0]);
                        if (!z) {
                            arrayList = soundCloudClient.getListTrackObjectsOfUser(parseLong, i2, 20);
                        } else {
                            arrayList = soundCloudClient.getListTrackObjectsOfPlaylist(parseLong, i2, 20);
                        }
                    } else {
                        WordpressClient wordpressClient = new WordpressClient(stringArray[0]);
                        ArrayList<TrackObject> tracksInCategory = wordpressClient.getTracksInCategory(stringArray[1], i2 / 20);
                        EndlessRecyclerOnScrollListener endlessRecyclerOnScrollListener = SoundCloudFragment.this.mEndlessRecyclerOnScrollListener;
                        if (i2 / 20 >= wordpressClient.getMaxPages()) {
                            z = true;
                        }
                        endlessRecyclerOnScrollListener.forceCantLoadMore(z);
                        arrayList = tracksInCategory;
                    }
                    SoundCloudFragment.this.mAct.runOnUiThread(new Runnable() {
                        /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass4.AnonymousClass1 */

                        public void run() {
                            SoundCloudFragment.this.mAdapter.setFooterView(null);
                            if (arrayList != null) {
                                SoundCloudFragment.this.mAdapter.setModeAndNotify(1);
                                if (arrayList.size() > 0) {
                                    SoundCloudFragment.this.mRetrievedTracks.addAll(arrayList);
                                }
                            } else {
                                Helper.noConnection(SoundCloudFragment.this.mAct);
                                SoundCloudFragment.this.mAdapter.setModeAndNotify(2);
                            }
                            SoundCloudFragment.this.mAdapter.notifyDataSetChanged();
                        }
                    });
                }
            }
        });
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void showTrackActionsPopup(final TrackObject trackObject, View view) {
        PopupMenu popupMenu = new PopupMenu(this.mAct, view);
        popupMenu.getMenuInflater().inflate(R.menu.soundcloud_track_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass5 */

            public boolean onMenuItemClick(MenuItem menuItem) {
                int itemId = menuItem.getItemId();
                if (itemId == R.id.menu_download) {
                    Helper.download(SoundCloudFragment.this.mAct, trackObject.getLinkStream());
                    return true;
                } else if (itemId != R.id.menu_share) {
                    return false;
                } else {
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType("text/plain");
                    intent.putExtra("android.intent.extra.TEXT", trackObject.getPermalinkUrl());
                    SoundCloudFragment.this.startActivity(Intent.createChooser(intent, SoundCloudFragment.this.getResources().getString(R.string.share_header)));
                    return true;
                }
            }
        });
        popupMenu.show();
    }

    private void initRetrieveTracksRecyclerView() {
        this.mRetrieveTracksListener = new TrackView.Listener() {
            /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass6 */

            @Override // com.thedaw.uiuians.providers.soundcloud.ui.views.TrackView.Listener
            public void onTrackClicked(TrackObject trackObject) {
                if (SoundCloudFragment.this.mCheerleaderPlayer.isClosed()) {
                    SoundCloudFragment.this.mCheerleaderPlayer = SoundCloudFragment.this.initPlayer();
                }
                if (SoundCloudFragment.this.mCheerleaderPlayer.getTracks().contains(trackObject)) {
                    SoundCloudFragment.this.mCheerleaderPlayer.play(trackObject);
                    return;
                }
                boolean z = !SoundCloudFragment.this.mCheerleaderPlayer.isPlaying();
                SoundCloudFragment.this.mCheerleaderPlayer.addTrack(trackObject, z);
                SoundCloudFragment.this.mPlaylistAdapter.notifyDataSetChanged();
                if (!z) {
                    Toast.makeText(SoundCloudFragment.this.mAct, SoundCloudFragment.this.getResources().getString(R.string.toast_track_added), 1).show();
                }
            }

            @Override // com.thedaw.uiuians.providers.soundcloud.ui.views.TrackView.Listener
            public void onMoreClicked(TrackObject trackObject, View view) {
                SoundCloudFragment.this.showTrackActionsPopup(trackObject, view);
            }
        };
        this.mRetrievedTracks = new ArrayList<>();
        this.mAdapter = new TracksAdapter(getContext(), this.mRetrieveTracksListener, this.mRetrievedTracks);
        this.mAdapter.setModeAndNotify(3);
        this.mRetrieveTracksRecyclerView.setAdapter(this.mAdapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.mAct, 1, false);
        this.mRetrieveTracksRecyclerView.setLayoutManager(linearLayoutManager);
        this.mEndlessRecyclerOnScrollListener = new EndlessRecyclerOnScrollListener(linearLayoutManager) {
            /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass7 */

            @Override // com.thedaw.uiuians.providers.soundcloud.helpers.EndlessRecyclerOnScrollListener
            public void onLoadMore(final int i) {
                SoundCloudFragment.this.mRetrieveTracksRecyclerView.post(new Runnable() {
                    /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass7.AnonymousClass1 */

                    public void run() {
                        SoundCloudFragment.this.loadTracks(i);
                    }
                });
            }
        };
        this.mRetrieveTracksRecyclerView.addOnScrollListener(this.mEndlessRecyclerOnScrollListener);
    }

    private void initPlaylistTracksRecyclerView() {
        this.mPlaylistTracksListener = new TrackView.Listener() {
            /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass8 */

            @Override // com.thedaw.uiuians.providers.soundcloud.ui.views.TrackView.Listener
            public void onTrackClicked(TrackObject trackObject) {
                SoundCloudFragment.this.mCheerleaderPlayer.play(trackObject);
            }

            @Override // com.thedaw.uiuians.providers.soundcloud.ui.views.TrackView.Listener
            public void onMoreClicked(TrackObject trackObject, View view) {
                SoundCloudFragment.this.showTrackActionsPopup(trackObject, view);
            }
        };
        this.mPlaybackView = new PlaybackView(this.mAct);
        this.mPlaybackView.setListener(this);
        this.mPlaylistTracks = new ArrayList<>();
        this.mPlaylistAdapter = new TracksAdapter(getContext(), this.mPlaylistTracksListener, this.mPlaylistTracks);
        this.mPlaylistAdapter.setHeaderView(this.mPlaybackView);
        this.mPlaylistRecyclerView.setLayoutManager(new LinearLayoutManager(this.mAct, 1, false));
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, 4) {
            /* class com.thedaw.uiuians.providers.soundcloud.ui.SoundCloudFragment.AnonymousClass9 */

            @Override // android.support.v7.widget.helper.ItemTouchHelper.Callback
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder viewHolder2) {
                return false;
            }

            @Override // android.support.v7.widget.helper.ItemTouchHelper.SimpleCallback
            public int getSwipeDirs(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
                if (viewHolder.getAdapterPosition() == 0) {
                    return 0;
                }
                return super.getSwipeDirs(recyclerView, viewHolder);
            }

            @Override // android.support.v7.widget.helper.ItemTouchHelper.Callback
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int i) {
                TrackObject trackObject = SoundCloudFragment.this.mCheerleaderPlayer.getTracks().get(viewHolder.getAdapterPosition() - 1);
                if (SoundCloudFragment.this.mCheerleaderPlayer.getTracks().contains(trackObject)) {
                    SoundCloudFragment.this.mCheerleaderPlayer.removeTrack(SoundCloudFragment.this.mPlaylistTracks.indexOf(trackObject));
                }
            }

            @Override // android.support.v7.widget.helper.ItemTouchHelper.Callback
            public void onChildDraw(Canvas canvas, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float f, float f2, int i, boolean z) {
                if (i == 1) {
                    View view = viewHolder.itemView;
                    Paint paint = new Paint();
                    if (f < 0.0f) {
                        paint.setColor(ContextCompat.getColor(SoundCloudFragment.this.mAct, R.color.grey));
                        canvas.drawRect(((float) view.getRight()) + f, (float) view.getTop(), (float) view.getRight(), (float) view.getBottom(), paint);
                    }
                    super.onChildDraw(canvas, recyclerView, viewHolder, f, f2, i, z);
                }
            }
        }).attachToRecyclerView(this.mPlaylistRecyclerView);
    }

    @Override // com.thedaw.uiuians.inherit.BackPressFragment
    public boolean handleBackPress() {
        if (this.mPlaybackView.getTop() >= this.mPlaylistRecyclerView.getHeight() - this.mPlaybackView.getHeight() || this.mPlaylistTracks.size() <= 0) {
            return false;
        }
        this.mPlaylistRecyclerView.getLayoutManager().smoothScrollToPosition(this.mPlaylistRecyclerView, null, 0);
        return true;
    }
}

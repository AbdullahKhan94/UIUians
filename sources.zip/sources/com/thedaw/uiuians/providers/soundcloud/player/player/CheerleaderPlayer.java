package com.thedaw.uiuians.providers.soundcloud.player.player;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.DrawableRes;
import android.support.annotation.StringRes;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class CheerleaderPlayer {
    private static final int STATE_PAUSED = 1;
    private static final int STATE_PLAYING = 2;
    private static final int STATE_STOPPED = 0;
    private static CheerleaderPlayer sInstance;
    private WeakReference<Context> mApplicationContext;
    private ArrayList<CheerleaderPlayerListener> mCheerleaderPlayerListeners;
    private ArrayList<CheerleaderPlaylistListener> mCheerleaderPlaylistListeners;
    private String mClientKey;
    private boolean mDestroyDelayed;
    private PlaybackListener mInternalListener;
    private boolean mIsClosed;
    private NotificationManager mNotificationManager;
    private PlayerPlaylist mPlayerPlaylist;
    private int mState;

    private CheerleaderPlayer() {
    }

    private CheerleaderPlayer(Context context, String str) {
        this.mClientKey = str;
        this.mIsClosed = false;
        this.mDestroyDelayed = false;
        this.mState = 0;
        this.mCheerleaderPlayerListeners = new ArrayList<>();
        this.mCheerleaderPlaylistListeners = new ArrayList<>();
        this.mApplicationContext = new WeakReference<>(context);
        this.mPlayerPlaylist = PlayerPlaylist.getInstance();
        this.mNotificationManager = NotificationManager.getInstance(getContext());
        initInternalListener(context);
    }

    /* access modifiers changed from: private */
    public static CheerleaderPlayer getInstance(Context context, String str) {
        if (str == null) {
            throw new IllegalArgumentException("Sound cloud client id can't be null.");
        }
        if (sInstance == null || sInstance.mIsClosed) {
            sInstance = new CheerleaderPlayer(context.getApplicationContext(), str);
        } else {
            sInstance.mClientKey = str;
        }
        sInstance.mDestroyDelayed = false;
        return sInstance;
    }

    public void destroy() {
        if (!this.mIsClosed) {
            if (this.mState != 0) {
                this.mDestroyDelayed = true;
                return;
            }
            this.mIsClosed = true;
            PlaybackService.unregisterListener(getContext(), this.mInternalListener);
            this.mInternalListener = null;
            this.mApplicationContext.clear();
            this.mApplicationContext = null;
            this.mClientKey = null;
            this.mPlayerPlaylist = null;
            this.mCheerleaderPlayerListeners.clear();
        }
    }

    public void play() {
        checkState();
        if (this.mState == 1) {
            PlaybackService.resume(getContext(), this.mClientKey);
        } else if (this.mState == 0) {
            TrackObject currentTrack = this.mPlayerPlaylist.getCurrentTrack();
            if (currentTrack != null) {
                PlaybackService.play(getContext(), this.mClientKey, currentTrack);
            } else {
                return;
            }
        }
        this.mState = 2;
    }

    public void play(int i) {
        checkState();
        ArrayList<TrackObject> tracks = this.mPlayerPlaylist.getTracks();
        if (i >= 0 && i < tracks.size()) {
            this.mPlayerPlaylist.setPlayingTrack(i);
            PlaybackService.play(getContext(), this.mClientKey, tracks.get(i));
        }
    }

    public void play(TrackObject trackObject) {
        checkState();
        int indexOf = this.mPlayerPlaylist.getTracks().indexOf(trackObject);
        if (indexOf > -1) {
            this.mPlayerPlaylist.setPlayingTrack(indexOf);
            PlaybackService.play(getContext(), this.mClientKey, trackObject);
        }
    }

    public void pause() {
        checkState();
        if (this.mState == 2) {
            PlaybackService.pause(getContext(), this.mClientKey);
            this.mState = 1;
        }
    }

    public void togglePlayback() {
        switch (this.mState) {
            case 0:
            case 1:
                play();
                return;
            case 2:
                pause();
                return;
            default:
                return;
        }
    }

    public boolean next() {
        checkState();
        if (this.mPlayerPlaylist.isEmpty()) {
            return false;
        }
        PlaybackService.play(getContext(), this.mClientKey, this.mPlayerPlaylist.next());
        return true;
    }

    public boolean previous() {
        checkState();
        if (this.mPlayerPlaylist.isEmpty()) {
            return false;
        }
        PlaybackService.play(getContext(), this.mClientKey, this.mPlayerPlaylist.previous());
        return true;
    }

    public void seekTo(int i) {
        checkState();
        if (!this.mPlayerPlaylist.isEmpty()) {
            PlaybackService.seekTo(getContext(), this.mClientKey, i);
        }
    }

    public void addTrack(TrackObject trackObject) {
        addTrack(trackObject, false);
    }

    public void addTrack(TrackObject trackObject, boolean z) {
        checkState();
        this.mPlayerPlaylist.add(trackObject);
        Iterator<CheerleaderPlaylistListener> it = this.mCheerleaderPlaylistListeners.iterator();
        while (it.hasNext()) {
            it.next().onTrackAdded(trackObject);
        }
        if (z) {
            play(this.mPlayerPlaylist.size() - 1);
        }
    }

    public void addTracks(List<TrackObject> list) {
        checkState();
        for (TrackObject trackObject : list) {
            addTrack(trackObject);
        }
    }

    public void removeTrack(int i) {
        checkState();
        TrackObject currentTrack = this.mPlayerPlaylist.getCurrentTrack();
        TrackObject remove = this.mPlayerPlaylist.remove(i);
        if (remove != null) {
            if (this.mPlayerPlaylist.isEmpty()) {
                PlaybackService.stop(getContext(), this.mClientKey);
            } else if (currentTrack != null && currentTrack.equals(remove) && this.mState == 2) {
                play(this.mPlayerPlaylist.getCurrentTrackIndex());
            }
            Iterator<CheerleaderPlaylistListener> it = this.mCheerleaderPlaylistListeners.iterator();
            while (it.hasNext()) {
                it.next().onTrackRemoved(remove, this.mPlayerPlaylist.isEmpty());
            }
        }
    }

    public boolean isPlaying() {
        return this.mState == 2;
    }

    public ArrayList<TrackObject> getTracks() {
        checkState();
        return new ArrayList<>(this.mPlayerPlaylist.getTracks());
    }

    public boolean isClosed() {
        return this.mIsClosed;
    }

    public TrackObject getCurrentTrack() {
        checkState();
        return this.mPlayerPlaylist.getCurrentTrack();
    }

    public void registerPlayerListener(CheerleaderPlayerListener cheerleaderPlayerListener) {
        checkState();
        this.mCheerleaderPlayerListeners.add(cheerleaderPlayerListener);
        if (this.mState == 2) {
            cheerleaderPlayerListener.onPlayerPlay(this.mPlayerPlaylist.getCurrentTrack(), this.mPlayerPlaylist.getCurrentTrackIndex());
        } else if (this.mState == 1) {
            cheerleaderPlayerListener.onPlayerPause();
        }
    }

    public void unregisterPlayerListener(CheerleaderPlayerListener cheerleaderPlayerListener) {
        checkState();
        this.mCheerleaderPlayerListeners.remove(cheerleaderPlayerListener);
    }

    public void registerPlaylistListener(CheerleaderPlaylistListener cheerleaderPlaylistListener) {
        checkState();
        this.mCheerleaderPlaylistListeners.add(cheerleaderPlaylistListener);
    }

    public void unregisterPlaylistListener(CheerleaderPlaylistListener cheerleaderPlaylistListener) {
        checkState();
        this.mCheerleaderPlaylistListeners.remove(cheerleaderPlaylistListener);
    }

    private Context getContext() {
        if (this.mApplicationContext.get() != null) {
            return this.mApplicationContext.get();
        }
        throw new IllegalStateException("WeakReference on application context null");
    }

    private void initInternalListener(Context context) {
        this.mInternalListener = new PlaybackListener() {
            /* class com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayer.AnonymousClass1 */

            /* access modifiers changed from: protected */
            @Override // com.thedaw.uiuians.providers.soundcloud.player.player.PlaybackListener
            public void onPlay(TrackObject trackObject) {
                super.onPlay(trackObject);
                CheerleaderPlayer.this.mState = 2;
                Iterator it = CheerleaderPlayer.this.mCheerleaderPlayerListeners.iterator();
                while (it.hasNext()) {
                    ((CheerleaderPlayerListener) it.next()).onPlayerPlay(trackObject, CheerleaderPlayer.this.mPlayerPlaylist.getCurrentTrackIndex());
                }
            }

            /* access modifiers changed from: protected */
            @Override // com.thedaw.uiuians.providers.soundcloud.player.player.PlaybackListener
            public void onPause() {
                super.onPause();
                CheerleaderPlayer.this.mState = 1;
                Iterator it = CheerleaderPlayer.this.mCheerleaderPlayerListeners.iterator();
                while (it.hasNext()) {
                    ((CheerleaderPlayerListener) it.next()).onPlayerPause();
                }
            }

            /* access modifiers changed from: protected */
            @Override // com.thedaw.uiuians.providers.soundcloud.player.player.PlaybackListener
            public void onPlayerDestroyed() {
                super.onPlayerDestroyed();
                CheerleaderPlayer.this.mState = 0;
                Iterator it = CheerleaderPlayer.this.mCheerleaderPlayerListeners.iterator();
                while (it.hasNext()) {
                    ((CheerleaderPlayerListener) it.next()).onPlayerDestroyed();
                }
                if (CheerleaderPlayer.this.mDestroyDelayed) {
                    CheerleaderPlayer.this.destroy();
                }
            }

            /* access modifiers changed from: protected */
            @Override // com.thedaw.uiuians.providers.soundcloud.player.player.PlaybackListener
            public void onSeekTo(int i) {
                super.onSeekTo(i);
                Iterator it = CheerleaderPlayer.this.mCheerleaderPlayerListeners.iterator();
                while (it.hasNext()) {
                    ((CheerleaderPlayerListener) it.next()).onPlayerSeekTo(i);
                }
            }

            /* access modifiers changed from: protected */
            @Override // com.thedaw.uiuians.providers.soundcloud.player.player.PlaybackListener
            public void onBufferingStarted() {
                super.onBufferingStarted();
                Iterator it = CheerleaderPlayer.this.mCheerleaderPlayerListeners.iterator();
                while (it.hasNext()) {
                    ((CheerleaderPlayerListener) it.next()).onBufferingStarted();
                }
            }

            /* access modifiers changed from: protected */
            @Override // com.thedaw.uiuians.providers.soundcloud.player.player.PlaybackListener
            public void onDurationChanged(long j) {
                super.onDurationChanged(j);
                Iterator it = CheerleaderPlayer.this.mCheerleaderPlayerListeners.iterator();
                while (it.hasNext()) {
                    ((CheerleaderPlayerListener) it.next()).onDurationChanged(j);
                }
            }

            /* access modifiers changed from: protected */
            @Override // com.thedaw.uiuians.providers.soundcloud.player.player.PlaybackListener
            public void onBufferingEnded() {
                super.onBufferingEnded();
                Iterator it = CheerleaderPlayer.this.mCheerleaderPlayerListeners.iterator();
                while (it.hasNext()) {
                    ((CheerleaderPlayerListener) it.next()).onBufferingEnded();
                }
            }

            /* access modifiers changed from: protected */
            @Override // com.thedaw.uiuians.providers.soundcloud.player.player.PlaybackListener
            public void onProgressChanged(int i) {
                super.onProgressChanged(i);
                Iterator it = CheerleaderPlayer.this.mCheerleaderPlayerListeners.iterator();
                while (it.hasNext()) {
                    ((CheerleaderPlayerListener) it.next()).onProgressChanged(i);
                }
            }
        };
        PlaybackService.registerListener(context, this.mInternalListener);
    }

    private void checkState() {
        if (this.mIsClosed) {
            throw new IllegalStateException("Client instance can't be used after being closed.");
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void setNotificationConfig(NotificationConfig notificationConfig) {
        this.mNotificationManager.setNotificationConfig(notificationConfig);
    }

    public static class Builder {
        private String apiKey;
        private Context context;
        private NotificationConfig notificationConfig = new NotificationConfig();

        public Builder() {
            this.notificationConfig.setNotificationIcon(R.drawable.ic_album_white);
            this.notificationConfig.setNotificationIconBackground(R.drawable.soundcloud_notification_icon_background);
        }

        public Builder from(Context context2) {
            this.context = context2;
            return this;
        }

        public Builder with(String str) {
            if (str == null) {
                throw new IllegalArgumentException("SoundCloud api can't be null");
            }
            this.apiKey = str;
            return this;
        }

        public Builder with(@StringRes int i) {
            if (this.context == null) {
                throw new IllegalStateException("Context should be set first.");
            }
            this.apiKey = this.context.getString(i);
            return this;
        }

        public Builder notificationIcon(@DrawableRes int i) {
            this.notificationConfig.setNotificationIcon(i);
            return this;
        }

        public Builder notificationIconBackground(@DrawableRes int i) {
            this.notificationConfig.setNotificationIconBackground(i);
            return this;
        }

        public Builder notificationActivity(Activity activity) {
            this.notificationConfig.setNotificationActivity(activity);
            return this;
        }

        public Builder notificationBundle(Bundle bundle) {
            this.notificationConfig.setNotificationBundle(bundle);
            return this;
        }

        public CheerleaderPlayer build() {
            if (this.context == null) {
                throw new IllegalStateException("Context should be passed using 'Builder.from' to build the client.");
            } else if (this.apiKey == null) {
                throw new IllegalStateException("Api key should be passed using 'Builder.with' to build the client.");
            } else {
                if (!this.apiKey.equals(CheerleaderPlayer.getInstance(this.context, this.apiKey).mClientKey)) {
                    throw new IllegalStateException("Only one api key can be used at the same time.");
                }
                CheerleaderPlayer.sInstance.setNotificationConfig(this.notificationConfig);
                return CheerleaderPlayer.sInstance;
            }
        }
    }
}

package com.thedaw.uiuians.providers.soundcloud.player.media;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.view.KeyEvent;
import com.thedaw.uiuians.providers.soundcloud.player.player.PlaybackService;

public class MediaSessionReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        if ("android.intent.action.MEDIA_BUTTON".equals(intent.getAction())) {
            KeyEvent keyEvent = (KeyEvent) intent.getParcelableExtra("android.intent.extra.KEY_EVENT");
            int keyCode = keyEvent.getKeyCode();
            int action = keyEvent.getAction();
            if (keyCode != 79 && keyCode != 85) {
                switch (keyCode) {
                    case 87:
                        if (action == 0) {
                            sendAction(context, "sherdle.universal.soundcloud.library.media.NEXT_TRACK");
                            return;
                        }
                        return;
                    case 88:
                        if (action == 0) {
                            sendAction(context, "com.sherdle.universal.providers.soundcloud.library.media.PREVIOUS_TRACK");
                            return;
                        }
                        return;
                    default:
                        return;
                }
            } else if (action == 0) {
                sendAction(context, "com.sherdle.universal.providers.soundcloud.library.media.TOGGLE_PLAYBACK");
            }
        }
    }

    private void sendAction(Context context, String str) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction(str);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }
}

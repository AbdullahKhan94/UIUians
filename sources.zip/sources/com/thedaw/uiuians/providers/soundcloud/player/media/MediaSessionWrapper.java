package com.thedaw.uiuians.providers.soundcloud.player.media;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.os.Build;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaButtonReceiver;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import com.google.android.exoplayer2.extractor.ts.PsExtractor;
import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;
import com.thedaw.uiuians.providers.soundcloud.player.remote.RemoteControlClientCompat;
import com.thedaw.uiuians.providers.soundcloud.player.remote.RemoteControlHelper;
import com.thedaw.uiuians.util.Log;

public class MediaSessionWrapper {
    static final String ACTION_NEXT_TRACK = "sherdle.universal.soundcloud.library.media.NEXT_TRACK";
    static final String ACTION_PREVIOUS_TRACK = "com.sherdle.universal.providers.soundcloud.library.media.PREVIOUS_TRACK";
    static final String ACTION_TOGGLE_PLAYBACK = "com.sherdle.universal.providers.soundcloud.library.media.TOGGLE_PLAYBACK";
    public static final int PLAYBACK_STATE_PAUSED = 2;
    public static final int PLAYBACK_STATE_PLAYING = 1;
    public static final int PLAYBACK_STATE_STOPPED = 0;
    private static final String TAG = "MediaSessionWrapper";
    private AudioManager mAudioManager;
    private MediaSessionWrapperCallback mCallback;
    private Context mContext;
    private LocalBroadcastManager mLocalBroadcastManager;
    private LockScreenReceiver mLockScreenReceiver;
    private ComponentName mMediaButtonReceiverComponent;
    private MediaSessionCompat mMediaSession;
    private RemoteControlClientCompat mRemoteControlClientCompat;
    private String mRuntimePackageName;

    public interface MediaSessionWrapperCallback {
        void onPause();

        void onPlay();

        void onPlayPauseToggle();

        void onSkipToNext();

        void onSkipToPrevious();
    }

    public MediaSessionWrapper(Context context, MediaSessionWrapperCallback mediaSessionWrapperCallback, AudioManager audioManager) {
        this.mContext = context;
        this.mCallback = mediaSessionWrapperCallback;
        this.mAudioManager = audioManager;
        this.mRuntimePackageName = context.getPackageName();
        initLockScreenRemoteControlClient(context);
        this.mMediaSession = new MediaSessionCompat(context, TAG, new ComponentName(context.getApplicationContext(), MediaButtonReceiver.class), null);
        this.mMediaSession.setCallback(new MediaSessionCallback());
        this.mMediaSession.setFlags(3);
    }

    public void onDestroy() {
        if (Build.VERSION.SDK_INT < 21) {
            this.mRemoteControlClientCompat.setPlaybackState(1);
            this.mAudioManager.unregisterMediaButtonEventReceiver(this.mMediaButtonReceiverComponent);
            this.mLocalBroadcastManager.unregisterReceiver(this.mLockScreenReceiver);
        }
        this.mMediaSession.release();
    }

    public void setPlaybackState(int i) {
        switch (i) {
            case 0:
                setRemoteControlClientPlaybackState(1);
                setMediaSessionCompatPlaybackState(1);
                return;
            case 1:
                this.mMediaSession.setActive(true);
                setRemoteControlClientPlaybackState(3);
                setMediaSessionCompatPlaybackState(3);
                return;
            case 2:
                setRemoteControlClientPlaybackState(2);
                setMediaSessionCompatPlaybackState(2);
                return;
            default:
                Log.e(TAG, "Unknown playback state.");
                return;
        }
    }

    public void setMetaData(TrackObject trackObject) {
        setMetaData(trackObject, null);
    }

    public void setMetaData(TrackObject trackObject, Bitmap bitmap) {
        if (Build.VERSION.SDK_INT < 21) {
            this.mRemoteControlClientCompat.setPlaybackState(3);
            RemoteControlClientCompat.MetadataEditorCompat putString = this.mRemoteControlClientCompat.editMetadata(true).putString(7, trackObject.getTitle()).putString(2, trackObject.getUsername());
            if (bitmap != null) {
                putString.putBitmap(100, bitmap);
            }
            putString.apply();
        }
        MediaMetadataCompat.Builder putString2 = new MediaMetadataCompat.Builder().putString(MediaMetadataCompat.METADATA_KEY_TITLE, trackObject.getTitle()).putString(MediaMetadataCompat.METADATA_KEY_ARTIST, trackObject.getUsername());
        if (bitmap != null) {
            putString2.putBitmap(MediaMetadataCompat.METADATA_KEY_ART, bitmap);
        }
        this.mMediaSession.setMetadata(putString2.build());
        setMediaSessionCompatPlaybackState(3);
    }

    private void setRemoteControlClientPlaybackState(int i) {
        if (Build.VERSION.SDK_INT < 21) {
            this.mRemoteControlClientCompat.setPlaybackState(i);
        }
    }

    private void setMediaSessionCompatPlaybackState(int i) {
        PlaybackStateCompat.Builder builder = new PlaybackStateCompat.Builder();
        builder.setState(i, -1, 1.0f);
        this.mMediaSession.setPlaybackState(builder.build());
    }

    private void initLockScreenRemoteControlClient(Context context) {
        if (Build.VERSION.SDK_INT < 21) {
            this.mMediaButtonReceiverComponent = new ComponentName(this.mRuntimePackageName, MediaSessionReceiver.class.getName());
            this.mAudioManager.registerMediaButtonEventReceiver(this.mMediaButtonReceiverComponent);
            if (this.mRemoteControlClientCompat == null) {
                Intent intent = new Intent("android.intent.action.MEDIA_BUTTON");
                intent.setComponent(this.mMediaButtonReceiverComponent);
                this.mRemoteControlClientCompat = new RemoteControlClientCompat(PendingIntent.getBroadcast(context, 0, intent, 0));
                RemoteControlHelper.registerRemoteControlClient(this.mAudioManager, this.mRemoteControlClientCompat);
            }
            this.mRemoteControlClientCompat.setPlaybackState(3);
            this.mRemoteControlClientCompat.setTransportControlFlags(PsExtractor.PRIVATE_STREAM_1);
            registerLockScreenReceiver(context);
        }
    }

    private void registerLockScreenReceiver(Context context) {
        this.mLockScreenReceiver = new LockScreenReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ACTION_TOGGLE_PLAYBACK);
        intentFilter.addAction(ACTION_NEXT_TRACK);
        intentFilter.addAction(ACTION_PREVIOUS_TRACK);
        this.mLocalBroadcastManager = LocalBroadcastManager.getInstance(context);
        this.mLocalBroadcastManager.registerReceiver(this.mLockScreenReceiver, intentFilter);
    }

    private final class MediaSessionCallback extends MediaSessionCompat.Callback {
        private MediaSessionCallback() {
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.Callback
        public void onPlay() {
            super.onPlay();
            MediaSessionWrapper.this.mCallback.onPlay();
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.Callback
        public void onPause() {
            super.onPause();
            MediaSessionWrapper.this.mCallback.onPause();
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.Callback
        public void onSkipToNext() {
            super.onSkipToNext();
            MediaSessionWrapper.this.mCallback.onSkipToNext();
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.Callback
        public void onSkipToPrevious() {
            super.onSkipToPrevious();
            MediaSessionWrapper.this.mCallback.onSkipToPrevious();
        }
    }

    /* access modifiers changed from: private */
    public final class LockScreenReceiver extends BroadcastReceiver {
        private LockScreenReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                String action = intent.getAction();
                char c = 65535;
                int hashCode = action.hashCode();
                if (hashCode != -715554800) {
                    if (hashCode != 545628985) {
                        if (hashCode == 1373933934 && action.equals(MediaSessionWrapper.ACTION_NEXT_TRACK)) {
                            c = 1;
                        }
                    } else if (action.equals(MediaSessionWrapper.ACTION_PREVIOUS_TRACK)) {
                        c = 2;
                    }
                } else if (action.equals(MediaSessionWrapper.ACTION_TOGGLE_PLAYBACK)) {
                    c = 0;
                }
                switch (c) {
                    case 0:
                        MediaSessionWrapper.this.mCallback.onPlayPauseToggle();
                        return;
                    case 1:
                        MediaSessionWrapper.this.mCallback.onSkipToNext();
                        return;
                    case 2:
                        MediaSessionWrapper.this.mCallback.onSkipToPrevious();
                        return;
                    default:
                        return;
                }
            }
        }
    }
}

package com.thedaw.uiuians.providers.soundcloud.player.player;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.NotificationCompat;
import android.widget.RemoteViews;
import com.onesignal.OneSignalDbContract;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.radio.player.MediaNotificationManager;
import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;
import com.thedaw.uiuians.providers.soundcloud.helpers.SoundCloudArtworkHelper;

/* access modifiers changed from: package-private */
public final class NotificationManager {
    private static final int NOTIFICATION_ID = 66;
    private static final int REQUEST_CODE_CLEAR = 64;
    private static final int REQUEST_CODE_NEXT = 32;
    private static final int REQUEST_CODE_PLAYBACK = 16;
    private static final int REQUEST_CODE_PREVIOUS = 48;
    static final int REQUEST_DISPLAYING_CONTROLLER = 1107313152;
    private static NotificationManager sInstance;
    private PendingIntent mClearPendingIntent;
    private Handler mMainThreadHandler;
    private PendingIntent mNextPendingIntent;
    private NotificationCompat.Builder mNotificationBuilder;
    private NotificationConfig mNotificationConfig;
    private RemoteViews mNotificationExpandedView;
    private android.app.NotificationManager mNotificationManager;
    private RemoteViews mNotificationView;
    private PendingIntent mPreviousPendingIntent;
    private PendingIntent mTogglePlaybackPendingIntent;
    private long mTrackId = -1;

    private NotificationManager(Context context) {
        this.mMainThreadHandler = new Handler(context.getApplicationContext().getMainLooper());
        this.mNotificationManager = (android.app.NotificationManager) context.getSystemService(OneSignalDbContract.NotificationTable.TABLE_NAME);
        initializePendingIntent(context);
    }

    public static NotificationManager getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new NotificationManager(context);
        }
        return sInstance;
    }

    public void setNotificationConfig(NotificationConfig notificationConfig) {
        this.mNotificationConfig = notificationConfig;
    }

    public void notify(Service service, final TrackObject trackObject, boolean z) {
        if (this.mNotificationBuilder == null) {
            initNotificationBuilder(service);
            createNotificationChannel(service);
        }
        this.mNotificationView.setTextViewText(R.id.simple_sound_cloud_notification_title, trackObject.getUsername());
        this.mNotificationView.setTextViewText(R.id.simple_sound_cloud_notification_subtitle, trackObject.getTitle());
        this.mNotificationExpandedView.setTextViewText(R.id.simple_sound_cloud_notification_title, trackObject.getUsername());
        this.mNotificationExpandedView.setTextViewText(R.id.simple_sound_cloud_notification_subtitle, trackObject.getTitle());
        if (z) {
            this.mNotificationView.setImageViewResource(R.id.simple_sound_cloud_notification_play, R.drawable.ic_play_white);
            this.mNotificationExpandedView.setImageViewResource(R.id.simple_sound_cloud_notification_play, R.drawable.ic_play_white);
        } else {
            this.mNotificationView.setImageViewResource(R.id.simple_sound_cloud_notification_play, R.drawable.ic_pause_white);
            this.mNotificationExpandedView.setImageViewResource(R.id.simple_sound_cloud_notification_play, R.drawable.ic_pause_white);
        }
        service.startForeground(66, buildNotification());
        long id = trackObject.getId();
        if (this.mTrackId == -1 || this.mTrackId != id) {
            final AnonymousClass1 r7 = new Target() {
                /* class com.thedaw.uiuians.providers.soundcloud.player.player.NotificationManager.AnonymousClass1 */

                @Override // com.squareup.picasso.Target
                public void onBitmapFailed(Exception exc, Drawable drawable) {
                }

                @Override // com.squareup.picasso.Target
                public void onPrepareLoad(Drawable drawable) {
                }

                @Override // com.squareup.picasso.Target
                public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom loadedFrom) {
                    NotificationManager.this.mNotificationView.setImageViewBitmap(R.id.simple_sound_cloud_notification_thumbnail, bitmap);
                    NotificationManager.this.mNotificationExpandedView.setImageViewBitmap(R.id.simple_sound_cloud_notification_thumbnail, bitmap);
                    NotificationManager.this.mNotificationExpandedView.setImageViewBitmap(R.id.simple_sound_cloud_notification_expanded_thumbnail, bitmap);
                    NotificationManager.this.mNotificationManager.notify(66, NotificationManager.this.buildNotification());
                }
            };
            this.mMainThreadHandler.post(new Runnable() {
                /* class com.thedaw.uiuians.providers.soundcloud.player.player.NotificationManager.AnonymousClass2 */

                public void run() {
                    Picasso.get().load(SoundCloudArtworkHelper.getArtworkUrl(trackObject, SoundCloudArtworkHelper.XLARGE)).into(r7);
                }
            });
            this.mTrackId = id;
        }
    }

    public void cancel() {
        this.mNotificationManager.cancel(66);
    }

    private void initializePendingIntent(Context context) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction("sound_cloud_toggle_playback");
        this.mTogglePlaybackPendingIntent = PendingIntent.getService(context, 16, intent, 134217728);
        Intent intent2 = new Intent(context, PlaybackService.class);
        intent2.setAction("sound_cloud_player_next");
        this.mNextPendingIntent = PendingIntent.getService(context, 32, intent2, 134217728);
        Intent intent3 = new Intent(context, PlaybackService.class);
        intent3.setAction("sound_cloud_player_previous");
        this.mPreviousPendingIntent = PendingIntent.getService(context, 48, intent3, 134217728);
        Intent intent4 = new Intent(context, PlaybackService.class);
        intent4.setAction("sound_cloud_player_clear");
        this.mClearPendingIntent = PendingIntent.getService(context, 64, intent4, 134217728);
    }

    private void initNotificationBuilder(Context context) {
        this.mNotificationBuilder = new NotificationCompat.Builder(context, MediaNotificationManager.NOTIFICATION_CHANNEL_ID);
        this.mNotificationView = new RemoteViews(context.getPackageName(), (int) R.layout.soundcloud_notification);
        this.mNotificationExpandedView = new RemoteViews(context.getPackageName(), (int) R.layout.soundcloud_notification_expanded);
        if (Build.VERSION.SDK_INT >= 21) {
            addSmallIcon(this.mNotificationView);
            addSmallIcon(this.mNotificationExpandedView);
        }
        this.mNotificationView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_previous, this.mPreviousPendingIntent);
        this.mNotificationExpandedView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_previous, this.mPreviousPendingIntent);
        this.mNotificationView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_next, this.mNextPendingIntent);
        this.mNotificationExpandedView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_next, this.mNextPendingIntent);
        this.mNotificationView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_play, this.mTogglePlaybackPendingIntent);
        this.mNotificationExpandedView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_play, this.mTogglePlaybackPendingIntent);
        this.mNotificationView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_clear, this.mClearPendingIntent);
        this.mNotificationExpandedView.setOnClickPendingIntent(R.id.simple_sound_cloud_notification_clear, this.mClearPendingIntent);
        this.mNotificationBuilder.setSmallIcon(this.mNotificationConfig.getNotificationIcon());
        this.mNotificationBuilder.setContent(this.mNotificationView);
        this.mNotificationBuilder.setPriority(1);
        Class<?> cls = this.mNotificationConfig.getNotificationActivity().getClass();
        if (cls != null) {
            Intent intent = new Intent(context, cls);
            Bundle notificationBundle = this.mNotificationConfig.getNotificationBundle();
            if (notificationBundle != null) {
                intent.putExtras(notificationBundle);
            }
            this.mNotificationBuilder.setContentIntent(PendingIntent.getActivity(context, REQUEST_DISPLAYING_CONTROLLER, intent, 134217728));
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private Notification buildNotification() {
        Notification build = this.mNotificationBuilder.build();
        if (Build.VERSION.SDK_INT >= 16) {
            build.bigContentView = this.mNotificationExpandedView;
        }
        return build;
    }

    private void createNotificationChannel(Context context) {
        android.app.NotificationManager notificationManager = (android.app.NotificationManager) context.getSystemService(OneSignalDbContract.NotificationTable.TABLE_NAME);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(MediaNotificationManager.NOTIFICATION_CHANNEL_ID, context.getString(R.string.audio_notification), 2);
            notificationChannel.enableVibration(false);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    private void addSmallIcon(RemoteViews remoteViews) {
        remoteViews.setInt(R.layout.soundcloud_notification_icon, "setBackgroundResource", this.mNotificationConfig.getNotificationIconBackground());
        remoteViews.setImageViewResource(R.layout.soundcloud_notification_icon, this.mNotificationConfig.getNotificationIcon());
    }
}

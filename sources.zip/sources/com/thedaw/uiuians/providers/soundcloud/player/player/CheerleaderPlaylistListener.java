package com.thedaw.uiuians.providers.soundcloud.player.player;

import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;

public interface CheerleaderPlaylistListener {
    void onTrackAdded(TrackObject trackObject);

    void onTrackRemoved(TrackObject trackObject, boolean z);
}

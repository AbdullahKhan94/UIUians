package com.thedaw.uiuians.providers.soundcloud.player.player;

import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;
import java.util.ArrayList;
import java.util.List;

/* access modifiers changed from: package-private */
public final class PlayerPlaylist {
    private static PlayerPlaylist sInstance;
    private int mCurrentTrackIndex = -1;
    private ArrayList<TrackObject> mTracks = new ArrayList<>();

    private PlayerPlaylist() {
    }

    public static PlayerPlaylist getInstance() {
        if (sInstance == null) {
            sInstance = new PlayerPlaylist();
        }
        return sInstance;
    }

    public ArrayList<TrackObject> getTracks() {
        return this.mTracks;
    }

    public TrackObject getCurrentTrack() {
        if (this.mCurrentTrackIndex <= -1 || this.mCurrentTrackIndex >= getTracks().size()) {
            return null;
        }
        return getTracks().get(this.mCurrentTrackIndex);
    }

    public int getCurrentTrackIndex() {
        return this.mCurrentTrackIndex;
    }

    public void add(TrackObject trackObject) {
        add(getTracks().size(), trackObject);
    }

    public void addAll(List<TrackObject> list) {
        for (TrackObject trackObject : list) {
            add(getTracks().size(), trackObject);
        }
    }

    public void add(int i, TrackObject trackObject) {
        if (this.mCurrentTrackIndex == -1) {
            this.mCurrentTrackIndex = 0;
        }
        this.mTracks.add(i, trackObject);
    }

    public TrackObject remove(int i) {
        ArrayList<TrackObject> tracks = getTracks();
        if (i < 0 || i >= tracks.size()) {
            return null;
        }
        TrackObject remove = tracks.remove(i);
        if (tracks.size() == 0) {
            this.mCurrentTrackIndex = 0;
            return remove;
        } else if (i == tracks.size()) {
            this.mCurrentTrackIndex = (this.mCurrentTrackIndex - 1) % tracks.size();
            return remove;
        } else if (i < 0 || i >= this.mCurrentTrackIndex) {
            return remove;
        } else {
            this.mCurrentTrackIndex = (this.mCurrentTrackIndex - 1) % tracks.size();
            return remove;
        }
    }

    public TrackObject next() {
        this.mCurrentTrackIndex = (this.mCurrentTrackIndex + 1) % getTracks().size();
        return getTracks().get(this.mCurrentTrackIndex);
    }

    public TrackObject previous() {
        int size = getTracks().size();
        this.mCurrentTrackIndex = ((this.mCurrentTrackIndex + size) - 1) % size;
        return getTracks().get(this.mCurrentTrackIndex);
    }

    public int size() {
        return getTracks().size();
    }

    public boolean isEmpty() {
        return getTracks().size() == 0;
    }

    /* access modifiers changed from: package-private */
    public void setPlayingTrack(int i) {
        if (i < 0 || i >= getTracks().size()) {
            throw new IllegalArgumentException("No tracks a the position " + i);
        }
        this.mCurrentTrackIndex = i;
    }
}

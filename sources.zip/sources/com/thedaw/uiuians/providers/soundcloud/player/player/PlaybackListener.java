package com.thedaw.uiuians.providers.soundcloud.player.player;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;
import com.thedaw.uiuians.util.Log;

/* access modifiers changed from: package-private */
public class PlaybackListener extends BroadcastReceiver {
    static final String ACTION_ON_BUFFERING_ENDED = "simple_sc_listener_action_on_buffering_end";
    static final String ACTION_ON_BUFFERING_STARTED = "simple_sc_listener_action_on_buffering_start";
    static final String ACTION_ON_DURATION_CHANGED = "simple_sc_listener_action_on_duration_changed";
    static final String ACTION_ON_PLAYER_DESTROYED = "simple_sc_listener_action_on_player_destroyed";
    static final String ACTION_ON_PLAYER_PAUSED = "simple_sc_listener_action_on_track_paused";
    static final String ACTION_ON_PROGRESS_CHANGED = "simple_sc_listener_action_on_progress_changed";
    static final String ACTION_ON_SEEK_COMPLETE = "simple_sc_listener_action_on_player_seek_complete";
    static final String ACTION_ON_TRACK_PLAYED = "simple_sc_listener_action_on_track_played";
    static final String EXTRA_KEY_CURRENT_TIME = "simple_sc_listener_extra_current_time";
    static final String EXTRA_KEY_DURATION = "simple_sc_listener_extra_duration";
    static final String EXTRA_KEY_TRACK = "simple_sc_listener_extra_track";
    private static final String TAG = "PlaybackListener";

    /* access modifiers changed from: protected */
    public void onBufferingEnded() {
    }

    /* access modifiers changed from: protected */
    public void onBufferingStarted() {
    }

    /* access modifiers changed from: protected */
    public void onDurationChanged(long j) {
    }

    /* access modifiers changed from: protected */
    public void onPause() {
    }

    /* access modifiers changed from: protected */
    public void onPlay(TrackObject trackObject) {
    }

    /* access modifiers changed from: protected */
    public void onPlayerDestroyed() {
    }

    /* access modifiers changed from: protected */
    public void onProgressChanged(int i) {
    }

    /* access modifiers changed from: protected */
    public void onSeekTo(int i) {
    }

    PlaybackListener() {
    }

    public void onReceive(Context context, Intent intent) {
        if (intent != null) {
            String action = intent.getAction();
            char c = 65535;
            switch (action.hashCode()) {
                case -1846616187:
                    if (action.equals(ACTION_ON_BUFFERING_STARTED)) {
                        c = 4;
                        break;
                    }
                    break;
                case -1727713118:
                    if (action.equals(ACTION_ON_PROGRESS_CHANGED)) {
                        c = 6;
                        break;
                    }
                    break;
                case -1427631938:
                    if (action.equals(ACTION_ON_BUFFERING_ENDED)) {
                        c = 5;
                        break;
                    }
                    break;
                case -826120951:
                    if (action.equals(ACTION_ON_DURATION_CHANGED)) {
                        c = 7;
                        break;
                    }
                    break;
                case -317944670:
                    if (action.equals(ACTION_ON_PLAYER_PAUSED)) {
                        c = 1;
                        break;
                    }
                    break;
                case -308375993:
                    if (action.equals(ACTION_ON_TRACK_PLAYED)) {
                        c = 0;
                        break;
                    }
                    break;
                case 394759234:
                    if (action.equals(ACTION_ON_SEEK_COMPLETE)) {
                        c = 2;
                        break;
                    }
                    break;
                case 568567867:
                    if (action.equals(ACTION_ON_PLAYER_DESTROYED)) {
                        c = 3;
                        break;
                    }
                    break;
            }
            switch (c) {
                case 0:
                    onPlay((TrackObject) intent.getSerializableExtra(EXTRA_KEY_TRACK));
                    return;
                case 1:
                    onPause();
                    return;
                case 2:
                    onSeekTo(intent.getIntExtra(EXTRA_KEY_CURRENT_TIME, 0));
                    return;
                case 3:
                    onPlayerDestroyed();
                    return;
                case 4:
                    onBufferingStarted();
                    return;
                case 5:
                    onBufferingEnded();
                    return;
                case 6:
                    onProgressChanged(intent.getIntExtra(EXTRA_KEY_CURRENT_TIME, 0));
                    return;
                case 7:
                    onDurationChanged(intent.getLongExtra(EXTRA_KEY_DURATION, 0));
                    return;
                default:
                    String str = TAG;
                    Log.e(str, "unknown action : " + intent.getAction());
                    return;
            }
        }
    }
}

package com.thedaw.uiuians.providers.soundcloud.player.player;

import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;

public interface CheerleaderPlayerListener {
    void onBufferingEnded();

    void onBufferingStarted();

    void onDurationChanged(long j);

    void onPlayerDestroyed();

    void onPlayerPause();

    void onPlayerPlay(TrackObject trackObject, int i);

    void onPlayerSeekTo(int i);

    void onProgressChanged(int i);
}

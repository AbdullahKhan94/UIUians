package com.thedaw.uiuians.providers.soundcloud.player.player;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.support.v4.content.LocalBroadcastManager;
import com.google.android.exoplayer2.source.chunk.ChunkedTrackBlacklistUtil;
import com.google.android.exoplayer2.util.MimeTypes;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;
import com.thedaw.uiuians.providers.soundcloud.helpers.SoundCloudArtworkHelper;
import com.thedaw.uiuians.providers.soundcloud.player.media.MediaSessionWrapper;
import com.thedaw.uiuians.util.Log;
import java.io.IOException;

public class PlaybackService extends Service implements MediaPlayer.OnErrorListener, MediaPlayer.OnCompletionListener, MediaPlayer.OnSeekCompleteListener, AudioManager.OnAudioFocusChangeListener, MediaPlayer.OnInfoListener, MediaPlayer.OnPreparedListener {
    static final String ACTION_AUDIO_BECOMING_NOISY = "sound_cloud_player_becoming_noisy";
    static final String ACTION_CLEAR_NOTIFICATION = "sound_cloud_player_clear";
    static final String ACTION_NEXT_TRACK = "sound_cloud_player_next";
    private static final String ACTION_PAUSE_PLAYER = "sound_cloud_player_resume";
    private static final String ACTION_PLAY = "sound_cloud_play";
    static final String ACTION_PREVIOUS_TRACK = "sound_cloud_player_previous";
    private static final String ACTION_RESUME_PLAYER = "sound_cloud_player_pause";
    private static final String ACTION_SEEK_TO = "sound_cloud_player_seek_to";
    private static final String ACTION_STOP_PLAYER = "sound_cloud_player_stop";
    static final String ACTION_TOGGLE_PLAYBACK = "sound_cloud_toggle_playback";
    private static final String BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID = "sound_cloud_player_bundle_key_client_id";
    private static final String BUNDLE_KEY_SOUND_CLOUD_TRACK = "sound_cloud_player_bundle_key_track_url";
    private static final String BUNDLE_KEY_SOUND_CLOUD_TRACK_POSITION = "sound_cloud_player_bundle_key_seek_to";
    private static final int IDLE_PERIOD_MILLI = 60000;
    private static final int MESSAGE_DELAY_MILLI = 100;
    private static final String SOUND_CLOUD_CLIENT_ID_PARAM = "?client_id=";
    private static final String TAG = "PlaybackService";
    private static final String THREAD_NAME = (TAG + "player_thread");
    private static final int WHAT_CLEAR_PLAYER = 9;
    private static final int WHAT_NEXT_TRACK = 3;
    private static final int WHAT_PAUSE_PLAYER = 1;
    private static final int WHAT_PLAY = 0;
    private static final int WHAT_PREVIOUS_TRACK = 4;
    private static final int WHAT_RELEASE_PLAYER = 7;
    private static final int WHAT_RESUME_PLAYER = 2;
    private static final int WHAT_SEEK_TO = 5;
    private static final int WHAT_STOP_PLAYER = 6;
    private static final String WIFI_LOCK_TAG = (TAG + "wifi_lock");
    private AudioManager mAudioManager;
    private CountDownTimer mCountDown;
    private HandlerThread mHandlerThread;
    private boolean mHasAlreadyPlayed;
    private boolean mIsPaused;
    private LocalBroadcastManager mLocalBroadcastManager;
    private Handler mMainThreadHandler;
    private MediaPlayer mMediaPlayer;
    private MediaSessionWrapper mMediaSession;
    private NotificationManager mNotificationManager;
    private Handler mPlayerHandler;
    private PlayerPlaylist mPlayerPlaylist;
    private String mSoundCloundClientId;
    private Handler mStopServiceHandler;
    private WifiManager.WifiLock mWifiLock;

    public IBinder onBind(Intent intent) {
        return null;
    }

    public static void play(Context context, String str, TrackObject trackObject) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction(ACTION_PLAY);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID, str);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_TRACK, trackObject);
        context.startService(intent);
    }

    public static void pause(Context context, String str) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction(ACTION_PAUSE_PLAYER);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID, str);
        context.startService(intent);
    }

    public static void resume(Context context, String str) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction(ACTION_RESUME_PLAYER);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID, str);
        context.startService(intent);
    }

    public static void stop(Context context, String str) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction(ACTION_STOP_PLAYER);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID, str);
        context.startService(intent);
    }

    public static void seekTo(Context context, String str, int i) {
        Intent intent = new Intent(context, PlaybackService.class);
        intent.setAction(ACTION_SEEK_TO);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID, str);
        intent.putExtra(BUNDLE_KEY_SOUND_CLOUD_TRACK_POSITION, i);
        context.startService(intent);
    }

    public static void registerListener(Context context, PlaybackListener playbackListener) {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("simple_sc_listener_action_on_track_played");
        intentFilter.addAction("simple_sc_listener_action_on_track_paused");
        intentFilter.addAction("simple_sc_listener_action_on_player_seek_complete");
        intentFilter.addAction("simple_sc_listener_action_on_player_destroyed");
        intentFilter.addAction("simple_sc_listener_action_on_buffering_start");
        intentFilter.addAction("simple_sc_listener_action_on_buffering_end");
        intentFilter.addAction("simple_sc_listener_action_on_progress_changed");
        intentFilter.addAction("simple_sc_listener_action_on_duration_changed");
        LocalBroadcastManager.getInstance(context.getApplicationContext()).registerReceiver(playbackListener, intentFilter);
    }

    public static void unregisterListener(Context context, PlaybackListener playbackListener) {
        LocalBroadcastManager.getInstance(context.getApplicationContext()).unregisterReceiver(playbackListener);
    }

    public void onCreate() {
        super.onCreate();
        this.mHandlerThread = new HandlerThread(THREAD_NAME, -16);
        this.mHandlerThread.start();
        this.mPlayerHandler = new PlayerHandler(this.mHandlerThread.getLooper());
        this.mMediaPlayer = new MediaPlayer();
        initializeMediaPlayer();
        this.mStopServiceHandler = new StopHandler(this.mHandlerThread.getLooper());
        this.mMainThreadHandler = new Handler(getApplicationContext().getMainLooper());
        this.mWifiLock = ((WifiManager) getBaseContext().getApplicationContext().getSystemService("wifi")).createWifiLock(1, WIFI_LOCK_TAG);
        this.mLocalBroadcastManager = LocalBroadcastManager.getInstance(getApplicationContext());
        this.mNotificationManager = NotificationManager.getInstance(this);
        this.mPlayerPlaylist = PlayerPlaylist.getInstance();
        this.mHasAlreadyPlayed = false;
        this.mAudioManager = (AudioManager) getSystemService(MimeTypes.BASE_TYPE_AUDIO);
        this.mMediaSession = new MediaSessionWrapper(this, new MediaSessionCallback(), this.mAudioManager);
    }

    public void onDestroy() {
        stopTimer();
        this.mAudioManager.abandonAudioFocus(this);
        this.mMediaSession.onDestroy();
        this.mPlayerHandler.removeCallbacksAndMessages(null);
        stopForeground(true);
        this.mLocalBroadcastManager.sendBroadcast(new Intent("simple_sc_listener_action_on_player_destroyed"));
        this.mMediaPlayer.release();
        this.mMediaPlayer = null;
        this.mHandlerThread.quit();
        super.onDestroy();
    }

    /* JADX INFO: Can't fix incorrect switch cases order, some code will duplicate */
    public int onStartCommand(Intent intent, int i, int i2) {
        char c;
        if (intent != null) {
            Message obtainMessage = this.mPlayerHandler.obtainMessage();
            Bundle extras = intent.getExtras();
            if (extras != null) {
                this.mSoundCloundClientId = extras.getString(BUNDLE_KEY_SOUND_CLOUD_CLIENT_ID);
                obtainMessage.setData(extras);
            }
            String action = intent.getAction();
            switch (action.hashCode()) {
                case -1076183447:
                    if (action.equals(ACTION_CLEAR_NOTIFICATION)) {
                        c = '\t';
                        break;
                    }
                    c = 65535;
                    break;
                case -1064489454:
                    if (action.equals(ACTION_RESUME_PLAYER)) {
                        c = 2;
                        break;
                    }
                    c = 65535;
                    break;
                case -714183333:
                    if (action.equals(ACTION_PREVIOUS_TRACK)) {
                        c = 5;
                        break;
                    }
                    c = 65535;
                    break;
                case -311488681:
                    if (action.equals(ACTION_NEXT_TRACK)) {
                        c = 4;
                        break;
                    }
                    c = 65535;
                    break;
                case -311325594:
                    if (action.equals(ACTION_STOP_PLAYER)) {
                        c = 3;
                        break;
                    }
                    c = 65535;
                    break;
                case 818650158:
                    if (action.equals(ACTION_PLAY)) {
                        c = 0;
                        break;
                    }
                    c = 65535;
                    break;
                case 1421460369:
                    if (action.equals(ACTION_PAUSE_PLAYER)) {
                        c = 1;
                        break;
                    }
                    c = 65535;
                    break;
                case 1434335596:
                    if (action.equals(ACTION_TOGGLE_PLAYBACK)) {
                        c = 7;
                        break;
                    }
                    c = 65535;
                    break;
                case 1971971927:
                    if (action.equals(ACTION_AUDIO_BECOMING_NOISY)) {
                        c = '\b';
                        break;
                    }
                    c = 65535;
                    break;
                case 1989862078:
                    if (action.equals(ACTION_SEEK_TO)) {
                        c = 6;
                        break;
                    }
                    c = 65535;
                    break;
                default:
                    c = 65535;
                    break;
            }
            switch (c) {
                case 0:
                    obtainMessage.what = 0;
                    break;
                case 1:
                    obtainMessage.what = 1;
                    break;
                case 2:
                    obtainMessage.what = 2;
                    break;
                case 3:
                    obtainMessage.what = 6;
                    break;
                case 4:
                    obtainMessage.what = 3;
                    break;
                case 5:
                    obtainMessage.what = 4;
                    break;
                case 6:
                    obtainMessage.what = 5;
                    break;
                case 7:
                    if (!this.mIsPaused) {
                        obtainMessage.what = 1;
                        break;
                    } else {
                        obtainMessage.what = 2;
                        break;
                    }
                case '\b':
                    if (!this.mIsPaused) {
                        obtainMessage.what = 1;
                        break;
                    }
                    break;
                case '\t':
                    obtainMessage.what = 9;
                    break;
            }
            gotoIdleState();
            this.mPlayerHandler.removeCallbacksAndMessages(null);
            this.mPlayerHandler.sendMessageDelayed(obtainMessage, 100);
        }
        return 1;
    }

    public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
        String str = TAG;
        Log.e(str, "MediaPlayer error occurred : " + i + " => reset mediaPlayer");
        initializeMediaPlayer();
        return true;
    }

    public void onCompletion(MediaPlayer mediaPlayer) {
        if (this.mWifiLock.isHeld()) {
            this.mWifiLock.release();
        }
        gotoIdleState();
        this.mPlayerHandler.sendEmptyMessage(3);
    }

    public void onSeekComplete(MediaPlayer mediaPlayer) {
        Intent intent = new Intent("simple_sc_listener_action_on_player_seek_complete");
        intent.putExtra("simple_sc_listener_extra_current_time", mediaPlayer.getCurrentPosition());
        this.mLocalBroadcastManager.sendBroadcast(intent);
        if (!this.mIsPaused) {
            resumeTimer();
        }
    }

    public void onAudioFocusChange(int i) {
        if (i != 1) {
            switch (i) {
                case -3:
                    if (!this.mIsPaused) {
                        this.mMediaPlayer.setVolume(0.1f, 0.1f);
                        return;
                    }
                    return;
                case -2:
                    if (!this.mIsPaused) {
                        pause();
                        return;
                    }
                    return;
                case -1:
                    if (!this.mIsPaused) {
                        pause();
                        return;
                    }
                    return;
                default:
                    return;
            }
        } else {
            if (this.mIsPaused) {
                resume();
            }
            this.mMediaPlayer.setVolume(1.0f, 1.0f);
        }
    }

    public boolean onInfo(MediaPlayer mediaPlayer, int i, int i2) {
        switch (i) {
            case 701:
                this.mLocalBroadcastManager.sendBroadcast(new Intent("simple_sc_listener_action_on_buffering_start"));
                return true;
            case 702:
                this.mLocalBroadcastManager.sendBroadcast(new Intent("simple_sc_listener_action_on_buffering_end"));
                return true;
            default:
                return false;
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void pause() {
        if (this.mHasAlreadyPlayed && !this.mIsPaused) {
            this.mIsPaused = true;
            this.mMediaPlayer.pause();
            this.mLocalBroadcastManager.sendBroadcast(new Intent("simple_sc_listener_action_on_track_paused"));
            updateNotification();
            this.mMediaSession.setPlaybackState(2);
            pauseTimer();
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void resume() {
        if (this.mIsPaused) {
            this.mIsPaused = false;
            if (this.mAudioManager.requestAudioFocus(this, 3, 1) == 1) {
                this.mMediaPlayer.start();
                Intent intent = new Intent("simple_sc_listener_action_on_track_played");
                intent.putExtra("simple_sc_listener_extra_track", this.mPlayerPlaylist.getCurrentTrack());
                this.mLocalBroadcastManager.sendBroadcast(intent);
                updateNotification();
                this.mMediaSession.setPlaybackState(1);
                resumeTimer();
            }
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void stopPlayer() {
        this.mMediaSession.setPlaybackState(0);
        this.mMediaPlayer.stop();
        this.mIsPaused = true;
        stopSelf();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void nextTrack() {
        playTrack(this.mPlayerPlaylist.next());
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void previousTrack() {
        playTrack(this.mPlayerPlaylist.previous());
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void seekToPosition(int i) {
        this.mMediaPlayer.seekTo(i);
    }

    private void initializeMediaPlayer() {
        this.mMediaPlayer.reset();
        this.mMediaPlayer.setWakeMode(getApplicationContext(), 1);
        this.mMediaPlayer.setAudioStreamType(3);
        this.mMediaPlayer.setOnCompletionListener(this);
        this.mMediaPlayer.setOnSeekCompleteListener(this);
        this.mMediaPlayer.setOnInfoListener(this);
        this.mMediaPlayer.setOnPreparedListener(this);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void playTrack(final TrackObject trackObject) {
        pauseTimer();
        try {
            this.mWifiLock.acquire();
            this.mMediaPlayer.reset();
            this.mMediaPlayer.setDataSource(trackObject.getLinkStream());
            this.mIsPaused = false;
            this.mHasAlreadyPlayed = true;
            updateNotification();
            this.mMediaSession.setPlaybackState(1);
            final AnonymousClass1 r1 = new Target() {
                /* class com.thedaw.uiuians.providers.soundcloud.player.player.PlaybackService.AnonymousClass1 */

                @Override // com.squareup.picasso.Target
                public void onBitmapFailed(Exception exc, Drawable drawable) {
                }

                @Override // com.squareup.picasso.Target
                public void onPrepareLoad(Drawable drawable) {
                }

                @Override // com.squareup.picasso.Target
                public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom loadedFrom) {
                    if (PlaybackService.this.mPlayerPlaylist.getCurrentTrack() != null) {
                        PlaybackService.this.mMediaSession.setMetaData(PlaybackService.this.mPlayerPlaylist.getCurrentTrack(), bitmap.copy(bitmap.getConfig(), false));
                    }
                }
            };
            this.mMainThreadHandler.post(new Runnable() {
                /* class com.thedaw.uiuians.providers.soundcloud.player.player.PlaybackService.AnonymousClass2 */

                public void run() {
                    Picasso.get().load(SoundCloudArtworkHelper.getArtworkUrl(trackObject, SoundCloudArtworkHelper.XLARGE)).into(r1);
                }
            });
            Intent intent = new Intent("simple_sc_listener_action_on_track_played");
            intent.putExtra("simple_sc_listener_extra_track", trackObject);
            this.mLocalBroadcastManager.sendBroadcast(intent);
            this.mLocalBroadcastManager.sendBroadcast(new Intent("simple_sc_listener_action_on_buffering_start"));
            if (this.mAudioManager.requestAudioFocus(this, 3, 1) == 1) {
                this.mMediaPlayer.prepare();
                this.mMediaPlayer.start();
                TrackObject currentTrack = this.mPlayerPlaylist.getCurrentTrack();
                if (currentTrack == null) {
                    this.mMediaPlayer.stop();
                } else {
                    startTimer(currentTrack.getDuration());
                }
                this.mLocalBroadcastManager.sendBroadcast(new Intent("simple_sc_listener_action_on_buffering_end"));
            }
        } catch (IOException unused) {
            String str = TAG;
            Log.e(str, "File referencing not exist : " + trackObject);
        }
    }

    private void updateNotification() {
        this.mNotificationManager.notify(this, this.mPlayerPlaylist.getCurrentTrack(), this.mIsPaused);
    }

    private void gotoIdleState() {
        this.mStopServiceHandler.removeCallbacksAndMessages(null);
        this.mStopServiceHandler.sendEmptyMessageDelayed(7, ChunkedTrackBlacklistUtil.DEFAULT_TRACK_BLACKLIST_MS);
    }

    private void startTimer(long j) {
        if (this.mCountDown != null) {
            this.mCountDown.cancel();
            this.mCountDown = null;
        }
        this.mCountDown = new CountDownTimer(j, 1000) {
            /* class com.thedaw.uiuians.providers.soundcloud.player.player.PlaybackService.AnonymousClass3 */

            public void onTick(long j) {
                Intent intent = new Intent("simple_sc_listener_action_on_progress_changed");
                intent.putExtra("simple_sc_listener_extra_current_time", PlaybackService.this.mMediaPlayer.getCurrentPosition());
                PlaybackService.this.mLocalBroadcastManager.sendBroadcast(intent);
            }

            public void onFinish() {
                Intent intent = new Intent("simple_sc_listener_action_on_progress_changed");
                intent.putExtra("simple_sc_listener_extra_current_time", (int) PlaybackService.this.mPlayerPlaylist.getCurrentTrack().getDuration());
                PlaybackService.this.mLocalBroadcastManager.sendBroadcast(intent);
            }
        };
        this.mCountDown.start();
    }

    private void pauseTimer() {
        if (this.mCountDown != null) {
            this.mCountDown.cancel();
            this.mCountDown = null;
        }
    }

    private void resumeTimer() {
        startTimer(this.mPlayerPlaylist.getCurrentTrack().getDuration() - ((long) this.mMediaPlayer.getCurrentPosition()));
    }

    private void stopTimer() {
        if (this.mCountDown != null) {
            this.mCountDown.cancel();
            this.mCountDown = null;
        }
    }

    public void onPrepared(MediaPlayer mediaPlayer) {
        TrackObject currentTrack = this.mPlayerPlaylist.getCurrentTrack();
        if (currentTrack.getDuration() == 0) {
            currentTrack.setDuration((long) mediaPlayer.getDuration());
            Intent intent = new Intent("simple_sc_listener_action_on_duration_changed");
            intent.putExtra("simple_sc_listener_extra_duration", (long) mediaPlayer.getDuration());
            this.mLocalBroadcastManager.sendBroadcast(intent);
            resumeTimer();
        }
    }

    private final class PlayerHandler extends Handler {
        public PlayerHandler(Looper looper) {
            super(looper);
        }

        public void handleMessage(Message message) {
            super.handleMessage(message);
            Bundle data = message.getData();
            int i = message.what;
            if (i != 9) {
                switch (i) {
                    case 0:
                        PlaybackService.this.playTrack((TrackObject) data.getSerializable(PlaybackService.BUNDLE_KEY_SOUND_CLOUD_TRACK));
                        return;
                    case 1:
                        PlaybackService.this.pause();
                        return;
                    case 2:
                        PlaybackService.this.resume();
                        return;
                    case 3:
                        PlaybackService.this.nextTrack();
                        return;
                    case 4:
                        PlaybackService.this.previousTrack();
                        return;
                    case 5:
                        PlaybackService.this.seekToPosition(data.getInt(PlaybackService.BUNDLE_KEY_SOUND_CLOUD_TRACK_POSITION));
                        return;
                    case 6:
                        PlaybackService.this.stopPlayer();
                        return;
                    default:
                        return;
                }
            } else {
                PlaybackService.this.stopSelf();
            }
        }
    }

    private final class MediaSessionCallback implements MediaSessionWrapper.MediaSessionWrapperCallback {
        private MediaSessionCallback() {
        }

        @Override // com.thedaw.uiuians.providers.soundcloud.player.media.MediaSessionWrapper.MediaSessionWrapperCallback
        public void onPlay() {
            PlaybackService.this.resume();
        }

        @Override // com.thedaw.uiuians.providers.soundcloud.player.media.MediaSessionWrapper.MediaSessionWrapperCallback
        public void onPause() {
            PlaybackService.this.pause();
        }

        @Override // com.thedaw.uiuians.providers.soundcloud.player.media.MediaSessionWrapper.MediaSessionWrapperCallback
        public void onSkipToNext() {
            PlaybackService.this.nextTrack();
        }

        @Override // com.thedaw.uiuians.providers.soundcloud.player.media.MediaSessionWrapper.MediaSessionWrapperCallback
        public void onSkipToPrevious() {
            PlaybackService.this.previousTrack();
        }

        @Override // com.thedaw.uiuians.providers.soundcloud.player.media.MediaSessionWrapper.MediaSessionWrapperCallback
        public void onPlayPauseToggle() {
            if (PlaybackService.this.mIsPaused) {
                PlaybackService.this.resume();
            } else {
                PlaybackService.this.pause();
            }
        }
    }

    private class StopHandler extends Handler {
        public StopHandler(Looper looper) {
            super(looper);
        }

        public void handleMessage(Message message) {
            super.handleMessage(message);
            if (message.what == 7 && PlaybackService.this.mIsPaused) {
                PlaybackService.this.stopSelf();
            }
        }
    }
}

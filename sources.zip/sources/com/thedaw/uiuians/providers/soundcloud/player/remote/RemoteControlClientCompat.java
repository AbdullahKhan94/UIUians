package com.thedaw.uiuians.providers.soundcloud.player.remote;

import android.app.PendingIntent;
import android.graphics.Bitmap;
import android.os.Looper;
import com.thedaw.uiuians.util.Log;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class RemoteControlClientCompat {
    private static final String TAG = "RemoteControlCompat";
    private static boolean sHasRemoteControlAPIs = true;
    private static Method sRCCEditMetadataMethod;
    private static Method sRCCSetPlayStateMethod;
    private static Method sRCCSetTransportControlFlags;
    private static Class sRemoteControlClientClass = getActualRemoteControlClientClass(RemoteControlClientCompat.class.getClassLoader());
    private Object mActualRemoteControlClient;

    /* JADX WARNING: Code restructure failed: missing block: B:22:?, code lost:
        return;
     */
    /* JADX WARNING: Removed duplicated region for block: B:15:? A[ExcHandler: ClassNotFoundException | IllegalArgumentException | NoSuchMethodException | SecurityException (unused java.lang.Throwable), SYNTHETIC, Splitter:B:7:0x002f] */
    static {
        Field[] fields = RemoteControlClientCompat.class.getFields();
        for (Field field : fields) {
            try {
                field.set(null, sRemoteControlClientClass.getField(field.getName()).get(null));
            } catch (NoSuchFieldException unused) {
                Log.w(TAG, "Could not get real field: " + field.getName());
            } catch (IllegalArgumentException e) {
                Log.w(TAG, "Error trying to pull field value for: " + field.getName() + " " + e.getMessage());
            } catch (IllegalAccessException e2) {
                try {
                    Log.w(TAG, "Error trying to pull field value for: " + field.getName() + " " + e2.getMessage());
                } catch (ClassNotFoundException | IllegalArgumentException | NoSuchMethodException | SecurityException unused2) {
                }
            }
        }
        sRCCEditMetadataMethod = sRemoteControlClientClass.getMethod("editMetadata", Boolean.TYPE);
        sRCCSetPlayStateMethod = sRemoteControlClientClass.getMethod("setPlaybackState", Integer.TYPE);
        sRCCSetTransportControlFlags = sRemoteControlClientClass.getMethod("setTransportControlFlags", Integer.TYPE);
    }

    public static Class getActualRemoteControlClientClass(ClassLoader classLoader) throws ClassNotFoundException {
        return classLoader.loadClass("android.media.RemoteControlClient");
    }

    public RemoteControlClientCompat(PendingIntent pendingIntent) {
        if (sHasRemoteControlAPIs) {
            try {
                this.mActualRemoteControlClient = sRemoteControlClientClass.getConstructor(PendingIntent.class).newInstance(pendingIntent);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    public RemoteControlClientCompat(PendingIntent pendingIntent, Looper looper) {
        if (sHasRemoteControlAPIs) {
            try {
                this.mActualRemoteControlClient = sRemoteControlClientClass.getConstructor(PendingIntent.class, Looper.class).newInstance(pendingIntent, looper);
            } catch (Exception e) {
                Log.e(TAG, "Error creating new instance of " + sRemoteControlClientClass.getName() + e.toString());
            }
        }
    }

    public class MetadataEditorCompat {
        public static final int METADATA_KEY_ARTWORK = 100;
        private final Object mActualMetadataEditor;
        private Method mApplyMethod;
        private Method mClearMethod;
        private Method mPutBitmapMethod;
        private Method mPutLongMethod;
        private Method mPutStringMethod;

        private MetadataEditorCompat(Object obj) {
            if (!RemoteControlClientCompat.sHasRemoteControlAPIs || obj != null) {
                if (RemoteControlClientCompat.sHasRemoteControlAPIs) {
                    Class<?> cls = obj.getClass();
                    try {
                        this.mPutStringMethod = cls.getMethod("putString", Integer.TYPE, String.class);
                        this.mPutBitmapMethod = cls.getMethod("putBitmap", Integer.TYPE, Bitmap.class);
                        this.mPutLongMethod = cls.getMethod("putLong", Integer.TYPE, Long.TYPE);
                        this.mClearMethod = cls.getMethod("clear", new Class[0]);
                        this.mApplyMethod = cls.getMethod("apply", new Class[0]);
                    } catch (Exception e) {
                        throw new RuntimeException(e.getMessage(), e);
                    }
                }
                this.mActualMetadataEditor = obj;
                return;
            }
            throw new IllegalArgumentException("Remote Control API's exist, should not be given a null MetadataEditor");
        }

        public MetadataEditorCompat putString(int i, String str) {
            if (RemoteControlClientCompat.sHasRemoteControlAPIs) {
                try {
                    this.mPutStringMethod.invoke(this.mActualMetadataEditor, Integer.valueOf(i), str);
                } catch (Exception e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
            }
            return this;
        }

        public MetadataEditorCompat putBitmap(int i, Bitmap bitmap) {
            if (RemoteControlClientCompat.sHasRemoteControlAPIs) {
                try {
                    this.mPutBitmapMethod.invoke(this.mActualMetadataEditor, Integer.valueOf(i), bitmap);
                } catch (Exception e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
            }
            return this;
        }

        public MetadataEditorCompat putLong(int i, long j) {
            if (RemoteControlClientCompat.sHasRemoteControlAPIs) {
                try {
                    this.mPutLongMethod.invoke(this.mActualMetadataEditor, Integer.valueOf(i), Long.valueOf(j));
                } catch (Exception e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
            }
            return this;
        }

        public void clear() {
            if (RemoteControlClientCompat.sHasRemoteControlAPIs) {
                try {
                    this.mClearMethod.invoke(this.mActualMetadataEditor, null);
                } catch (Exception e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
            }
        }

        public void apply() {
            if (RemoteControlClientCompat.sHasRemoteControlAPIs) {
                try {
                    this.mApplyMethod.invoke(this.mActualMetadataEditor, null);
                } catch (Exception e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
            }
        }
    }

    public MetadataEditorCompat editMetadata(boolean z) {
        Object obj;
        if (sHasRemoteControlAPIs) {
            try {
                obj = sRCCEditMetadataMethod.invoke(this.mActualRemoteControlClient, Boolean.valueOf(z));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else {
            obj = null;
        }
        return new MetadataEditorCompat(obj);
    }

    public void setPlaybackState(int i) {
        if (sHasRemoteControlAPIs) {
            try {
                sRCCSetPlayStateMethod.invoke(this.mActualRemoteControlClient, Integer.valueOf(i));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void setTransportControlFlags(int i) {
        if (sHasRemoteControlAPIs) {
            try {
                sRCCSetTransportControlFlags.invoke(this.mActualRemoteControlClient, Integer.valueOf(i));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    public final Object getActualRemoteControlClientObject() {
        return this.mActualRemoteControlClient;
    }
}

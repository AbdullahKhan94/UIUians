package com.thedaw.uiuians.providers.soundcloud.player.remote;

import android.media.AudioManager;
import com.thedaw.uiuians.util.Log;
import java.lang.reflect.Method;

public class RemoteControlHelper {
    private static final String TAG = "RemoteControlHelper";
    private static boolean sHasRemoteControlAPIs = true;
    private static Method sRegisterRemoteControlClientMethod;
    private static Method sUnregisterRemoteControlClientMethod;

    static {
        try {
            Class actualRemoteControlClientClass = RemoteControlClientCompat.getActualRemoteControlClientClass(RemoteControlHelper.class.getClassLoader());
            sRegisterRemoteControlClientMethod = AudioManager.class.getMethod("registerRemoteControlClient", actualRemoteControlClientClass);
            sUnregisterRemoteControlClientMethod = AudioManager.class.getMethod("unregisterRemoteControlClient", actualRemoteControlClientClass);
        } catch (ClassNotFoundException | IllegalArgumentException | NoSuchMethodException | SecurityException unused) {
        }
    }

    public static void registerRemoteControlClient(AudioManager audioManager, RemoteControlClientCompat remoteControlClientCompat) {
        if (sHasRemoteControlAPIs) {
            try {
                sRegisterRemoteControlClientMethod.invoke(audioManager, remoteControlClientCompat.getActualRemoteControlClientObject());
            } catch (Exception e) {
                Log.e(TAG, e.getMessage() + e.toString());
            }
        }
    }

    public static void unregisterRemoteControlClient(AudioManager audioManager, RemoteControlClientCompat remoteControlClientCompat) {
        if (sHasRemoteControlAPIs) {
            try {
                sUnregisterRemoteControlClientMethod.invoke(audioManager, remoteControlClientCompat.getActualRemoteControlClientObject());
            } catch (Exception e) {
                Log.e(TAG, e.getMessage() + e.toString());
            }
        }
    }
}

package com.thedaw.uiuians.providers.soundcloud;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.soundcloud.api.object.TrackObject;
import com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener;
import com.thedaw.uiuians.providers.soundcloud.ui.views.TrackView;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import java.util.List;

public class TracksAdapter extends InfiniteRecyclerViewAdapter implements CheerleaderPlayerListener {
    private static final int VIEW_TYPE_FOOTER = 3;
    private static final int VIEW_TYPE_HEADER = 2;
    private static final int VIEW_TYPE_TRACK = 1;
    private View mFooterView;
    private View mHeaderView;
    private TrackView.Listener mListener;
    private int mPlayedTrackPosition = -1;
    private List<TrackObject> mTracks;

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onBufferingEnded() {
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onBufferingStarted() {
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onDurationChanged(long j) {
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onPlayerDestroyed() {
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onPlayerPause() {
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onPlayerSeekTo(int i) {
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onProgressChanged(int i) {
    }

    public TracksAdapter(Context context, TrackView.Listener listener, List<TrackObject> list) {
        super(context, null);
        this.mTracks = list;
        this.mListener = listener;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getViewType(int i) {
        if (i != 0 || this.mHeaderView == null) {
            return (i != getItemCount() - 1 || this.mFooterView == null) ? 1 : 3;
        }
        return 2;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public RecyclerView.ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        switch (i) {
            case 1:
                TrackView trackView = new TrackView(viewGroup.getContext());
                trackView.setListener(this.mListener);
                trackView.setLayoutParams(new RecyclerView.LayoutParams(-1, -2));
                return new TrackHolder(trackView);
            case 2:
                return new HeaderHolder(this.mHeaderView);
            case 3:
                return new FooterHolder(this.mFooterView);
            default:
                throw new IllegalStateException("View type not handled : " + i);
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public void doBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        switch (viewHolder.getItemViewType()) {
            case 1:
                TrackHolder trackHolder = (TrackHolder) viewHolder;
                trackHolder.trackView.setModel(this.mTracks.get(i - (this.mHeaderView != null ? 1 : 0)));
                if (i == this.mPlayedTrackPosition) {
                    trackHolder.trackView.setBackgroundResource(R.drawable.soundcloud_selectable_background_selected);
                    trackHolder.trackView.setSelected(true);
                } else {
                    trackHolder.trackView.setBackgroundResource(R.drawable.soundcloud_selectable_background_white);
                    trackHolder.trackView.setSelected(false);
                }
                if (i == 0) {
                    trackHolder.trackView.findViewById(R.id.divider).setVisibility(8);
                    return;
                }
                return;
            case 2:
            case 3:
                return;
            default:
                throw new IllegalStateException("Unhandled view type : " + viewHolder.getItemViewType());
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getCount() {
        int i = 1;
        int i2 = this.mHeaderView == null ? 0 : 1;
        if (this.mFooterView == null) {
            i = 0;
        }
        return i2 + this.mTracks.size() + i;
    }

    @Override // com.thedaw.uiuians.providers.soundcloud.player.player.CheerleaderPlayerListener
    public void onPlayerPlay(TrackObject trackObject, int i) {
        this.mPlayedTrackPosition = i + (this.mHeaderView == null ? 0 : 1);
        notifyDataSetChanged();
    }

    public void setHeaderView(View view) {
        this.mHeaderView = view;
    }

    public void setFooterView(View view) {
        this.mFooterView = view;
    }

    public static abstract class Holder extends RecyclerView.ViewHolder {
        private int viewType;

        public Holder(View view, int i) {
            super(view);
            this.viewType = i;
        }
    }

    private static class TrackHolder extends Holder {
        private TrackView trackView;

        private TrackHolder(TrackView trackView2) {
            super(trackView2, 1);
            this.trackView = trackView2;
        }
    }

    private static class FooterHolder extends Holder {
        private FooterHolder(View view) {
            super(view, 3);
        }
    }

    private static class HeaderHolder extends Holder {
        private HeaderHolder(View view) {
            super(view, 2);
        }
    }
}

package com.thedaw.uiuians.providers.woocommerce.interceptor;

public interface TimestampService {
    String getNonce();

    String getTimestampInSeconds();
}

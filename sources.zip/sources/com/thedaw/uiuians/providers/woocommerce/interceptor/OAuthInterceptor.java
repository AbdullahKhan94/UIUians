package com.thedaw.uiuians.providers.woocommerce.interceptor;

import com.google.android.gms.actions.SearchIntents;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.thedaw.uiuians.util.Log;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class OAuthInterceptor implements Interceptor {
    private static final String BASIC_CONSUMER_KEY = "consumer_key";
    private static final String BASIC_CONSUMER_SECRET = "consumer_secret";
    private static final String OAUTH_CONSUMER_KEY = "oauth_consumer_key";
    private static final String OAUTH_NONCE = "oauth_nonce";
    private static final String OAUTH_SIGNATURE = "oauth_signature";
    private static final String OAUTH_SIGNATURE_METHOD = "oauth_signature_method";
    private static final String OAUTH_SIGNATURE_METHOD_VALUE = "HMAC-SHA1";
    private static final String OAUTH_TIMESTAMP = "oauth_timestamp";
    private static final String OAUTH_VERSION = "oauth_version";
    private static final String OAUTH_VERSION_VALUE = "1.0";
    private final boolean OAUTH;
    private final String consumerKey;
    private final String consumerSecret;

    private OAuthInterceptor(String str, String str2) {
        this.OAUTH = true;
        this.consumerKey = str;
        this.consumerSecret = str2;
    }

    @Override // okhttp3.Interceptor
    public Response intercept(Interceptor.Chain chain) throws IOException {
        String str;
        Request request = chain.request();
        HttpUrl url = request.url();
        Log.d("URL", request.url().toString());
        Log.d("URL", request.url().scheme());
        Log.d("encodedpath", request.url().encodedPath());
        Log.d(SearchIntents.EXTRA_QUERY, "" + request.url().query());
        Log.d("path", "" + request.url().host());
        Log.d("encodedQuery", "" + request.url().encodedQuery());
        Log.d(FirebaseAnalytics.Param.METHOD, "" + request.method());
        String nonce = new TimestampServiceImpl().getNonce();
        String timestampInSeconds = new TimestampServiceImpl().getTimestampInSeconds();
        Log.d("nonce", nonce);
        Log.d("time", timestampInSeconds);
        String str2 = request.url().scheme() + "://" + request.url().host() + request.url().encodedPath();
        Log.d("ENCODED PATH", "" + str2);
        String str3 = request.method() + "&" + urlEncoded(str2);
        Log.d("firstBaseString", str3);
        if (request.url().encodedQuery() != null) {
            str = request.url().encodedQuery() + "&oauth_consumer_key=" + this.consumerKey + "&oauth_nonce=" + nonce + "&oauth_signature_method=HMAC-SHA1&oauth_timestamp=" + timestampInSeconds + "&oauth_version=1.0";
        } else {
            str = "oauth_consumer_key=" + this.consumerKey + "&oauth_nonce=" + nonce + "&oauth_signature_method=HMAC-SHA1&oauth_timestamp=" + timestampInSeconds + "&oauth_version=1.0";
        }
        ParameterList parameterList = new ParameterList();
        parameterList.addQuerystring(str);
        String asOauthBaseString = parameterList.sort().asOauthBaseString();
        Log.d("Sorted", "00--" + parameterList.sort().asOauthBaseString());
        String str4 = "&" + asOauthBaseString;
        if (str3.contains("%3F")) {
            Log.d("iff", "yess iff");
            str4 = "%26" + urlEncoded(asOauthBaseString);
        }
        String signature = new HMACSha1SignatureService().getSignature(str3 + str4, this.consumerSecret, "");
        Log.d("Signature", signature);
        return chain.proceed(request.newBuilder().url(url.newBuilder().addQueryParameter(OAUTH_SIGNATURE_METHOD, OAUTH_SIGNATURE_METHOD_VALUE).addQueryParameter(OAUTH_CONSUMER_KEY, this.consumerKey).addQueryParameter(OAUTH_VERSION, "1.0").addQueryParameter(OAUTH_TIMESTAMP, timestampInSeconds).addQueryParameter(OAUTH_NONCE, nonce).addQueryParameter(OAUTH_SIGNATURE, signature).build()).build());
    }

    public static final class Builder {
        private String consumerKey;
        private String consumerSecret;
        private int type;

        public Builder consumerKey(String str) {
            if (str == null) {
                throw new NullPointerException("consumerKey = null");
            }
            this.consumerKey = str;
            return this;
        }

        public Builder consumerSecret(String str) {
            if (str == null) {
                throw new NullPointerException("consumerSecret = null");
            }
            this.consumerSecret = str;
            return this;
        }

        public OAuthInterceptor build() {
            if (this.consumerKey == null) {
                throw new IllegalStateException("consumerKey not set");
            } else if (this.consumerSecret != null) {
                return new OAuthInterceptor(this.consumerKey, this.consumerSecret);
            } else {
                throw new IllegalStateException("consumerSecret not set");
            }
        }
    }

    public String urlEncoded(String str) {
        UnsupportedEncodingException e;
        String str2 = "";
        try {
            String encode = URLEncoder.encode(str, "UTF-8");
            try {
                Log.d("TEST", encode);
                return encode;
            } catch (UnsupportedEncodingException e2) {
                str2 = encode;
                e = e2;
            }
        } catch (UnsupportedEncodingException e3) {
            e = e3;
            e.printStackTrace();
            return str2;
        }
    }
}

package com.thedaw.uiuians.providers.woocommerce.interceptor;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class OAuthEncoder {
    private static String CHARSET = "UTF-8";
    private static final Map<String, String> ENCODING_RULES;

    static {
        HashMap hashMap = new HashMap();
        hashMap.put("*", "%2A");
        hashMap.put("+", "%20");
        hashMap.put("%7E", "~");
        ENCODING_RULES = Collections.unmodifiableMap(hashMap);
    }

    private OAuthEncoder() {
    }

    public static String encode(String str) {
        try {
            String encode = URLEncoder.encode(str, CHARSET);
            for (Map.Entry<String, String> entry : ENCODING_RULES.entrySet()) {
                encode = applyRule(encode, entry.getKey(), entry.getValue());
            }
            return encode;
        } catch (UnsupportedEncodingException e) {
            throw new OAuthException("Charset not found while encoding string: " + CHARSET, e);
        }
    }

    private static String applyRule(String str, String str2, String str3) {
        return str.replaceAll(Pattern.quote(str2), str3);
    }

    public static String decode(String str) {
        try {
            return URLDecoder.decode(str, CHARSET);
        } catch (UnsupportedEncodingException e) {
            throw new OAuthException("Charset not found while decoding string: " + CHARSET, e);
        }
    }
}

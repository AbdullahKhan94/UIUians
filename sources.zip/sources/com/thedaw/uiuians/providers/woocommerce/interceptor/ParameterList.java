package com.thedaw.uiuians.providers.woocommerce.interceptor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class ParameterList {
    private static final String EMPTY_STRING = "";
    private static final String PAIR_SEPARATOR = "=";
    private static final String PARAM_SEPARATOR = "&";
    private static final char QUERY_STRING_SEPARATOR = '?';
    private final List<Parameter> params;

    public ParameterList() {
        this.params = new ArrayList();
    }

    ParameterList(List<Parameter> list) {
        this.params = new ArrayList(list);
    }

    public ParameterList(Map<String, String> map) {
        this();
        if (!(map == null || map.isEmpty())) {
            for (Map.Entry<String, String> entry : map.entrySet()) {
                this.params.add(new Parameter(entry.getKey(), entry.getValue()));
            }
        }
    }

    public void add(String str, String str2) {
        this.params.add(new Parameter(str, str2));
    }

    public String appendTo(String str) {
        Preconditions.checkNotNull(str, "Cannot append to null URL");
        String asFormUrlEncodedString = asFormUrlEncodedString();
        if (asFormUrlEncodedString.equals("")) {
            return str;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append(str.indexOf(63) == -1 ? Character.valueOf(QUERY_STRING_SEPARATOR) : PARAM_SEPARATOR);
        sb.append(asFormUrlEncodedString);
        return sb.toString();
    }

    public String asOauthBaseString() {
        return OAuthEncoder.encode(asFormUrlEncodedString());
    }

    public String asFormUrlEncodedString() {
        if (this.params.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (Parameter parameter : this.params) {
            sb.append(PARAM_SEPARATOR);
            sb.append(parameter.asUrlEncodedPair());
        }
        return sb.substring(1);
    }

    public void addAll(ParameterList parameterList) {
        this.params.addAll(parameterList.getParams());
    }

    public void addQuerystring(String str) {
        if (!(str == null || str.isEmpty())) {
            for (String str2 : str.split(PARAM_SEPARATOR)) {
                String[] split = str2.split(PAIR_SEPARATOR);
                this.params.add(new Parameter(OAuthEncoder.decode(split[0]), split.length > 1 ? OAuthEncoder.decode(split[1]) : ""));
            }
        }
    }

    public boolean contains(Parameter parameter) {
        return this.params.contains(parameter);
    }

    public int size() {
        return this.params.size();
    }

    public List<Parameter> getParams() {
        return this.params;
    }

    public ParameterList sort() {
        ParameterList parameterList = new ParameterList(this.params);
        Collections.sort(parameterList.getParams());
        return parameterList;
    }
}

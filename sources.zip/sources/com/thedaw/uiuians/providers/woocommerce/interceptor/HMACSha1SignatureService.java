package com.thedaw.uiuians.providers.woocommerce.interceptor;

import android.util.Base64;
import com.thedaw.uiuians.util.Log;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class HMACSha1SignatureService implements SignatureService {
    private static final String CARRIAGE_RETURN = "\r\n";
    private static final String EMPTY_STRING = "";
    private static final String HMAC_SHA1 = "HmacSHA1";
    private static final String METHOD = "HMAC-SHA1";
    private static final String UTF8 = "UTF-8";

    @Override // com.thedaw.uiuians.providers.woocommerce.interceptor.SignatureService
    public String getSignatureMethod() {
        return METHOD;
    }

    @Override // com.thedaw.uiuians.providers.woocommerce.interceptor.SignatureService
    public String getSignature(String str, String str2, String str3) {
        try {
            Preconditions.checkEmptyString(str, "Base string cant be null or empty string");
            Preconditions.checkEmptyString(str2, "Api secret cant be null or empty string");
            return doSign(str, OAuthEncoder.encode(str2) + '&' + OAuthEncoder.encode(str3));
        } catch (Exception e) {
            throw new OAuthSignatureException(str, e);
        }
    }

    private String doSign(String str, String str2) throws Exception {
        Log.d("is it signing", "----------------------" + str);
        Log.d("is 22222222", str2 + "");
        SecretKeySpec secretKeySpec = new SecretKeySpec(str2.getBytes("UTF-8"), HMAC_SHA1);
        Mac instance = Mac.getInstance(HMAC_SHA1);
        instance.init(secretKeySpec);
        return bytesToBase64String(instance.doFinal(str.getBytes("UTF-8"))).replace(CARRIAGE_RETURN, "");
    }

    private String bytesToBase64String(byte[] bArr) {
        return Base64.encodeToString(bArr, 2);
    }
}

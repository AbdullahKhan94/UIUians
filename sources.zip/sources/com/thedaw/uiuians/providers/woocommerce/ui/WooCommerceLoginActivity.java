package com.thedaw.uiuians.providers.woocommerce.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.woocommerce.WooCommerceTask;
import com.thedaw.uiuians.providers.woocommerce.model.CredentialStorage;
import com.thedaw.uiuians.providers.woocommerce.model.RestAPI;
import com.thedaw.uiuians.providers.woocommerce.model.users.User;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class WooCommerceLoginActivity extends AppCompatActivity {
    private OkHttpClient client;
    private EditText mEmailView;
    private View mLoginFormView;
    private EditText mPasswordView;
    private View mProgressView;

    /* access modifiers changed from: protected */
    @Override // android.support.v7.app.AppCompatActivity, android.support.v4.app.SupportActivity, android.support.v4.app.FragmentActivity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_woocommerce_login);
        this.mEmailView = (EditText) findViewById(R.id.user);
        this.mPasswordView = (EditText) findViewById(R.id.password);
        this.mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceLoginActivity.AnonymousClass1 */

            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i != 6 && i != 0) {
                    return false;
                }
                WooCommerceLoginActivity.this.attemptLogin();
                return true;
            }
        });
        ((TextView) findViewById(R.id.user_register_button)).setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceLoginActivity.AnonymousClass2 */

            public void onClick(View view) {
                RestAPI restAPI = new RestAPI(WooCommerceLoginActivity.this);
                WooCommerceLoginActivity wooCommerceLoginActivity = WooCommerceLoginActivity.this;
                HolderActivity.startWebViewActivity(wooCommerceLoginActivity, restAPI.getHost() + restAPI.getRegister(), false, false, null);
            }
        });
        ((Button) findViewById(R.id.user_sign_in_button)).setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceLoginActivity.AnonymousClass3 */

            public void onClick(View view) {
                WooCommerceLoginActivity.this.attemptLogin();
            }
        });
        this.mLoginFormView = findViewById(R.id.login_form);
        this.mProgressView = findViewById(R.id.login_progress);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x006a  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x006e  */
    private void attemptLogin() {
        boolean z;
        EditText editText = null;
        this.mEmailView.setError(null);
        this.mPasswordView.setError(null);
        String obj = this.mEmailView.getText().toString();
        String obj2 = this.mPasswordView.getText().toString();
        if (TextUtils.isEmpty(obj2) || isPasswordValid(obj2)) {
            z = false;
        } else {
            this.mPasswordView.setError(getString(R.string.error_invalid_password));
            editText = this.mPasswordView;
            z = true;
        }
        if (TextUtils.isEmpty(obj)) {
            this.mEmailView.setError(getString(R.string.error_field_required));
            editText = this.mEmailView;
        } else {
            if (!isEmailValid(obj)) {
                this.mEmailView.setError(getString(R.string.error_invalid_email));
                editText = this.mEmailView;
            }
            if (!z) {
                editText.requestFocus();
                return;
            }
            showProgress(true);
            attemptLogin(obj, obj2);
            return;
        }
        z = true;
        if (!z) {
        }
    }

    private boolean isEmailValid(String str) {
        return str.contains("@") && str.contains(".");
    }

    private boolean isPasswordValid(String str) {
        return str.length() > 3;
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    @TargetApi(13)
    private void showProgress(final boolean z) {
        int i = 0;
        if (Build.VERSION.SDK_INT >= 13) {
            int integer = getResources().getInteger(17694720);
            this.mLoginFormView.setVisibility(z ? 8 : 0);
            long j = (long) integer;
            float f = 1.0f;
            this.mLoginFormView.animate().setDuration(j).alpha(z ? 0.0f : 1.0f).setListener(new AnimatorListenerAdapter() {
                /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceLoginActivity.AnonymousClass4 */

                public void onAnimationEnd(Animator animator) {
                    WooCommerceLoginActivity.this.mLoginFormView.setVisibility(z ? 8 : 0);
                }
            });
            View view = this.mProgressView;
            if (!z) {
                i = 8;
            }
            view.setVisibility(i);
            ViewPropertyAnimator duration = this.mProgressView.animate().setDuration(j);
            if (!z) {
                f = 0.0f;
            }
            duration.alpha(f).setListener(new AnimatorListenerAdapter() {
                /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceLoginActivity.AnonymousClass5 */

                public void onAnimationEnd(Animator animator) {
                    WooCommerceLoginActivity.this.mProgressView.setVisibility(z ? 0 : 8);
                }
            });
            return;
        }
        this.mProgressView.setVisibility(z ? 0 : 8);
        View view2 = this.mLoginFormView;
        if (z) {
            i = 8;
        }
        view2.setVisibility(i);
    }

    /* access modifiers changed from: package-private */
    public void attemptLogin(final String str, final String str2) {
        FormBody build = new FormBody.Builder().add("log", str).add("pwd", str2).build();
        final RestAPI restAPI = new RestAPI(getApplication());
        Request.Builder builder = new Request.Builder();
        Request build2 = builder.url(restAPI.getHost() + restAPI.getLogin()).post(build).build();
        Log.i("INFO", "Requesting: " + build2.url());
        new OkHttpClient.Builder().connectTimeout(25, TimeUnit.SECONDS).writeTimeout(25, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build().newCall(build2).enqueue(new Callback() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceLoginActivity.AnonymousClass6 */

            @Override // okhttp3.Callback
            public void onFailure(Call call, IOException iOException) {
                iOException.printStackTrace();
                WooCommerceLoginActivity.this.runOnUiThread(new Runnable() {
                    /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceLoginActivity.AnonymousClass6.AnonymousClass1 */

                    public void run() {
                        Helper.isOnlineShowDialog(WooCommerceLoginActivity.this);
                    }
                });
                WooCommerceLoginActivity.this.loginAttemptCompleted(false);
            }

            @Override // okhttp3.Callback
            public void onResponse(Call call, Response response) throws IOException {
                response.close();
                List<String> values = response.headers().values("Set-Cookie");
                for (String str : values) {
                    Log.i("Cookie", str);
                    if (str.startsWith(restAPI.getLoginCookie())) {
                        WooCommerceLoginActivity.this.retrieveUserData(str, str2);
                        return;
                    }
                }
                if (values.size() == 0) {
                    WooCommerceDebugDialog.showDialogIfNoCookies(WooCommerceLoginActivity.this);
                }
                WooCommerceLoginActivity.this.loginAttemptCompleted(false);
            }
        });
    }

    public void retrieveUserData(final String str, final String str2) {
        new WooCommerceTask.WooCommerceBuilder(this).getUsers(new WooCommerceTask.Callback<User>() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceLoginActivity.AnonymousClass7 */

            @Override // com.thedaw.uiuians.providers.woocommerce.WooCommerceTask.Callback
            public void success(ArrayList<User> arrayList) {
                if (arrayList.size() == 1) {
                    User user = arrayList.get(0);
                    CredentialStorage.saveCredentials(WooCommerceLoginActivity.this, str, str2, user.getId().intValue(), user.getFirstName());
                    WooCommerceLoginActivity.this.loginAttemptCompleted(true);
                    return;
                }
                if (arrayList.size() == 0) {
                    Log.e("INFO", "No Customers found with this email. Perhaps this person is a user, but not a customer");
                } else {
                    Log.e("INFO", "More than 1 Customer found with this email");
                }
                WooCommerceLoginActivity.this.loginAttemptCompleted(false);
            }

            @Override // com.thedaw.uiuians.providers.woocommerce.WooCommerceTask.Callback
            public void failed() {
                WooCommerceLoginActivity.this.loginAttemptCompleted(false);
            }
        }, str).execute(new Void[0]);
    }

    public void loginAttemptCompleted(final Boolean bool) {
        runOnUiThread(new Runnable() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceLoginActivity.AnonymousClass8 */

            public void run() {
                WooCommerceLoginActivity.this.showProgress(false);
                if (bool.booleanValue()) {
                    WooCommerceLoginActivity.this.finish();
                    return;
                }
                WooCommerceLoginActivity.this.mEmailView.setError(WooCommerceLoginActivity.this.getString(R.string.error_incorrect_credentials));
                WooCommerceLoginActivity.this.mPasswordView.setError(WooCommerceLoginActivity.this.getString(R.string.error_incorrect_credentials));
                WooCommerceLoginActivity.this.mPasswordView.requestFocus();
            }
        });
    }
}

package com.thedaw.uiuians.providers.woocommerce.ui;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.woocommerce.WooCommerceProductFilter;
import com.thedaw.uiuians.providers.woocommerce.WooCommerceTask;
import com.thedaw.uiuians.providers.woocommerce.adapter.ProductsAdapter;
import com.thedaw.uiuians.providers.woocommerce.model.RestAPI;
import com.thedaw.uiuians.providers.woocommerce.model.products.Category;
import com.thedaw.uiuians.providers.woocommerce.model.products.Image;
import com.thedaw.uiuians.providers.woocommerce.model.products.Product;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import com.thedaw.uiuians.util.Log;
import com.thedaw.uiuians.util.ThemeUtils;
import com.thedaw.uiuians.util.ViewModeUtils;
import com.thedaw.uiuians.util.layout.StaggeredGridSpacingItemDecoration;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jsoup.helper.StringUtil;

public class WooCommerceFragment extends Fragment implements WooCommerceTask.Callback<Product>, InfiniteRecyclerViewAdapter.LoadMoreListener {
    private static final String FEATURED = "featured";
    private static final String HOME = "home";
    private static final String SALE = "sale";
    private int category;
    private WooCommerceProductFilter filter;
    private List<String> headerImages;
    private boolean isHomePage = false;
    private Activity mAct;
    private int page = 1;
    private List<Product> productList;
    private ProductsAdapter productsAdapter;
    private RecyclerView recyclerView;
    private MenuItem searchMenu;
    private String searchQuery;
    private SearchView searchView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ViewModeUtils viewModeUtils;

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_list_refresh, viewGroup, false);
    }

    @Override // android.support.v4.app.Fragment
    public void onViewCreated(View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        setHasOptionsMenu(true);
        this.recyclerView = (RecyclerView) view.findViewById(R.id.list);
        this.swipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipeRefreshLayout);
        this.productList = new ArrayList();
        this.productsAdapter = new ProductsAdapter(getContext(), this.productList, this);
        this.productsAdapter.setModeAndNotify(3);
        this.recyclerView.setAdapter(this.productsAdapter);
        this.mAct = getActivity();
        this.filter = new WooCommerceProductFilter();
        String[] stringArray = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        if (stringArray.length > 0 && stringArray[0].matches("^-?\\d+$")) {
            this.category = Integer.parseInt(stringArray[0]);
        } else if (stringArray.length > 0 && stringArray[0].equals(HOME)) {
            this.isHomePage = true;
        } else if (stringArray.length > 0 && stringArray[0].equals(FEATURED)) {
            this.filter.onlyFeatured(true);
        } else if (stringArray.length > 0 && stringArray[0].equals(SALE)) {
            this.filter.onlySale(true);
        }
        this.headerImages = new ArrayList();
        if (stringArray.length > 1 && stringArray[1].startsWith("http")) {
            this.headerImages.add(stringArray[1]);
            if (stringArray.length > 2 && stringArray[2].startsWith("http")) {
                this.headerImages.add(stringArray[2]);
            }
        }
        setViewMode();
        this.recyclerView.addItemDecoration(new StaggeredGridSpacingItemDecoration((int) getResources().getDimension(R.dimen.woocommerce_padding), true));
        this.recyclerView.setItemAnimator(new DefaultItemAnimator());
        this.recyclerView.setBackgroundColor(getResources().getColor(R.color.white));
        if (getString(R.string.woocommerce_url).isEmpty() || !getString(R.string.woocommerce_url).startsWith("http")) {
            Toast.makeText(this.mAct, "You need to enter a valid WooCommerce url and API tokens as documented!", 0).show();
            return;
        }
        refreshItems();
        updateHeaders();
        this.swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment.AnonymousClass1 */

            @Override // android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener
            public void onRefresh() {
                WooCommerceFragment.this.refreshItems();
            }
        });
    }

    @Override // com.thedaw.uiuians.providers.woocommerce.WooCommerceTask.Callback
    public void success(ArrayList<Product> arrayList) {
        if (arrayList.size() > 0) {
            this.productList.addAll(arrayList);
        } else {
            this.productsAdapter.setHasMore(false);
        }
        this.productsAdapter.setModeAndNotify(1);
        this.swipeRefreshLayout.setRefreshing(false);
    }

    @Override // com.thedaw.uiuians.providers.woocommerce.WooCommerceTask.Callback
    public void failed() {
        this.productsAdapter.setModeAndNotify(2);
        this.swipeRefreshLayout.setRefreshing(false);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void refreshItems() {
        this.page = 1;
        this.productList.clear();
        this.filter.clearFilters();
        this.productsAdapter.setHasMore(true);
        this.productsAdapter.setModeAndNotify(3);
        requestItems();
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter.LoadMoreListener
    public void onMoreRequested() {
        this.page++;
        requestItems();
    }

    private void requestItems() {
        WooCommerceTask.WooCommerceBuilder wooCommerceBuilder = new WooCommerceTask.WooCommerceBuilder(this.mAct);
        if (this.searchQuery != null) {
            wooCommerceBuilder.getProductsForQuery(this, this.searchQuery, this.page, this.filter).execute(new Void[0]);
        } else if (this.category != 0) {
            wooCommerceBuilder.getProductsForCategory(this, this.category, this.page, this.filter).execute(new Void[0]);
        } else {
            wooCommerceBuilder.getProducts(this, this.page, this.filter).execute(new Void[0]);
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.woocommerce_menu, menu);
        this.searchView = new SearchView(getActivity());
        this.searchView.setQueryHint(getResources().getString(R.string.search_hint));
        this.searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment.AnonymousClass2 */

            @Override // android.support.v7.widget.SearchView.OnQueryTextListener
            public boolean onQueryTextChange(String str) {
                return false;
            }

            @Override // android.support.v7.widget.SearchView.OnQueryTextListener
            public boolean onQueryTextSubmit(String str) {
                try {
                    str = URLEncoder.encode(str, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    Log.printStackTrace(e);
                }
                WooCommerceFragment.this.searchView.clearFocus();
                WooCommerceFragment.this.searchQuery = str;
                WooCommerceFragment.this.refreshItems();
                WooCommerceFragment.this.updateHeaders();
                return true;
            }
        });
        this.searchView.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment.AnonymousClass3 */

            public void onViewAttachedToWindow(View view) {
            }

            public void onViewDetachedFromWindow(View view) {
                WooCommerceFragment.this.searchQuery = null;
                WooCommerceFragment.this.updateHeaders();
                WooCommerceFragment.this.refreshItems();
            }
        });
        this.searchMenu = menu.findItem(R.id.menu_search);
        this.searchMenu.setActionView(this.searchView);
        if ((this.searchQuery == null) && this.isHomePage) {
            this.searchMenu.setVisible(false);
        }
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.menu_cart) {
            HolderActivity.startActivity(getActivity(), CartFragment.class, null);
        }
        return super.onOptionsItemSelected(menuItem);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void showFilterDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this.mAct);
        View inflate = this.mAct.getLayoutInflater().inflate(R.layout.fragment_wc_filter_dialog, (ViewGroup) null);
        final EditText editText = (EditText) inflate.findViewById(R.id.min_price);
        final EditText editText2 = (EditText) inflate.findViewById(R.id.max_price);
        final CheckBox checkBox = (CheckBox) inflate.findViewById(R.id.checkbox_sale);
        final CheckBox checkBox2 = (CheckBox) inflate.findViewById(R.id.checkbox_featured);
        ((TextView) inflate.findViewById(R.id.currency_max_price)).setText(String.format(RestAPI.getCurrencyFormat(), ""));
        ((TextView) inflate.findViewById(R.id.currency_min_price)).setText(String.format(RestAPI.getCurrencyFormat(), ""));
        if (this.filter.getMinPrice() != 0.0d) {
            editText.setText(Double.toString(this.filter.getMinPrice()));
        }
        if (this.filter.getMaxPrice() != 0.0d) {
            editText2.setText(Double.toString(this.filter.getMaxPrice()));
        }
        if (this.filter.isOnlySale()) {
            checkBox.setChecked(true);
        }
        if (this.filter.isOnlyFeatured()) {
            checkBox2.setChecked(true);
        }
        builder.setView(inflate);
        builder.setTitle(getResources().getString(R.string.filter));
        builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment.AnonymousClass4 */

            public void onClick(DialogInterface dialogInterface, int i) {
                double d;
                double d2 = 0.0d;
                if (editText.getText().toString().isEmpty()) {
                    d = 0.0d;
                } else {
                    d = Double.parseDouble(editText.getText().toString());
                }
                if (!editText2.getText().toString().isEmpty()) {
                    d2 = Double.parseDouble(editText2.getText().toString());
                }
                WooCommerceFragment.this.filter.maxPrice(d2).minPrice(d).onlyFeatured(checkBox2.isChecked()).onlySale(checkBox.isChecked());
                WooCommerceFragment.this.refreshItems();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment.AnonymousClass5 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.create().show();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private int randomGradientResource(int i) {
        int i2 = i + 1;
        if (i2 == 6) {
            i2 = 1;
        }
        return Helper.getGradient(i2);
    }

    public void updateHeaders() {
        int i;
        this.productsAdapter.clearHeaders();
        int i2 = 0;
        if (this.searchQuery != null) {
            loadFilterHeader(0);
        } else if (this.isHomePage) {
            loadSearchHeader(0);
            if (this.headerImages.size() > 0) {
                loadHeaderImage(1, this.headerImages.get(0), RestAPI.home_banner_one);
                i = 2;
            } else {
                i = 1;
            }
            loadCategorySlider(i);
            if (this.headerImages.size() > 1) {
                loadTextHeader(i, getString(R.string.sale));
                int i3 = i + 1;
                loadHeaderImage(i3, this.headerImages.get(1), RestAPI.home_banner_two);
                i = i3 + 1;
            }
            loadTextHeader(i, getString(R.string.latest_products));
        } else {
            if (this.headerImages.size() > 0) {
                loadHeaderImage(0, this.headerImages.get(0), null);
            }
            if (this.headerImages.size() > 0) {
                i2 = 1;
            }
            loadFilterHeader(i2);
        }
    }

    private void loadCategorySlider(final int i) {
        new WooCommerceTask.WooCommerceBuilder(this.mAct).getCategories(new WooCommerceTask.Callback<Category>() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment.AnonymousClass6 */

            @Override // com.thedaw.uiuians.providers.woocommerce.WooCommerceTask.Callback
            public void failed() {
            }

            @Override // com.thedaw.uiuians.providers.woocommerce.WooCommerceTask.Callback
            public void success(ArrayList<Category> arrayList) {
                ViewGroup viewGroup;
                LayoutInflater from = LayoutInflater.from(WooCommerceFragment.this.mAct);
                ViewGroup viewGroup2 = (ViewGroup) from.inflate(R.layout.fragment_wc_header_slider, (ViewGroup) null);
                Iterator<Category> it = arrayList.iterator();
                while (it.hasNext()) {
                    final Category next = it.next();
                    if (next.getImage() == null || !(next.getImage() instanceof JsonObject)) {
                        viewGroup = (ViewGroup) from.inflate(R.layout.fragment_wc_category_card_text, (ViewGroup) null);
                        viewGroup.findViewById(R.id.background).setBackgroundResource(WooCommerceFragment.this.randomGradientResource(arrayList.indexOf(next)));
                    } else {
                        viewGroup = (ViewGroup) from.inflate(R.layout.fragment_wc_category_card_image, (ViewGroup) null);
                        Picasso.get().load(((Image) new Gson().fromJson(next.getImage(), Image.class)).getSrc()).into((ImageView) viewGroup.findViewById(R.id.image));
                    }
                    ((TextView) viewGroup.findViewById(R.id.title)).setText(next.getName());
                    viewGroup.setOnClickListener(new View.OnClickListener() {
                        /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment.AnonymousClass6.AnonymousClass1 */

                        public void onClick(View view) {
                            HolderActivity.startActivity(WooCommerceFragment.this.mAct, WooCommerceFragment.class, new String[]{Integer.toString(next.getId().intValue())});
                        }
                    });
                    ((LinearLayout) viewGroup2.findViewById(R.id.slider_content)).addView(viewGroup);
                }
                WooCommerceFragment.this.productsAdapter.addHeaderToIndex(viewGroup2, i);
                viewGroup2.setAlpha(0.0f);
                viewGroup2.animate().alpha(1.0f).setDuration(500).start();
            }
        }).execute(new Void[0]);
    }

    private void loadSearchHeader(int i) {
        ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(this.mAct).inflate(R.layout.fragment_wc_header_search, (ViewGroup) null);
        final EditText editText = (EditText) viewGroup.findViewById(R.id.search_bar);
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment.AnonymousClass7 */

            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i != 6) {
                    return false;
                }
                WooCommerceFragment.this.searchMenu.setVisible(true);
                WooCommerceFragment.this.searchView.onActionViewExpanded();
                WooCommerceFragment.this.searchMenu.expandActionView();
                WooCommerceFragment.this.searchView.setQuery(editText.getText(), true);
                return true;
            }
        });
        this.productsAdapter.addHeaderToIndex(viewGroup, i);
    }

    private void loadHeaderImage(int i, String str, final String str2) {
        if (str != null) {
            ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(this.mAct).inflate(R.layout.fragment_wc_header_image, (ViewGroup) null);
            Picasso.get().load(str).into((ImageView) viewGroup.findViewById(R.id.header_image));
            viewGroup.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment.AnonymousClass8 */

                public void onClick(View view) {
                    if (!StringUtil.isBlank(str2)) {
                        HolderActivity.startActivity(WooCommerceFragment.this.mAct, WooCommerceFragment.class, new String[]{str2});
                    }
                }
            });
            this.productsAdapter.addHeaderToIndex(viewGroup, i);
        }
    }

    private void loadTextHeader(int i, String str) {
        ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(this.mAct).inflate(R.layout.fragment_wc_header_text, (ViewGroup) null);
        ((TextView) viewGroup.findViewById(R.id.text)).setText(str);
        this.productsAdapter.addHeaderToIndex(viewGroup, i);
    }

    private void loadFilterHeader(int i) {
        ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(this.mAct).inflate(R.layout.fragment_wc_filter_header, (ViewGroup) null);
        final ImageButton imageButton = (ImageButton) viewGroup.findViewById(R.id.normal);
        final ImageButton imageButton2 = (ImageButton) viewGroup.findViewById(R.id.compact);
        updateViewModeButtons(imageButton, imageButton2);
        ((Button) viewGroup.findViewById(R.id.filter)).setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment.AnonymousClass9 */

            public void onClick(View view) {
                WooCommerceFragment.this.showFilterDialog();
            }
        });
        AnonymousClass10 r3 = new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment.AnonymousClass10 */

            public void onClick(View view) {
                WooCommerceFragment.this.viewModeUtils.saveToPreferences(!view.equals(imageButton2));
                WooCommerceFragment.this.setViewMode();
                WooCommerceFragment.this.updateViewModeButtons(imageButton, imageButton2);
            }
        };
        imageButton.setOnClickListener(r3);
        imageButton2.setOnClickListener(r3);
        this.productsAdapter.addHeaderToIndex(viewGroup, i);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void setViewMode() {
        if (this.viewModeUtils == null) {
            this.viewModeUtils = new ViewModeUtils(getContext(), getClass());
        }
        this.recyclerView.setLayoutManager(new StaggeredGridLayoutManager((this.viewModeUtils.getViewMode() == 0 || (this.isHomePage && this.searchQuery == null)) ? 2 : 1, 1));
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void updateViewModeButtons(View view, View view2) {
        if (this.viewModeUtils.getViewMode() == 1) {
            view.setAlpha(1.0f);
            view2.setAlpha(0.5f);
            return;
        }
        view.setAlpha(0.5f);
        view2.setAlpha(1.0f);
    }
}

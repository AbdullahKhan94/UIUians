package com.thedaw.uiuians.providers.woocommerce.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.woocommerce.WooCommerceTask;
import com.thedaw.uiuians.providers.woocommerce.adapter.OrdersAdapter;
import com.thedaw.uiuians.providers.woocommerce.model.CredentialStorage;
import com.thedaw.uiuians.providers.woocommerce.model.orders.Order;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import com.thedaw.uiuians.util.ThemeUtils;
import java.util.ArrayList;
import java.util.List;

public class OrdersFragment extends Fragment implements WooCommerceTask.Callback<Order>, InfiniteRecyclerViewAdapter.LoadMoreListener {
    private boolean awaitingLogin = false;
    private Activity mAct;
    private OrdersAdapter ordersAdapter;
    private List<Order> ordersList;
    private int page = 1;
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_list_refresh, viewGroup, false);
    }

    @Override // android.support.v4.app.Fragment
    public void onViewCreated(View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        setHasOptionsMenu(true);
        this.recyclerView = (RecyclerView) view.findViewById(R.id.list);
        this.swipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipeRefreshLayout);
        this.ordersList = new ArrayList();
        this.ordersAdapter = new OrdersAdapter(getContext(), this.ordersList, this);
        this.ordersAdapter.setModeAndNotify(3);
        this.recyclerView.setAdapter(this.ordersAdapter);
        this.mAct = getActivity();
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this.mAct));
        this.recyclerView.setItemAnimator(new DefaultItemAnimator());
        if (CredentialStorage.credentialsAvailable(this.mAct)) {
            refreshItems();
            loadHeader();
        } else {
            this.ordersAdapter.setEmptyViewText(getString(R.string.no_user), getString(R.string.no_user_subtitle));
            this.ordersAdapter.setEmptyViewButton(getResources().getString(R.string.common_signin_button_text), new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.woocommerce.ui.OrdersFragment.AnonymousClass1 */

                public void onClick(View view) {
                    OrdersFragment.this.startActivity(new Intent(OrdersFragment.this.mAct, WooCommerceLoginActivity.class));
                    OrdersFragment.this.awaitingLogin = true;
                }
            });
            this.ordersAdapter.setModeAndNotify(2);
        }
        this.swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.OrdersFragment.AnonymousClass2 */

            @Override // android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener
            public void onRefresh() {
                if (CredentialStorage.credentialsAvailable(OrdersFragment.this.mAct)) {
                    OrdersFragment.this.refreshItems();
                } else {
                    OrdersFragment.this.swipeRefreshLayout.setRefreshing(false);
                }
            }
        });
    }

    private void loadHeader() {
        ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(this.mAct).inflate(R.layout.fragment_wc_order_header, (ViewGroup) null);
        View findViewById = viewGroup.findViewById(R.id.user_sign_out_button);
        ((TextView) viewGroup.findViewById(R.id.order_header_text)).setText(String.format(getString(R.string.greeting), CredentialStorage.getName(this.mAct)));
        findViewById.setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.OrdersFragment.AnonymousClass3 */

            public void onClick(View view) {
                CredentialStorage.clearCredentials(OrdersFragment.this.mAct);
                Toast.makeText(OrdersFragment.this.mAct, (int) R.string.action_sign_out_success, 0).show();
                OrdersFragment.this.getFragmentManager().beginTransaction().detach(OrdersFragment.this).attach(OrdersFragment.this).commit();
            }
        });
        this.ordersAdapter.setHeader(viewGroup);
    }

    @Override // android.support.v4.app.Fragment
    public void onResume() {
        super.onResume();
        if (this.awaitingLogin) {
            this.awaitingLogin = false;
            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
        }
    }

    @Override // com.thedaw.uiuians.providers.woocommerce.WooCommerceTask.Callback
    public void success(ArrayList<Order> arrayList) {
        if (arrayList.size() > 0) {
            this.ordersList.addAll(arrayList);
            this.ordersAdapter.setModeAndNotify(1);
        } else if (arrayList.size() == 0 && this.ordersList.size() == 0) {
            this.ordersAdapter.setEmptyViewText(String.format(getString(R.string.greeting), CredentialStorage.getName(this.mAct)), getString(R.string.no_order));
            this.ordersAdapter.setEmptyViewButton(getString(R.string.shop), new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.woocommerce.ui.OrdersFragment.AnonymousClass4 */

                public void onClick(View view) {
                    HolderActivity.startActivity(OrdersFragment.this.mAct, WooCommerceFragment.class, new String[0]);
                }
            });
            this.ordersAdapter.setModeAndNotify(2);
        } else {
            this.ordersAdapter.setHasMore(false);
            this.ordersAdapter.setModeAndNotify(1);
        }
        this.swipeRefreshLayout.setRefreshing(false);
    }

    @Override // com.thedaw.uiuians.providers.woocommerce.WooCommerceTask.Callback
    public void failed() {
        this.ordersAdapter.setModeAndNotify(2);
        this.swipeRefreshLayout.setRefreshing(false);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void refreshItems() {
        this.page = 1;
        this.ordersList.clear();
        this.ordersAdapter.setHasMore(true);
        this.ordersAdapter.setModeAndNotify(3);
        requestItems();
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter.LoadMoreListener
    public void onMoreRequested() {
        this.page++;
        requestItems();
    }

    private void requestItems() {
        new WooCommerceTask.WooCommerceBuilder(this.mAct).getOrders(this, CredentialStorage.getId(this.mAct).intValue(), this.page).execute(new Void[0]);
    }

    @Override // android.support.v4.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.woocommerce_menu, menu);
        menu.findItem(R.id.menu_search).setVisible(false);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.menu_cart) {
            HolderActivity.startActivity(getActivity(), CartFragment.class, null);
        }
        return super.onOptionsItemSelected(menuItem);
    }
}

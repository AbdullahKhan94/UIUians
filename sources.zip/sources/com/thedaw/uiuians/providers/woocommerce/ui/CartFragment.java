package com.thedaw.uiuians.providers.woocommerce.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.woocommerce.adapter.CartAdapter;
import com.thedaw.uiuians.providers.woocommerce.checkout.Cart;
import com.thedaw.uiuians.providers.woocommerce.checkout.CartAssistant;
import com.thedaw.uiuians.providers.woocommerce.checkout.CartProduct;
import com.thedaw.uiuians.providers.woocommerce.checkout.CartWithCookies;
import com.thedaw.uiuians.providers.woocommerce.checkout.PriceFormat;
import java.util.Iterator;
import java.util.List;
import okhttp3.Cookie;

public class CartFragment extends Fragment implements Cart.CartListener {
    private Button btnFinish;
    private Cart cart;
    private View loadingView;
    private Activity mAct;
    private CartAdapter productsAdapter;
    private RecyclerView recyclerView;
    private TextView textViewCheckOutPrice;
    private float total;
    private View view;

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_wc_cart, viewGroup, false);
    }

    @Override // android.support.v4.app.Fragment
    public void onViewCreated(View view2, @Nullable Bundle bundle) {
        super.onViewCreated(view2, bundle);
        this.view = view2;
        this.mAct = getActivity();
        if (this.mAct instanceof HolderActivity) {
            ((HolderActivity) this.mAct).getSupportActionBar().setTitle(R.string.cart_title);
        }
        this.recyclerView = (RecyclerView) view2.findViewById(R.id.recycleViewCheckOut);
        this.textViewCheckOutPrice = (TextView) view2.findViewById(R.id.textViewCheckOutPrice);
        this.btnFinish = (Button) view2.findViewById(R.id.btnFinish);
        this.loadingView = view2.findViewById(R.id.loading_view);
        this.cart = Cart.getInstance(this.mAct);
        this.cart.setCartListener(this);
        this.productsAdapter = new CartAdapter(this.mAct, this.cart);
        this.recyclerView.addItemDecoration(new DividerItemDecoration(this.recyclerView.getContext(), 1));
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this.mAct, 1, false));
        this.recyclerView.setItemAnimator(new DefaultItemAnimator());
        this.recyclerView.setAdapter(this.productsAdapter);
        updateQuantity();
        this.btnFinish.setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.ui.CartFragment.AnonymousClass1 */

            public void onClick(View view) {
                if (CartFragment.this.cart.getCartProducts().size() != 0) {
                    CartFragment.this.loadingView.setVisibility(0);
                    new CartWithCookies(CartFragment.this.mAct, new CartWithCookies.AllProductsAddedCallback() {
                        /* class com.thedaw.uiuians.providers.woocommerce.ui.CartFragment.AnonymousClass1.AnonymousClass1 */

                        @Override // com.thedaw.uiuians.providers.woocommerce.checkout.CartWithCookies.AllProductsAddedCallback
                        public void success(final List<Cookie> list) {
                            CartFragment.this.mAct.runOnUiThread(new Runnable() {
                                /* class com.thedaw.uiuians.providers.woocommerce.ui.CartFragment.AnonymousClass1.AnonymousClass1.AnonymousClass1 */

                                public void run() {
                                    CartFragment.this.cart.clearCart();
                                    CartFragment.this.productsAdapter.notifyDataSetChanged();
                                    CartFragment.this.updateQuantity();
                                    CheckoutActivity.startActivity(CartFragment.this.mAct, list);
                                    CartFragment.this.mAct.finish();
                                }
                            });
                        }

                        @Override // com.thedaw.uiuians.providers.woocommerce.checkout.CartWithCookies.AllProductsAddedCallback
                        public void failure() {
                            CartFragment.this.mAct.runOnUiThread(new Runnable() {
                                /* class com.thedaw.uiuians.providers.woocommerce.ui.CartFragment.AnonymousClass1.AnonymousClass1.AnonymousClass2 */

                                public void run() {
                                    CartFragment.this.loadingView.setVisibility(8);
                                    Toast.makeText(CartFragment.this.mAct, (int) R.string.cart_failed, 1).show();
                                }
                            });
                        }
                    }).addProductsToCart(CartFragment.this.cart.getCartProducts());
                }
            }
        });
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void updateQuantity() {
        if (this.cart.getCartProducts().size() == 0) {
            this.view.findViewById(R.id.empty_view).setVisibility(0);
        } else {
            this.view.findViewById(R.id.empty_view).setVisibility(8);
        }
        this.total = 0.0f;
        Iterator<CartProduct> it = this.cart.getCartProducts().iterator();
        while (it.hasNext()) {
            CartProduct next = it.next();
            this.total += CartAssistant.getPrice(next.getProduct(), next.getVariation()) * ((float) next.getQuantity());
        }
        this.textViewCheckOutPrice.setText(PriceFormat.formatPrice(Float.valueOf(this.total)));
    }

    @Override // com.thedaw.uiuians.providers.woocommerce.checkout.Cart.CartListener
    public void onCartUpdated() {
        updateQuantity();
    }
}

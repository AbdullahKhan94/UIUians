package com.thedaw.uiuians.providers.woocommerce.model.products;

import com.google.android.exoplayer2.text.ttml.TtmlNode;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class Attribute implements Serializable {
    @SerializedName(TtmlNode.ATTR_ID)
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("option")
    @Expose
    private String option;
    @SerializedName("options")
    @Expose
    private List<String> options;

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer num) {
        this.id = num;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getOption() {
        return this.option;
    }

    public void setOption(String str) {
        this.option = str;
    }

    public List<String> getOptions() {
        return this.options;
    }

    public void setOptions(List<String> list) {
        this.options = list;
    }
}

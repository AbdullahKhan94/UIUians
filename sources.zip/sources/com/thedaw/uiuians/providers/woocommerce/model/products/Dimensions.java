package com.thedaw.uiuians.providers.woocommerce.model.products;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import io.fabric.sdk.android.services.settings.SettingsJsonConstants;
import java.io.Serializable;

public class Dimensions implements Serializable {
    @SerializedName(SettingsJsonConstants.ICON_HEIGHT_KEY)
    @Expose
    private String height;
    @SerializedName("length")
    @Expose
    private String length;
    @SerializedName(SettingsJsonConstants.ICON_WIDTH_KEY)
    @Expose
    private String width;

    public String getLength() {
        return this.length;
    }

    public void setLength(String str) {
        this.length = str;
    }

    public String getWidth() {
        return this.width;
    }

    public void setWidth(String str) {
        this.width = str;
    }

    public String getHeight() {
        return this.height;
    }

    public void setHeight(String str) {
        this.height = str;
    }
}

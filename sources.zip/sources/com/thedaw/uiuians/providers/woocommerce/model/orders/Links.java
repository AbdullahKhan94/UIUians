package com.thedaw.uiuians.providers.woocommerce.model.orders;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.List;

public class Links {
    @SerializedName("collection")
    @Expose
    private List<Collection> collection = new ArrayList();
    @SerializedName("self")
    @Expose
    private List<Self> self = new ArrayList();

    public List<Self> getSelf() {
        return this.self;
    }

    public void setSelf(List<Self> list) {
        this.self = list;
    }

    public List<Collection> getCollection() {
        return this.collection;
    }

    public void setCollection(List<Collection> list) {
        this.collection = list;
    }
}

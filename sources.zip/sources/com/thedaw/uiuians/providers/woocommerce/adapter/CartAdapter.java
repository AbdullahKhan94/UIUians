package com.thedaw.uiuians.providers.woocommerce.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.woocommerce.checkout.Cart;
import com.thedaw.uiuians.providers.woocommerce.checkout.CartAssistant;
import com.thedaw.uiuians.providers.woocommerce.checkout.CartProduct;
import com.thedaw.uiuians.providers.woocommerce.checkout.PriceFormat;
import com.thedaw.uiuians.providers.woocommerce.model.products.Product;
import com.thedaw.uiuians.providers.woocommerce.ui.ProductActivity;

public class CartAdapter extends RecyclerView.Adapter<MyViewHolder> {
    public static int MAX_QUANTITY = 15;
    private Cart cart;
    private Context mContext;

    /* access modifiers changed from: package-private */
    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView overflowDelete;
        TextView overflowEdit;
        TextView productDetails;
        ImageView productImage;
        TextView productName;
        TextView productPrice;
        TextView productPriceRegular;
        TextView productQuantity;

        MyViewHolder(View view) {
            super(view);
            this.productName = (TextView) view.findViewById(R.id.productName);
            this.productPrice = (TextView) view.findViewById(R.id.productPrice);
            this.productPriceRegular = (TextView) view.findViewById(R.id.productPriceRegular);
            this.productQuantity = (TextView) view.findViewById(R.id.productQuantity);
            this.productDetails = (TextView) view.findViewById(R.id.productDetails);
            this.productImage = (ImageView) view.findViewById(R.id.productImage);
            this.overflowDelete = (TextView) view.findViewById(R.id.overflowDelete);
            this.overflowEdit = (TextView) view.findViewById(R.id.overflowEdit);
        }
    }

    public CartAdapter(Context context, Cart cart2) {
        this.mContext = context;
        this.cart = cart2;
    }

    @Override // android.support.v7.widget.RecyclerView.Adapter
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_wc_cart_item, viewGroup, false));
    }

    public void onBindViewHolder(final MyViewHolder myViewHolder, int i) {
        String str;
        final CartProduct cartProduct = this.cart.getCartProducts().get(i);
        final Product product = cartProduct.getProduct();
        String name = product.getName();
        String src = product.getImages().get(0).getSrc();
        float price = CartAssistant.getPrice(product, cartProduct.getVariation());
        if (product.getCategories().size() > 0) {
            str = product.getCategories().get(0).getName();
        } else {
            str = product.getDescription().replaceAll("<[^>]*>", "").trim();
        }
        if (cartProduct.getVariation() != null) {
            str = CartAssistant.getVariationDescription(cartProduct.getVariation());
        }
        myViewHolder.productName.setText(name);
        myViewHolder.productPrice.setText(PriceFormat.formatPrice(Float.valueOf(price)));
        myViewHolder.productDetails.setText(str);
        myViewHolder.productQuantity.setText(String.format(this.mContext.getString(R.string.quantity), Integer.valueOf(cartProduct.getQuantity())).trim());
        myViewHolder.overflowDelete.setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.adapter.CartAdapter.AnonymousClass1 */

            public void onClick(View view) {
                if (CartAdapter.this.cart.removeProductFromCart(product, cartProduct.getVariation())) {
                    CartAdapter.this.notifyItemRemoved(myViewHolder.getAdapterPosition());
                } else {
                    CartAdapter.this.notifyDataSetChanged();
                }
            }
        });
        myViewHolder.overflowEdit.setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.adapter.CartAdapter.AnonymousClass2 */

            public void onClick(View view) {
                CartAdapter.this.showQuantityEditor(myViewHolder.getAdapterPosition());
            }
        });
        Picasso.get().load(src).into(myViewHolder.productImage);
        myViewHolder.productImage.setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.adapter.CartAdapter.AnonymousClass3 */

            public void onClick(View view) {
                Intent intent = new Intent(CartAdapter.this.mContext, ProductActivity.class);
                intent.putExtra(ProductActivity.PRODUCT, product);
                CartAdapter.this.mContext.startActivity(intent);
            }
        });
        if (product.getOnSale().booleanValue()) {
            myViewHolder.productPriceRegular.setVisibility(0);
            myViewHolder.productPriceRegular.setText(PriceFormat.formatPrice(Float.valueOf(product.getRegularPrice())));
            myViewHolder.productPriceRegular.setPaintFlags(myViewHolder.productPriceRegular.getPaintFlags() | 16);
            myViewHolder.productPrice.setText(PriceFormat.formatPrice(Float.valueOf(product.getSalePrice())));
            return;
        }
        myViewHolder.productPrice.setText(PriceFormat.formatPrice(Float.valueOf(price)));
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void showQuantityEditor(int i) {
        final CartProduct cartProduct = this.cart.getCartProducts().get(i);
        RelativeLayout relativeLayout = new RelativeLayout(this.mContext);
        final NumberPicker numberPicker = new NumberPicker(this.mContext);
        numberPicker.setMaxValue(cartProduct.getProduct().getManageStock().booleanValue() ? cartProduct.getProduct().getStockQuantity().intValue() : MAX_QUANTITY);
        numberPicker.setMinValue(1);
        numberPicker.setValue(cartProduct.getQuantity());
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(50, 50);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(14);
        relativeLayout.setLayoutParams(layoutParams);
        relativeLayout.addView(numberPicker, layoutParams2);
        AlertDialog.Builder builder = new AlertDialog.Builder(this.mContext);
        builder.setTitle(R.string.quantity_picker);
        builder.setView(relativeLayout);
        builder.setCancelable(false).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.adapter.CartAdapter.AnonymousClass5 */

            public void onClick(DialogInterface dialogInterface, int i) {
                CartAdapter.this.cart.setProductQuantity(cartProduct, numberPicker.getValue());
                CartAdapter.this.notifyDataSetChanged();
            }
        }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.adapter.CartAdapter.AnonymousClass4 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.create().show();
    }

    @Override // android.support.v7.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.cart.getCartProducts().size();
    }
}

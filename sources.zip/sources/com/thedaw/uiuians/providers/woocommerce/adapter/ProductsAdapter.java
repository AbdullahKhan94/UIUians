package com.thedaw.uiuians.providers.woocommerce.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.woocommerce.checkout.CartAssistant;
import com.thedaw.uiuians.providers.woocommerce.checkout.PriceFormat;
import com.thedaw.uiuians.providers.woocommerce.model.ViewItem;
import com.thedaw.uiuians.providers.woocommerce.model.products.Product;
import com.thedaw.uiuians.providers.woocommerce.ui.ProductActivity;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import java.util.ArrayList;
import java.util.List;

public class ProductsAdapter extends InfiniteRecyclerViewAdapter {
    private static final int TYPE_CUSTOM = 1;
    private static final int TYPE_PRODUCT = 0;
    private List<ViewItem> headersList = new ArrayList();
    private float itemWidth;
    private Context mContext;
    private List<Product> productList;

    private class ProductViewHolder extends RecyclerView.ViewHolder {
        ImageView overflow;
        ImageView productImage;
        TextView productName;
        TextView productPrice;
        TextView productPriceRegular;
        TextView saleLabel;
        View view;

        ProductViewHolder(View view2) {
            super(view2);
            this.view = view2;
            this.productName = (TextView) view2.findViewById(R.id.productName);
            this.productPrice = (TextView) view2.findViewById(R.id.productPrice);
            this.productPriceRegular = (TextView) view2.findViewById(R.id.productPriceRegular);
            this.productImage = (ImageView) view2.findViewById(R.id.productImage);
            this.overflow = (ImageView) view2.findViewById(R.id.overflow);
            this.saleLabel = (TextView) view2.findViewById(R.id.sale_label);
        }
    }

    private class HeaderViewHolder extends RecyclerView.ViewHolder {
        LinearLayout layout;

        HeaderViewHolder(View view) {
            super(view);
            this.layout = (LinearLayout) view;
        }
    }

    public ProductsAdapter(Context context, List<Product> list, InfiniteRecyclerViewAdapter.LoadMoreListener loadMoreListener) {
        super(context, loadMoreListener);
        this.mContext = context;
        this.productList = list;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getViewType(int i) {
        return i < this.headersList.size() ? 1 : 0;
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public RecyclerView.ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        if (i == 0) {
            return new ProductViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_wc_product_card, viewGroup, false));
        }
        HeaderViewHolder headerViewHolder = new HeaderViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_wc_header, viewGroup, false));
        requestFullSpan(headerViewHolder);
        return headerViewHolder;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public void doBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ProductViewHolder) {
            ProductViewHolder productViewHolder = (ProductViewHolder) viewHolder;
            final Product product = this.productList.get(i - this.headersList.size());
            String name = product.getName();
            String src = product.getImages().get(0).getSrc();
            productViewHolder.productName.setText(name);
            if (product.getOnSale().booleanValue()) {
                productViewHolder.productPriceRegular.setVisibility(0);
                productViewHolder.saleLabel.setVisibility(0);
                productViewHolder.productPriceRegular.setText(PriceFormat.formatPrice(Float.valueOf(product.getRegularPrice())));
                productViewHolder.productPriceRegular.setPaintFlags(productViewHolder.productPriceRegular.getPaintFlags() | 16);
                productViewHolder.productPrice.setText(PriceFormat.formatPrice(Float.valueOf(product.getSalePrice())));
            } else {
                productViewHolder.productPriceRegular.setVisibility(8);
                productViewHolder.saleLabel.setVisibility(8);
                productViewHolder.productPrice.setText(PriceFormat.formatPrice(Float.valueOf(product.getPrice())));
            }
            productViewHolder.overflow.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.woocommerce.adapter.ProductsAdapter.AnonymousClass1 */

                public void onClick(View view) {
                    new CartAssistant(ProductsAdapter.this.mContext, view, product).addProductToCart(null);
                }
            });
            Picasso.get().load(src).into(productViewHolder.productImage);
            productViewHolder.productImage.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.woocommerce.adapter.ProductsAdapter.AnonymousClass2 */

                public void onClick(View view) {
                    Intent intent = new Intent(ProductsAdapter.this.mContext, ProductActivity.class);
                    intent.putExtra(ProductActivity.PRODUCT, product);
                    ProductsAdapter.this.mContext.startActivity(intent);
                }
            });
            if (this.itemWidth > 0.0f) {
                productViewHolder.view.getLayoutParams().width = (int) this.itemWidth;
            }
        } else if (viewHolder instanceof HeaderViewHolder) {
            HeaderViewHolder headerViewHolder = (HeaderViewHolder) viewHolder;
            headerViewHolder.layout.removeAllViews();
            if (this.headersList.get(i).view.getParent() != null) {
                ((ViewGroup) this.headersList.get(i).view.getParent()).removeView(this.headersList.get(i).view);
            }
            headerViewHolder.layout.addView(this.headersList.get(i).view);
            requestFullSpan(viewHolder);
        }
    }

    public void setItemWidth(float f) {
        this.itemWidth = f;
    }

    @Override // android.support.v7.widget.RecyclerView.Adapter
    public void onViewAttachedToWindow(RecyclerView.ViewHolder viewHolder) {
        super.onViewAttachedToWindow(viewHolder);
        if (viewHolder instanceof HeaderViewHolder) {
            requestFullSpan(viewHolder);
        }
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getCount() {
        return this.headersList.size() + this.productList.size();
    }

    public void addHeaderToIndex(View view, int i) {
        this.headersList.add(i, new ViewItem(view));
        notifyDataSetChanged();
    }

    public void clearHeaders() {
        if (this.headersList.size() > 0) {
            this.headersList.clear();
            notifyDataSetChanged();
        }
    }
}

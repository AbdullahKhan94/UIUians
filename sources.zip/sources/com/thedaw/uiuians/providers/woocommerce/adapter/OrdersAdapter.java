package com.thedaw.uiuians.providers.woocommerce.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.woocommerce.checkout.PriceFormat;
import com.thedaw.uiuians.providers.woocommerce.model.orders.Order;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import java.util.List;

public class OrdersAdapter extends InfiniteRecyclerViewAdapter {
    private static final int TYPE_HEADER = 1;
    private static final int TYPE_NORMAL = 0;
    private View headerView;
    private float itemWidth;
    private Context mContext;
    private List<Order> ordersList;

    private class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView orderDate;
        TextView orderDescription;
        TextView orderStatus;
        TextView orderTotal;
        View view;

        OrderViewHolder(View view2) {
            super(view2);
            this.view = view2;
            this.orderDescription = (TextView) view2.findViewById(R.id.orderDescription);
            this.orderDate = (TextView) view2.findViewById(R.id.orderDate);
            this.orderTotal = (TextView) view2.findViewById(R.id.orderTotal);
            this.orderStatus = (TextView) view2.findViewById(R.id.orderStatus);
        }
    }

    private class HeaderViewHolder extends RecyclerView.ViewHolder {
        HeaderViewHolder(View view) {
            super(view);
        }
    }

    public OrdersAdapter(Context context, List<Order> list, InfiniteRecyclerViewAdapter.LoadMoreListener loadMoreListener) {
        super(context, loadMoreListener);
        this.mContext = context;
        this.ordersList = list;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getViewType(int i) {
        return (this.headerView == null || i != 0) ? 0 : 1;
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public RecyclerView.ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        if (i == 0) {
            return new OrderViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_wc_order, viewGroup, false));
        }
        if (i != 1) {
            return null;
        }
        HeaderViewHolder headerViewHolder = new HeaderViewHolder(this.headerView);
        requestFullSpan(headerViewHolder);
        return headerViewHolder;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public void doBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        String str;
        if (viewHolder instanceof OrderViewHolder) {
            OrderViewHolder orderViewHolder = (OrderViewHolder) viewHolder;
            Order order = this.ordersList.get(i - (this.headerView == null ? 0 : 1));
            if (order.getLineItems().size() == 1) {
                str = String.format(this.mContext.getString(R.string.order_item), order.getId(), order.getLineItems().get(0).getName());
            } else {
                str = String.format(this.mContext.getString(R.string.order_items), order.getId(), Integer.valueOf(order.getLineItems().size()));
            }
            String formatPrice = PriceFormat.formatPrice(Float.valueOf(order.getTotal()));
            String status = order.getStatus();
            String charSequence = DateUtils.getRelativeDateTimeString(this.mContext, order.getDateCreated().getTime(), 1000, 604800000, 524288).toString();
            orderViewHolder.orderDescription.setText(str);
            orderViewHolder.orderTotal.setText(formatPrice);
            orderViewHolder.orderDate.setText(charSequence);
            orderViewHolder.orderStatus.setText(status);
            if (this.itemWidth > 0.0f) {
                orderViewHolder.view.getLayoutParams().width = (int) this.itemWidth;
            }
        } else if (viewHolder instanceof HeaderViewHolder) {
            requestFullSpan(viewHolder);
        }
    }

    public void setItemWidth(float f) {
        this.itemWidth = f;
    }

    @Override // android.support.v7.widget.RecyclerView.Adapter
    public void onViewAttachedToWindow(RecyclerView.ViewHolder viewHolder) {
        super.onViewAttachedToWindow(viewHolder);
        if (viewHolder instanceof HeaderViewHolder) {
            requestFullSpan(viewHolder);
        }
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getCount() {
        return this.ordersList.size() + (this.headerView == null ? 0 : 1);
    }

    public void setHeader(View view) {
        this.headerView = view;
        notifyDataSetChanged();
    }
}

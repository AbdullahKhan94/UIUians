package com.thedaw.uiuians.providers.woocommerce;

import android.content.Context;
import android.os.AsyncTask;
import android.text.TextUtils;
import com.google.gson.Gson;
import com.thedaw.uiuians.providers.woocommerce.interceptor.OAuthInterceptor;
import com.thedaw.uiuians.providers.woocommerce.model.RestAPI;
import com.thedaw.uiuians.providers.woocommerce.model.orders.Order;
import com.thedaw.uiuians.providers.woocommerce.model.products.Category;
import com.thedaw.uiuians.providers.woocommerce.model.products.Product;
import com.thedaw.uiuians.providers.woocommerce.model.users.User;
import com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceDebugDialog;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.jsoup.helper.StringUtil;

public class WooCommerceTask<T> extends AsyncTask<Void, Void, ArrayList<T>> {
    private static int CATEGORIES = 10;
    private static String PARAM_ORDER_BY = "&orderby=id";
    private static String PARAM_PER_PAGE = "?per_page=20";
    private static String PARAM_PUBLISHED = "&status=publish";
    private static OkHttpClient client;
    private RestAPI api;
    private Callback callback;
    private Class type;
    private String url;

    public interface Callback<T> {
        void failed();

        void success(ArrayList<T> arrayList);
    }

    /* access modifiers changed from: protected */
    @Override // android.os.AsyncTask
    public /* bridge */ /* synthetic */ void onPostExecute(Object obj) {
        onPostExecute((ArrayList) ((ArrayList) obj));
    }

    public static class WooCommerceBuilder {
        private RestAPI restAPI;

        public WooCommerceBuilder(Context context) {
            this.restAPI = new RestAPI(context);
        }

        public WooCommerceTask<Product> getProducts(Callback<Product> callback, int i, WooCommerceProductFilter wooCommerceProductFilter) {
            return new WooCommerceTask<>(Product.class, callback, ((this.restAPI.getHost() + this.restAPI.getPath()) + "products") + WooCommerceTask.PARAM_PER_PAGE + WooCommerceTask.PARAM_PUBLISHED + WooCommerceTask.PARAM_ORDER_BY + "&page=" + i + wooCommerceProductFilter.getQuery(), this.restAPI);
        }

        public WooCommerceTask<Product> getProductsForCategory(Callback<Product> callback, int i, int i2, WooCommerceProductFilter wooCommerceProductFilter) {
            return new WooCommerceTask<>(Product.class, callback, ((this.restAPI.getHost() + this.restAPI.getPath()) + "products") + WooCommerceTask.PARAM_PER_PAGE + WooCommerceTask.PARAM_PUBLISHED + WooCommerceTask.PARAM_ORDER_BY + "&page=" + i2 + "&category=" + i + wooCommerceProductFilter.getQuery(), this.restAPI);
        }

        public WooCommerceTask<Product> getProductsForQuery(Callback<Product> callback, String str, int i, WooCommerceProductFilter wooCommerceProductFilter) {
            return new WooCommerceTask<>(Product.class, callback, ((this.restAPI.getHost() + this.restAPI.getPath()) + "products") + WooCommerceTask.PARAM_PER_PAGE + WooCommerceTask.PARAM_PUBLISHED + "&page=" + i + "&search=" + str + wooCommerceProductFilter.getQuery(), this.restAPI);
        }

        public WooCommerceTask<Category> getCategories(Callback<Category> callback) {
            return new WooCommerceTask<>(Category.class, callback, ((this.restAPI.getHost() + this.restAPI.getPath()) + "products/categories") + "?per_page=" + WooCommerceTask.CATEGORIES + "&orderby=count&order=desc", this.restAPI);
        }

        public WooCommerceTask<Product> getProductsForIds(Callback<Product> callback, List<Integer> list, int i) {
            return new WooCommerceTask<>(Product.class, callback, ((this.restAPI.getHost() + this.restAPI.getPath()) + "products") + "?page=" + i + WooCommerceTask.PARAM_PUBLISHED + "&include=" + TextUtils.join(",", list), this.restAPI);
        }

        public WooCommerceTask<Product> getVariationsForProduct(Callback<Product> callback, int i) {
            return new WooCommerceTask<>(Product.class, callback, ((this.restAPI.getHost() + this.restAPI.getPath()) + "products/" + i + "/variations") + "?per_page=10", this.restAPI);
        }

        public WooCommerceTask<Order> getOrders(Callback<Order> callback, int i, int i2) {
            return new WooCommerceTask<>(Order.class, callback, (this.restAPI.getHost() + this.restAPI.getPath()) + "orders?customer=" + i + "&page=" + i2, this.restAPI);
        }

        public WooCommerceTask<User> getUsers(Callback<User> callback, String str) {
            return new WooCommerceTask<>(User.class, callback, (this.restAPI.getHost() + this.restAPI.getPath()) + "customers?email=" + str, this.restAPI);
        }
    }

    private WooCommerceTask(Class cls, Callback callback2, String str, RestAPI restAPI) {
        this.type = cls;
        this.callback = callback2;
        this.url = str;
        this.api = restAPI;
    }

    /* JADX DEBUG: Multi-variable search result rejected for r6v2, resolved type: java.util.ArrayList<T> */
    /* JADX WARN: Multi-variable type inference failed */
    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x0017  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0021  */
    public ArrayList<T> doInBackground(Void... voidArr) {
        JSONArray jSONArray;
        String str;
        Exception e;
        try {
            str = getResponse(this.url);
            try {
                jSONArray = new JSONArray(str);
            } catch (IOException | JSONException e2) {
                e = e2;
            }
        } catch (IOException | JSONException e3) {
            e = e3;
            str = null;
            e.printStackTrace();
            jSONArray = null;
            if (jSONArray != null) {
            }
        }
        if (jSONArray != null) {
            WooCommerceDebugDialog.showDialogIfAuthFailed(str, this.api.getContext());
            return null;
        }
        ArrayList<T> arrayList = (ArrayList<T>) new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            try {
                if (this.type.equals(Product.class)) {
                    Product product = (Product) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), (Class) Product.class);
                    if (product.getPurchasable().booleanValue() || !StringUtil.isBlank(product.getExternalUrl())) {
                        arrayList.add(product);
                    }
                } else if (this.type.equals(Category.class)) {
                    arrayList.add((Category) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), (Class) Category.class));
                } else if (this.type.equals(Order.class)) {
                    arrayList.add((Order) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), (Class) Order.class));
                } else if (this.type.equals(User.class)) {
                    arrayList.add((User) new Gson().fromJson(jSONArray.getJSONObject(i).toString(), (Class) User.class));
                }
            } catch (JSONException e4) {
                e4.printStackTrace();
            }
        }
        return arrayList;
    }

    private String getResponse(String str) throws IOException, JSONException {
        client = getRestAPIClient(this.api);
        Response execute = client.newCall(new Request.Builder().url(str).build()).execute();
        execute.header("x-wp-totalpages");
        return execute.body().string();
    }

    public static OkHttpClient getRestAPIClient(RestAPI restAPI) {
        if (client == null) {
            client = new OkHttpClient.Builder().addInterceptor(new OAuthInterceptor.Builder().consumerKey(restAPI.getCustomerKey()).consumerSecret(restAPI.getCustomerSecret()).build()).connectTimeout(25, TimeUnit.SECONDS).writeTimeout(25, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();
        }
        return client;
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(ArrayList<T> arrayList) {
        if (arrayList != null) {
            this.callback.success(arrayList);
        } else {
            this.callback.failed();
        }
    }
}

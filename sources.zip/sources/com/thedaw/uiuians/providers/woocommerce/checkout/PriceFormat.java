package com.thedaw.uiuians.providers.woocommerce.checkout;

import com.thedaw.uiuians.providers.woocommerce.model.RestAPI;
import java.text.DecimalFormat;

public class PriceFormat {
    private static String priceWithDecimal(Float f) {
        return new DecimalFormat("###,###,###.00").format(f);
    }

    private static String priceWithoutDecimal(Float f) {
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###.##");
        return decimalFormat.format(f) + ",-";
    }

    public static String formatDecimal(Float f) {
        if (priceWithoutDecimal(f).indexOf(".") > 0) {
            return priceWithDecimal(f);
        }
        return priceWithoutDecimal(f);
    }

    public static String formatPrice(Float f) {
        return String.format(RestAPI.getCurrencyFormat(), formatDecimal(f));
    }
}

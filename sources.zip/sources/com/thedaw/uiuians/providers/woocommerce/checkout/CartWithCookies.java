package com.thedaw.uiuians.providers.woocommerce.checkout;

import android.content.Context;
import com.thedaw.uiuians.providers.woocommerce.model.CredentialStorage;
import com.thedaw.uiuians.providers.woocommerce.model.RestAPI;
import com.thedaw.uiuians.util.Log;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class CartWithCookies {
    private static OkHttpClient client;
    private AllProductsAddedCallback allProductsAddedCallback;
    private Context mContext;
    private final List<Cookie> mCookieStore = new ArrayList();
    private CookieJar mCookies;
    private ProductAddedCallback productAddedCallBack;

    public interface AllProductsAddedCallback {
        void failure();

        void success(List<Cookie> list);
    }

    /* access modifiers changed from: private */
    public interface ProductAddedCallback {
        void failure();

        void success(CartProduct cartProduct);
    }

    public CartWithCookies(Context context, AllProductsAddedCallback allProductsAddedCallback2) {
        this.mContext = context;
        this.allProductsAddedCallback = allProductsAddedCallback2;
        this.mCookies = new CookieJar() {
            /* class com.thedaw.uiuians.providers.woocommerce.checkout.CartWithCookies.AnonymousClass1 */

            @Override // okhttp3.CookieJar
            public void saveFromResponse(HttpUrl httpUrl, List<Cookie> list) {
                for (Cookie cookie : list) {
                    boolean z = false;
                    ListIterator listIterator = CartWithCookies.this.mCookieStore.listIterator();
                    while (listIterator.hasNext()) {
                        if (cookie.name().equals(((Cookie) listIterator.next()).name())) {
                            listIterator.set(cookie);
                            z = true;
                        }
                    }
                    if (!z) {
                        CartWithCookies.this.mCookieStore.add(cookie);
                    }
                }
            }

            @Override // okhttp3.CookieJar
            public List<Cookie> loadForRequest(HttpUrl httpUrl) {
                return CartWithCookies.this.mCookieStore;
            }
        };
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void startProductsToCartLoop(List<CartProduct> list) {
        final ArrayList arrayList = new ArrayList(list);
        this.productAddedCallBack = new ProductAddedCallback() {
            /* class com.thedaw.uiuians.providers.woocommerce.checkout.CartWithCookies.AnonymousClass2 */

            @Override // com.thedaw.uiuians.providers.woocommerce.checkout.CartWithCookies.ProductAddedCallback
            public void success(CartProduct cartProduct) {
                arrayList.remove(cartProduct);
                if (arrayList.size() > 0) {
                    CartWithCookies.this.addProductToCart((CartProduct) arrayList.get(0), CartWithCookies.this.productAddedCallBack);
                } else {
                    CartWithCookies.this.allProductsAddedCallback.success(CartWithCookies.this.mCookieStore);
                }
            }

            @Override // com.thedaw.uiuians.providers.woocommerce.checkout.CartWithCookies.ProductAddedCallback
            public void failure() {
                CartWithCookies.this.allProductsAddedCallback.failure();
            }
        };
        addProductToCart((CartProduct) arrayList.get(0), this.productAddedCallBack);
    }

    public void addProductsToCart(final List<CartProduct> list) {
        if (!CredentialStorage.credentialsAvailable(this.mContext)) {
            startProductsToCartLoop(list);
            return;
        }
        FormBody build = new FormBody.Builder().add("log", CredentialStorage.getEmail(this.mContext)).add("pwd", CredentialStorage.getPassword(this.mContext)).build();
        RestAPI restAPI = new RestAPI(this.mContext);
        Request.Builder builder = new Request.Builder();
        Request build2 = builder.url(restAPI.getHost() + restAPI.getLogin()).post(build).build();
        if (client == null) {
            client = new OkHttpClient.Builder().cookieJar(this.mCookies).build();
        }
        client.newCall(build2).enqueue(new Callback() {
            /* class com.thedaw.uiuians.providers.woocommerce.checkout.CartWithCookies.AnonymousClass3 */

            @Override // okhttp3.Callback
            public void onFailure(Call call, IOException iOException) {
                iOException.printStackTrace();
                CartWithCookies.this.allProductsAddedCallback.failure();
            }

            @Override // okhttp3.Callback
            public void onResponse(Call call, Response response) throws IOException {
                CartWithCookies.this.startProductsToCartLoop(list);
                response.close();
            }
        });
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void addProductToCart(final CartProduct cartProduct, final ProductAddedCallback productAddedCallback) {
        Integer num;
        OkHttpClient build = new OkHttpClient.Builder().cookieJar(this.mCookies).build();
        if (cartProduct.getVariation() == null) {
            num = cartProduct.getProduct().getId();
        } else {
            num = cartProduct.getVariation().getId();
        }
        int intValue = num.intValue();
        RestAPI restAPI = new RestAPI(this.mContext);
        Request.Builder builder = new Request.Builder();
        build.newCall(builder.url(restAPI.getHost() + "?add-to-cart=" + intValue + "&quantity=" + cartProduct.getQuantity()).get().build()).enqueue(new Callback() {
            /* class com.thedaw.uiuians.providers.woocommerce.checkout.CartWithCookies.AnonymousClass4 */

            @Override // okhttp3.Callback
            public void onFailure(Call call, IOException iOException) {
                iOException.printStackTrace();
                productAddedCallback.failure();
            }

            @Override // okhttp3.Callback
            public void onResponse(Call call, Response response) throws IOException {
                Log.v("INFO", "RESPONSE CODE: " + response.code());
                productAddedCallback.success(cartProduct);
                response.close();
            }
        });
    }
}

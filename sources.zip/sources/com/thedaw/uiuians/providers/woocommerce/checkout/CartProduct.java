package com.thedaw.uiuians.providers.woocommerce.checkout;

import com.thedaw.uiuians.providers.woocommerce.model.products.Product;
import java.io.Serializable;

public class CartProduct implements Serializable {
    private Product product;
    private int quantity;
    private Product variation;

    public CartProduct(Product product2, Product product3) {
        this.product = product2;
        this.quantity = 1;
        this.variation = product3;
    }

    public CartProduct(Product product2) {
        this.product = product2;
        this.quantity = 1;
        this.variation = null;
    }

    /* access modifiers changed from: package-private */
    public void updateQuantity(int i) {
        this.quantity += i;
    }

    /* access modifiers changed from: package-private */
    public void setQuantity(int i) {
        this.quantity = i;
    }

    public int getQuantity() {
        return this.quantity;
    }

    public Product getVariation() {
        return this.variation;
    }

    public Product getProduct() {
        return this.product;
    }
}

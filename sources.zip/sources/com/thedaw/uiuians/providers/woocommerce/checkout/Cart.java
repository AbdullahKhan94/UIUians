package com.thedaw.uiuians.providers.woocommerce.checkout;

import android.content.Context;
import com.thedaw.uiuians.providers.woocommerce.model.products.Product;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Cart implements Serializable {
    private static ArrayList<CartProduct> productsInCart;
    private String CACHE_FILE = "cart";
    private CartListener callback;
    private Context context;

    public interface CartListener {
        void onCartUpdated();
    }

    private Cart(Context context2) {
        this.context = context2;
        if (productsInCart == null) {
            ArrayList<CartProduct> retrieveCart = retrieveCart();
            if (retrieveCart != null) {
                productsInCart = retrieveCart;
            } else {
                productsInCart = new ArrayList<>();
            }
        }
    }

    public static Cart getInstance(Context context2) {
        return new Cart(context2);
    }

    /* access modifiers changed from: package-private */
    public boolean addProductToCart(Product product, Product product2) {
        Iterator<CartProduct> it = productsInCart.iterator();
        while (it.hasNext()) {
            CartProduct next = it.next();
            if (next.getProduct().getId().equals(product.getId()) && (next.getVariation() == null || next.getVariation().getId().equals(product2.getId()))) {
                if (!productIsInStock(product, next.getQuantity() + 1, product2)) {
                    return false;
                }
                next.updateQuantity(1);
                return true;
            }
        }
        if (!productIsInStock(product, 1, product2)) {
            return false;
        }
        addProductToCart(new CartProduct(product, product2));
        return true;
    }

    private void addProductToCart(CartProduct cartProduct) {
        productsInCart.add(cartProduct);
        saveCart();
    }

    public boolean removeProductFromCart(Product product, Product product2) {
        ListIterator<CartProduct> listIterator = productsInCart.listIterator();
        while (listIterator.hasNext()) {
            CartProduct next = listIterator.next();
            if (next.getProduct().getId().equals(product.getId()) && (next.getVariation() == null || next.getVariation().getId().equals(product2.getId()))) {
                boolean z = true;
                if (next.getQuantity() > 1) {
                    next.updateQuantity(-1);
                    z = false;
                } else {
                    listIterator.remove();
                }
                saveCart();
                return z;
            }
        }
        return false;
    }

    public boolean setProductQuantity(CartProduct cartProduct, int i) {
        if (!productsInCart.contains(cartProduct) || !productIsInStock(cartProduct.getProduct(), i, cartProduct.getVariation())) {
            return false;
        }
        cartProduct.setQuantity(i);
        saveCart();
        return true;
    }

    public void clearCart() {
        productsInCart.clear();
        saveCart();
    }

    public ArrayList<CartProduct> getCartProducts() {
        return productsInCart;
    }

    private boolean productIsInStock(Product product, int i, Product product2) {
        if (product2 != null) {
            product = product2;
        }
        if (!product.getManageStock().booleanValue()) {
            return product.getInStock().booleanValue();
        }
        return product.getStockQuantity().intValue() > i;
    }

    private void saveCart() {
        if (this.callback != null) {
            this.callback.onCartUpdated();
        }
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(new File(this.context.getCacheDir(), "") + this.CACHE_FILE));
            objectOutputStream.writeObject(productsInCart);
            objectOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private ArrayList<CartProduct> retrieveCart() {
        try {
            ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(new File(new File(this.context.getCacheDir(), "") + this.CACHE_FILE)));
            ArrayList<CartProduct> arrayList = (ArrayList) objectInputStream.readObject();
            objectInputStream.close();
            return arrayList;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (ClassNotFoundException e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public void setCartListener(CartListener cartListener) {
        this.callback = cartListener;
    }
}

package com.thedaw.uiuians.providers.woocommerce.checkout;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.woocommerce.WooCommerceTask;
import com.thedaw.uiuians.providers.woocommerce.model.products.Attribute;
import com.thedaw.uiuians.providers.woocommerce.model.products.Product;
import com.thedaw.uiuians.providers.woocommerce.ui.CartFragment;
import java.util.ArrayList;
import java.util.Iterator;

public class CartAssistant {
    private Cart mCart;
    private View mCartButton;
    private Context mContext;
    private Product mProduct;
    private ArrayList<Product> variations;

    public CartAssistant(Context context, View view, Product product) {
        this.mCart = Cart.getInstance(context);
        this.mContext = context;
        this.mCartButton = view;
        this.mProduct = product;
    }

    public void addProductToCart(Product product) {
        if (this.mProduct.getExternalUrl() != null && !this.mProduct.getExternalUrl().isEmpty()) {
            HolderActivity.startWebViewActivity(this.mContext, this.mProduct.getExternalUrl(), false, false, null);
        } else if (!this.mProduct.getType().equals("variable") || product != null) {
            Snackbar action = Snackbar.make(this.mCartButton, this.mCart.addProductToCart(this.mProduct, product) ? R.string.cart_success : R.string.out_of_stock, 0).setAction(R.string.view_cart, new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.woocommerce.checkout.CartAssistant.AnonymousClass1 */

                public void onClick(View view) {
                    HolderActivity.startActivity(CartAssistant.this.mContext, CartFragment.class, null);
                }
            });
            action.show();
            ((TextView) action.getView().findViewById(R.id.snackbar_text)).setTextColor(this.mContext.getResources().getColor(R.color.white));
        } else {
            retrieveVariations();
        }
    }

    private void retrieveVariations() {
        if (this.variations == null) {
            final ProgressDialog show = ProgressDialog.show(this.mContext, this.mContext.getResources().getString(R.string.loading), this.mContext.getResources().getString(R.string.loading), true);
            new WooCommerceTask.WooCommerceBuilder(this.mContext).getVariationsForProduct(new WooCommerceTask.Callback<Product>() {
                /* class com.thedaw.uiuians.providers.woocommerce.checkout.CartAssistant.AnonymousClass2 */

                @Override // com.thedaw.uiuians.providers.woocommerce.WooCommerceTask.Callback
                public void success(ArrayList<Product> arrayList) {
                    show.dismiss();
                    CartAssistant.this.variations = arrayList;
                    CartAssistant.this.selectVariation();
                }

                @Override // com.thedaw.uiuians.providers.woocommerce.WooCommerceTask.Callback
                public void failed() {
                    show.dismiss();
                    Toast.makeText(CartAssistant.this.mContext, (int) R.string.varations_missing, 0).show();
                }
            }, this.mProduct.getId().intValue()).execute(new Void[0]);
            return;
        }
        selectVariation();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void selectVariation() {
        ArrayList arrayList = new ArrayList();
        Iterator<Product> it = this.variations.iterator();
        while (it.hasNext()) {
            Product next = it.next();
            String variationDescription = getVariationDescription(next);
            arrayList.add(variationDescription + " (" + PriceFormat.formatPrice(Float.valueOf(getPrice(this.mProduct, next))) + ")");
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this.mContext);
        builder.setItems((String[]) arrayList.toArray(new String[0]), new DialogInterface.OnClickListener() {
            /* class com.thedaw.uiuians.providers.woocommerce.checkout.CartAssistant.AnonymousClass3 */

            public void onClick(DialogInterface dialogInterface, int i) {
                CartAssistant.this.addProductToCart((Product) CartAssistant.this.variations.get(i));
            }
        });
        if (this.variations.size() == 0) {
            builder.setMessage(R.string.out_of_stock);
        }
        builder.setTitle(R.string.varations);
        builder.create().show();
    }

    public static String getVariationDescription(Product product) {
        ArrayList arrayList = new ArrayList();
        for (Attribute attribute : product.getAttributes()) {
            arrayList.add(attribute.getName() + ": " + attribute.getOption());
        }
        return TextUtils.join(", ", arrayList);
    }

    public static float getPrice(Product product, Product product2) {
        if (product2 == null || product2.getPrice() == 0.0f) {
            return product.getPrice();
        }
        if (product2.getOnSale().booleanValue()) {
            return product2.getSalePrice();
        }
        return product2.getPrice();
    }
}

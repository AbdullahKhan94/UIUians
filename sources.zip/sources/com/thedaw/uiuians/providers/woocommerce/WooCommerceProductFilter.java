package com.thedaw.uiuians.providers.woocommerce;

public class WooCommerceProductFilter {
    private double maxPrice;
    private double minPrice;
    private boolean onlyFeatured;
    private boolean onlyInStock;
    private boolean onlySale;

    public WooCommerceProductFilter minPrice(double d) {
        this.minPrice = d;
        return this;
    }

    public WooCommerceProductFilter maxPrice(double d) {
        this.maxPrice = d;
        return this;
    }

    public WooCommerceProductFilter onlySale(boolean z) {
        this.onlySale = z;
        return this;
    }

    public WooCommerceProductFilter onlyFeatured(boolean z) {
        this.onlyFeatured = z;
        return this;
    }

    public WooCommerceProductFilter onlyInStock(boolean z) {
        this.onlyInStock = z;
        return this;
    }

    public String getQuery() {
        StringBuilder sb = new StringBuilder();
        if (this.minPrice != 0.0d) {
            sb.append("&min_price=" + this.minPrice);
        }
        if (this.maxPrice != 0.0d) {
            sb.append("&max_price=" + this.maxPrice);
        }
        if (this.onlyFeatured) {
            sb.append("&featured=" + Boolean.toString(this.onlyFeatured));
        }
        if (this.onlySale) {
            sb.append("&on_sale=" + Boolean.toString(this.onlySale));
        }
        if (this.onlyInStock) {
            sb.append("&in_stock=" + Boolean.toString(this.onlyInStock));
        }
        return sb.toString();
    }

    public double getMaxPrice() {
        return this.maxPrice;
    }

    public double getMinPrice() {
        return this.minPrice;
    }

    public boolean isOnlyFeatured() {
        return this.onlyFeatured;
    }

    public boolean isOnlySale() {
        return this.onlySale;
    }

    public boolean isOnlyInStock() {
        return this.onlyInStock;
    }

    public void clearFilters() {
        this.minPrice = 0.0d;
        this.maxPrice = 0.0d;
    }
}

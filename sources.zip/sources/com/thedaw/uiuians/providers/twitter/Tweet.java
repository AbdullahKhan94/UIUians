package com.thedaw.uiuians.providers.twitter;

import android.annotation.SuppressLint;
import com.thedaw.uiuians.util.Log;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;

public class Tweet {
    private String imageUrl;
    private String message;
    private String name;
    private int retweetCount;
    private String tweetDate;
    private String tweetId;
    private String urlProfileImage;
    private String username;

    public String getname() {
        return this.name;
    }

    public void setname(String str) {
        this.name = str;
    }

    public String getusername() {
        return this.username;
    }

    public void setusername(String str) {
        this.username = str;
    }

    public String geturlProfileImage() {
        return this.urlProfileImage;
    }

    public void seturlProfileImage(String str) {
        this.urlProfileImage = str;
    }

    public String getmessage() {
        return this.message;
    }

    public void setmessage(String str) {
        this.message = str;
    }

    public String getData() {
        return this.tweetDate;
    }

    public void setTweetId(String str) {
        this.tweetId = str;
    }

    public String getTweetId() {
        return this.tweetId;
    }

    public void setRetweetCount(int i) {
        this.retweetCount = i;
    }

    public int getRetweetCount() {
        return this.retweetCount;
    }

    public void setImageUrl(String str) {
        this.imageUrl = str;
    }

    public String getImageUrl() {
        return this.imageUrl;
    }

    public void setData(String str) {
        this.tweetDate = fomatData(removeTimeZone(str));
    }

    @SuppressLint({"SimpleDateFormat"})
    private String fomatData(String str) {
        TimeZone timeZone = TimeZone.getTimeZone("UTC");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss yyyy", Locale.getDefault());
        simpleDateFormat.setTimeZone(timeZone);
        try {
            return new SimpleDateFormat("EEE, dd/MM/yy, 'at' HH:mm").format(simpleDateFormat.parse(str));
        } catch (ParseException e) {
            Log.e("Error parsing data", e.toString());
            return null;
        }
    }

    private String removeTimeZone(String str) {
        return str.replaceFirst("(\\s[+|-]\\d{4})", "");
    }
}

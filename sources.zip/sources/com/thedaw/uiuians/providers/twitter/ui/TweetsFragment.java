package com.thedaw.uiuians.providers.twitter.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.google.android.exoplayer2.text.ttml.TtmlNode;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.twitter.Tweet;
import com.thedaw.uiuians.providers.twitter.TweetAdapter;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import com.thedaw.uiuians.util.Log;
import com.thedaw.uiuians.util.ThemeUtils;
import io.fabric.sdk.android.services.network.HttpRequest;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TweetsFragment extends Fragment implements InfiniteRecyclerViewAdapter.LoadMoreListener {
    Boolean isLoading = true;
    String latesttweetid;
    private RecyclerView listView;
    private RelativeLayout ll;
    private Activity mAct;
    String perpage = "25";
    String searchValue;
    private TweetAdapter tweetAdapter;
    private ArrayList<Tweet> tweets;

    @Override // android.support.v4.app.Fragment
    @SuppressLint({"InflateParams"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list, viewGroup, false);
        setHasOptionsMenu(true);
        this.searchValue = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        this.listView = (RecyclerView) this.ll.findViewById(R.id.list);
        this.tweets = new ArrayList<>();
        this.tweetAdapter = new TweetAdapter(getContext(), this.tweets, this);
        this.tweetAdapter.setModeAndNotify(3);
        this.listView.setAdapter(this.tweetAdapter);
        this.listView.setLayoutManager(new LinearLayoutManager(getContext(), 1, false));
        return this.ll;
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        refreshItems();
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.refresh) {
            if (!this.isLoading.booleanValue()) {
                refreshItems();
            } else {
                Toast.makeText(this.mAct, getString(R.string.already_loading), 1).show();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void refreshItems() {
        this.isLoading = true;
        this.latesttweetid = null;
        this.tweets.clear();
        this.tweetAdapter.setHasMore(true);
        this.tweetAdapter.setModeAndNotify(3);
        new SearchTweetsTask().execute(this.searchValue);
    }

    public void updateList(ArrayList<Tweet> arrayList) {
        if (arrayList.size() > 0) {
            this.tweets.addAll(arrayList);
        }
        if (arrayList.size() == 0) {
            this.tweetAdapter.setHasMore(false);
        }
        this.tweetAdapter.setModeAndNotify(1);
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter.LoadMoreListener
    public void onMoreRequested() {
        if (!this.isLoading.booleanValue()) {
            new SearchTweetsTask().execute(this.searchValue);
        }
    }

    /* access modifiers changed from: private */
    public class SearchTweetsTask extends AsyncTask<String, Void, ArrayList<Tweet>> {
        private final String CONSUMER_KEY;
        private final String CONSUMER_SECRET;
        private final String URL_AUTH;
        private final String URL_BASE;
        private final String URL_PARAM;
        private final String URL_SEARCH;
        private final String URL_TIMELINE;
        private String URL_VALUE;

        private SearchTweetsTask() {
            this.URL_BASE = "https://api.twitter.com";
            this.URL_TIMELINE = "https://api.twitter.com/1.1/statuses/user_timeline.json?count=" + TweetsFragment.this.perpage + "&tweet_mode=extended&exclude_replies=true&include_rts=1&screen_name=";
            this.URL_SEARCH = "https://api.twitter.com/1.1/search/tweets.json?count=" + TweetsFragment.this.perpage + "&q=";
            this.URL_PARAM = "&max_id=";
            this.URL_AUTH = "https://api.twitter.com/oauth2/token";
            this.CONSUMER_KEY = TweetsFragment.this.getResources().getString(R.string.twitter_api_consumer_key);
            this.CONSUMER_SECRET = TweetsFragment.this.getResources().getString(R.string.twitter_api_consumer_secret_key);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:11:0x00a1, code lost:
            if (r1 != null) goto L_0x00a3;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:12:0x00a3, code lost:
            r1.disconnect();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x00ce, code lost:
            if (r1 == null) goto L_0x00d1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:24:0x00d1, code lost:
            if (r3 != null) goto L_0x00d4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:0x00d3, code lost:
            return null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:27:0x00d8, code lost:
            return r3.toString();
         */
        /* JADX WARNING: Removed duplicated region for block: B:30:0x00dc  */
        private String authenticateApp() {
            HttpURLConnection httpURLConnection;
            Throwable th;
            StringBuilder sb;
            Exception e;
            try {
                httpURLConnection = (HttpURLConnection) new URL("https://api.twitter.com/oauth2/token").openConnection();
                try {
                    httpURLConnection.setRequestMethod(HttpRequest.METHOD_POST);
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    String str = this.CONSUMER_KEY + ":" + this.CONSUMER_SECRET;
                    httpURLConnection.addRequestProperty(HttpRequest.HEADER_AUTHORIZATION, "Basic " + Base64.encodeToString(str.getBytes(), 2));
                    httpURLConnection.setRequestProperty(HttpRequest.HEADER_CONTENT_TYPE, "application/x-www-form-urlencoded;charset=UTF-8");
                    httpURLConnection.connect();
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    outputStream.write("grant_type=client_credentials".getBytes());
                    outputStream.flush();
                    outputStream.close();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                    sb = new StringBuilder();
                    while (true) {
                        try {
                            String readLine = bufferedReader.readLine();
                            if (readLine == null) {
                                break;
                            }
                            sb.append(readLine);
                        } catch (Exception e2) {
                            e = e2;
                            try {
                                Log.e("INFO", "Exception: " + e.toString());
                            } catch (Throwable th2) {
                                th = th2;
                                if (httpURLConnection != null) {
                                }
                                throw th;
                            }
                        }
                    }
                    Log.d("Post response", String.valueOf(httpURLConnection.getResponseCode()));
                    Log.d("Json response - tokenk", sb.toString());
                } catch (Exception e3) {
                    e = e3;
                    sb = null;
                    Log.e("INFO", "Exception: " + e.toString());
                }
            } catch (Exception e4) {
                e = e4;
                httpURLConnection = null;
                sb = null;
                Log.e("INFO", "Exception: " + e.toString());
            } catch (Throwable th3) {
                httpURLConnection = null;
                th = th3;
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                throw th;
            }
        }

        /* access modifiers changed from: protected */
        public void onPreExecute() {
            super.onPreExecute();
            TweetsFragment.this.isLoading = true;
        }

        /* access modifiers changed from: protected */
        /* JADX WARNING: Code restructure failed: missing block: B:48:0x020d, code lost:
            r0 = th;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:49:0x020f, code lost:
            r0 = e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:50:0x0210, code lost:
            r3 = null;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Removed duplicated region for block: B:48:0x020d A[ExcHandler: all (th java.lang.Throwable), Splitter:B:20:0x00af] */
        /* JADX WARNING: Removed duplicated region for block: B:59:0x0239  */
        /* JADX WARNING: Removed duplicated region for block: B:62:0x023f  */
        public ArrayList<Tweet> doInBackground(String... strArr) {
            ArrayList<Tweet> arrayList;
            Exception e;
            URL url;
            JSONArray jSONArray;
            String str = strArr[0];
            Boolean bool = false;
            if (str.startsWith("?")) {
                this.URL_VALUE = this.URL_SEARCH;
                try {
                    str = URLEncoder.encode(str.substring(1), "UTF-8");
                } catch (UnsupportedEncodingException e2) {
                    Log.printStackTrace(e2);
                }
                bool = true;
            } else {
                this.URL_VALUE = this.URL_TIMELINE;
            }
            HttpURLConnection httpURLConnection = null;
            try {
                if (TweetsFragment.this.latesttweetid == null || TweetsFragment.this.latesttweetid.equals("")) {
                    url = new URL(this.URL_VALUE + str);
                } else {
                    Long valueOf = Long.valueOf(Long.parseLong(TweetsFragment.this.latesttweetid) - 1);
                    url = new URL(this.URL_VALUE + str + "&max_id=" + Long.toString(valueOf.longValue()));
                }
                Log.v("INFO", "Requesting: " + url.toString());
                HttpURLConnection httpURLConnection2 = (HttpURLConnection) url.openConnection();
                try {
                    httpURLConnection2.setRequestMethod(HttpRequest.METHOD_GET);
                    JSONObject jSONObject = new JSONObject(authenticateApp());
                    httpURLConnection2.setRequestProperty(HttpRequest.HEADER_AUTHORIZATION, jSONObject.getString("token_type") + " " + jSONObject.getString("access_token"));
                    httpURLConnection2.setRequestProperty(HttpRequest.HEADER_CONTENT_TYPE, "application/json");
                    httpURLConnection2.connect();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection2.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    while (true) {
                        String readLine = bufferedReader.readLine();
                        if (readLine == null) {
                            break;
                        }
                        sb.append(readLine);
                    }
                    Log.d("GET response", String.valueOf(httpURLConnection2.getResponseCode()));
                    Log.d("JSON response", sb.toString());
                    if (bool.booleanValue()) {
                        jSONArray = new JSONObject(sb.toString()).getJSONArray("statuses");
                    } else {
                        jSONArray = new JSONArray(sb.toString());
                    }
                    arrayList = new ArrayList<>();
                    for (int i = 0; i < jSONArray.length(); i++) {
                        JSONObject jSONObject2 = (JSONObject) jSONArray.get(i);
                        Tweet tweet = new Tweet();
                        tweet.setname(jSONObject2.getJSONObject("user").getString("name"));
                        tweet.setusername(jSONObject2.getJSONObject("user").getString("screen_name"));
                        tweet.seturlProfileImage(jSONObject2.getJSONObject("user").getString("profile_image_url").replace("_normal", ""));
                        tweet.setmessage(jSONObject2.getString("full_text"));
                        tweet.setRetweetCount(jSONObject2.getInt("retweet_count"));
                        tweet.setData(jSONObject2.getString("created_at"));
                        tweet.setTweetId(jSONObject2.getString(TtmlNode.ATTR_ID));
                        try {
                            if (jSONObject2.has("extended_entities")) {
                                String string = ((JSONObject) jSONObject2.getJSONObject("extended_entities").getJSONArray("media").get(0)).getString("media_url");
                                if (((JSONObject) jSONObject2.getJSONObject("extended_entities").getJSONArray("media").get(0)).getString("type").equalsIgnoreCase("photo")) {
                                    tweet.setImageUrl(string);
                                }
                            }
                        } catch (JSONException e3) {
                            Log.printStackTrace(e3);
                        }
                        TweetsFragment.this.latesttweetid = jSONObject2.getString(TtmlNode.ATTR_ID);
                        arrayList.add(i, tweet);
                    }
                    if (httpURLConnection2 != null) {
                        httpURLConnection2.disconnect();
                    }
                } catch (Exception e4) {
                    e = e4;
                    httpURLConnection = httpURLConnection2;
                    try {
                        Log.printStackTrace(e);
                        Log.e("INFO", "Exception: GET " + e.toString());
                        if (httpURLConnection != null) {
                        }
                        return arrayList;
                    } catch (Throwable th) {
                        Throwable th2 = th;
                        httpURLConnection2 = httpURLConnection;
                        if (httpURLConnection2 != null) {
                            httpURLConnection2.disconnect();
                        }
                        throw th2;
                    }
                } catch (Throwable th3) {
                }
            } catch (Exception e5) {
                e = e5;
                arrayList = null;
                Log.printStackTrace(e);
                Log.e("INFO", "Exception: GET " + e.toString());
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                return arrayList;
            }
            return arrayList;
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(ArrayList<Tweet> arrayList) {
            TweetsFragment.this.isLoading = false;
            if (arrayList != null) {
                TweetsFragment.this.updateList(arrayList);
                return;
            }
            Helper.noConnection(TweetsFragment.this.mAct);
            TweetsFragment.this.tweetAdapter.setModeAndNotify(2);
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.refresh_menu, menu);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }
}

package com.thedaw.uiuians.providers.twitter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.attachmentviewer.model.MediaAttachment;
import com.thedaw.uiuians.attachmentviewer.ui.AttachmentActivity;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import com.thedaw.uiuians.util.WebHelper;
import java.util.ArrayList;

public class TweetAdapter extends InfiniteRecyclerViewAdapter {
    private Context context;
    private ArrayList<Tweet> tweets;

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getViewType(int i) {
        return 0;
    }

    public TweetAdapter(Context context2, ArrayList<Tweet> arrayList, InfiniteRecyclerViewAdapter.LoadMoreListener loadMoreListener) {
        super(context2, loadMoreListener);
        this.context = context2;
        this.tweets = arrayList;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public RecyclerView.ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        return new TweetHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_tweets_row, viewGroup, false));
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public void doBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof TweetHolder) {
            TweetHolder tweetHolder = (TweetHolder) viewHolder;
            final Tweet tweet = this.tweets.get(i);
            tweetHolder.name.setText(tweet.getname());
            TextView textView = tweetHolder.username;
            textView.setText("@" + tweet.getusername());
            tweetHolder.date.setText(tweet.getData());
            tweetHolder.message.setText(Html.fromHtml(tweet.getmessage()));
            tweetHolder.message.setTextSize(2, (float) WebHelper.getTextViewFontSize(this.context));
            tweetHolder.retweetCount.setText(Helper.formatValue((double) tweet.getRetweetCount()));
            Picasso.get().load(tweet.geturlProfileImage()).into(tweetHolder.imagem);
            if (tweet.getImageUrl() != null) {
                tweetHolder.photo.setVisibility(0);
                Picasso.get().load(tweet.getImageUrl()).placeholder(R.drawable.placeholder).into(tweetHolder.photo);
                tweetHolder.photo.setOnClickListener(new View.OnClickListener() {
                    /* class com.thedaw.uiuians.providers.twitter.TweetAdapter.AnonymousClass1 */

                    public void onClick(View view) {
                        AttachmentActivity.startActivity(TweetAdapter.this.context, MediaAttachment.withImage(tweet.getImageUrl()));
                    }
                });
            } else {
                tweetHolder.photo.setImageDrawable(null);
                tweetHolder.photo.setVisibility(8);
            }
            tweetHolder.itemView.findViewById(R.id.share).setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.twitter.TweetAdapter.AnonymousClass2 */

                public void onClick(View view) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", "http://twitter.com/" + tweet.getusername() + "/status/" + tweet.getTweetId());
                    StringBuilder sb = new StringBuilder();
                    sb.append(tweet.getusername());
                    sb.append(TweetAdapter.this.context.getResources().getString(R.string.tweet_share_header));
                    intent.putExtra("android.intent.extra.SUBJECT", sb.toString());
                    intent.setType("text/plain");
                    TweetAdapter.this.context.startActivity(Intent.createChooser(intent, TweetAdapter.this.context.getResources().getString(R.string.share_header)));
                }
            });
            tweetHolder.itemView.findViewById(R.id.open).setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.twitter.TweetAdapter.AnonymousClass3 */

                public void onClick(View view) {
                    HolderActivity.startWebViewActivity(TweetAdapter.this.context, "http://twitter.com/" + tweet.getusername() + "/status/" + tweet.getTweetId(), false, false, null);
                }
            });
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getCount() {
        return this.tweets.size();
    }

    private class TweetHolder extends RecyclerView.ViewHolder {
        TextView date;
        ImageView imagem;
        TextView message;
        TextView name;
        ImageView photo;
        TextView retweetCount;
        TextView username;

        TweetHolder(View view) {
            super(view);
            this.name = (TextView) view.findViewById(R.id.name);
            this.username = (TextView) view.findViewById(R.id.username);
            this.imagem = (ImageView) view.findViewById(R.id.profile_image);
            this.photo = (ImageView) view.findViewById(R.id.photo);
            this.message = (TextView) view.findViewById(R.id.message);
            this.retweetCount = (TextView) view.findViewById(R.id.retweet_count);
            this.date = (TextView) view.findViewById(R.id.date);
        }
    }
}

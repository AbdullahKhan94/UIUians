package com.thedaw.uiuians.providers.wordpress.api.providers;

import com.thedaw.uiuians.providers.wordpress.CategoryItem;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import com.thedaw.uiuians.providers.wordpress.api.WordpressGetTaskInfo;
import java.util.ArrayList;

public interface WordpressProvider {
    ArrayList<CategoryItem> getCategories(WordpressGetTaskInfo wordpressGetTaskInfo);

    String getCategoryPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str);

    String getRecentPosts(WordpressGetTaskInfo wordpressGetTaskInfo);

    String getSearchPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str);

    String getTagPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str);

    ArrayList<PostItem> parsePostsFromUrl(WordpressGetTaskInfo wordpressGetTaskInfo, String str);
}

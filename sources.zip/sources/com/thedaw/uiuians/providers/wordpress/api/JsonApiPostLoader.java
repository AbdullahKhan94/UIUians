package com.thedaw.uiuians.providers.wordpress.api;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.thedaw.uiuians.providers.soundcloud.api.SoundCloudClient;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import com.thedaw.uiuians.providers.wordpress.api.providers.JsonApiProvider;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import org.json.JSONObject;

public final class JsonApiPostLoader extends Thread {
    private String apiBase;
    private PostItem item;
    private BackgroundPostCompleterListener listener;

    public interface BackgroundPostCompleterListener {
        void completed(PostItem postItem);
    }

    public JsonApiPostLoader(PostItem postItem, String str, BackgroundPostCompleterListener backgroundPostCompleterListener) {
        this.item = postItem;
        this.apiBase = str;
        this.listener = backgroundPostCompleterListener;
    }

    public void run() {
        JSONObject jSONObjectFromUrl = Helper.getJSONObjectFromUrl(JsonApiProvider.getPostUrl(this.item.getId().longValue(), this.apiBase));
        try {
            if (jSONObjectFromUrl.getString("status").equalsIgnoreCase("ok")) {
                JSONObject jSONObject = jSONObjectFromUrl.getJSONObject("post");
                this.item.setContent(jSONObject.getString(FirebaseAnalytics.Param.CONTENT));
                this.item.setCommentCount(Long.valueOf((long) jSONObject.getInt("comment_count")));
                this.item.setCommentsArray(jSONObject.getJSONArray(SoundCloudClient.COMMENTS));
                this.item.setPostCompleted();
                if (this.listener != null) {
                    this.listener.completed(this.item);
                }
            }
        } catch (Exception e) {
            Log.printStackTrace(e);
            if (this.listener != null) {
                this.listener.completed(null);
            }
        }
    }
}

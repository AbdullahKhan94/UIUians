package com.thedaw.uiuians.providers.wordpress.api;

import android.os.AsyncTask;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import java.util.ArrayList;

public class WordpressPostsTask extends AsyncTask<String, Integer, ArrayList<PostItem>> {
    public static final int PER_PAGE = 15;
    public static final int PER_PAGE_RELATED = 4;
    private WordpressPostsCallback callback;
    private WordpressGetTaskInfo info;
    private String url;

    public interface WordpressPostsCallback {
        void postsFailed();

        void postsLoaded(ArrayList<PostItem> arrayList);
    }

    /* access modifiers changed from: protected */
    public void onPreExecute() {
    }

    public WordpressPostsTask(String str, WordpressGetTaskInfo wordpressGetTaskInfo, WordpressPostsCallback wordpressPostsCallback) {
        this.url = str;
        this.info = wordpressGetTaskInfo;
        this.callback = wordpressPostsCallback;
    }

    /* access modifiers changed from: protected */
    public ArrayList<PostItem> doInBackground(String... strArr) {
        this.info.curpage = Integer.valueOf(this.info.curpage.intValue() + 1);
        this.url += Integer.toString(this.info.curpage.intValue());
        return this.info.provider.parsePostsFromUrl(this.info, this.url);
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(ArrayList<PostItem> arrayList) {
        if (arrayList != null) {
            this.callback.postsLoaded(arrayList);
        } else {
            this.callback.postsFailed();
        }
    }
}

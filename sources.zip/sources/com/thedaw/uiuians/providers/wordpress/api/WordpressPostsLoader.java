package com.thedaw.uiuians.providers.wordpress.api;

import android.widget.Toast;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import com.thedaw.uiuians.providers.wordpress.api.WordpressPostsTask;
import com.thedaw.uiuians.providers.wordpress.api.providers.JsonApiProvider;
import com.thedaw.uiuians.providers.wordpress.api.providers.RestApiProvider;
import com.thedaw.uiuians.util.Helper;
import java.util.ArrayList;

public class WordpressPostsLoader implements WordpressPostsTask.WordpressPostsCallback {
    private WordpressGetTaskInfo info;
    private boolean initialload;
    private String url;

    public static String getRecentPosts(WordpressGetTaskInfo wordpressGetTaskInfo) {
        String recentPosts = wordpressGetTaskInfo.provider.getRecentPosts(wordpressGetTaskInfo);
        new WordpressPostsLoader(recentPosts, true, wordpressGetTaskInfo).load();
        return recentPosts;
    }

    public static String getTagPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        String tagPosts = wordpressGetTaskInfo.provider.getTagPosts(wordpressGetTaskInfo, str);
        new WordpressPostsLoader(tagPosts, true, wordpressGetTaskInfo).load();
        return tagPosts;
    }

    public static String getCategoryPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        String categoryPosts = wordpressGetTaskInfo.provider.getCategoryPosts(wordpressGetTaskInfo, str);
        new WordpressPostsLoader(categoryPosts, true, wordpressGetTaskInfo).load();
        return categoryPosts;
    }

    public static String getSearchPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        if (wordpressGetTaskInfo.isLoading) {
            wordpressGetTaskInfo.isLoading = false;
        }
        String searchPosts = wordpressGetTaskInfo.provider.getSearchPosts(wordpressGetTaskInfo, str);
        new WordpressPostsLoader(searchPosts, true, wordpressGetTaskInfo).load();
        return searchPosts;
    }

    public static void loadMorePosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        new WordpressPostsLoader(str, false, wordpressGetTaskInfo).load();
    }

    private WordpressPostsLoader(String str, boolean z, WordpressGetTaskInfo wordpressGetTaskInfo) {
        this.url = str;
        this.initialload = z;
        this.info = wordpressGetTaskInfo;
    }

    private void load() {
        if (!this.info.isLoading) {
            this.info.isLoading = true;
            if (this.initialload) {
                this.info.adapter.setModeAndNotify(3);
                this.info.adapter.setHasMore(true);
                this.info.posts.clear();
                this.info.curpage = 0;
            }
            new WordpressPostsTask(this.url, this.info, this).execute(new String[0]);
        }
    }

    private void complete() {
        this.info.isLoading = false;
    }

    private void updateList(ArrayList<PostItem> arrayList) {
        if (arrayList.size() > 0) {
            this.info.posts.addAll(arrayList);
        }
        if (this.info.curpage.intValue() >= this.info.pages.intValue() || this.info.simpleMode.booleanValue()) {
            this.info.adapter.setHasMore(false);
        }
        this.info.adapter.setModeAndNotify(1);
    }

    private void showErrorMessage() {
        String str;
        if (this.info.baseurl.contains("\"")) {
            str = "Your parameters should not contain the character \". Note that the quotes in the documentation only represent the parameters to enter in the configurator tool.";
        } else if (this.info.baseurl.endsWith("/") && (this.info.provider instanceof JsonApiProvider)) {
            str = "Your base url " + this.info.baseurl + "should not not end with / (slash)";
        } else if (this.info.baseurl.endsWith("/v2/") || !(this.info.provider instanceof RestApiProvider)) {
            str = "The result of '" + this.url + "' does not appear to return valid JSON or at least not in the expected format.";
        } else {
            str = this.info.baseurl.endsWith("/v2/") + " is not a valid base url for the Wordpress REST API. A base url usually ends with wp-json/wp/v2/";
        }
        if (this.info.posts == null || this.info.posts.size() == 0) {
            this.info.adapter.setModeAndNotify(2);
        }
        Helper.noConnection(this.info.context, str);
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.WordpressPostsTask.WordpressPostsCallback
    public void postsLoaded(ArrayList<PostItem> arrayList) {
        updateList(arrayList);
        if (arrayList != null && arrayList.size() < 1 && !this.info.simpleMode.booleanValue()) {
            Toast.makeText(this.info.context, this.info.context.getResources().getString(R.string.no_results), 1).show();
            this.info.adapter.setModeAndNotify(1);
        } else if (arrayList != null && arrayList.size() > 0) {
            this.info.completedWithPosts();
        }
        complete();
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.WordpressPostsTask.WordpressPostsCallback
    public void postsFailed() {
        showErrorMessage();
        complete();
    }
}

package com.thedaw.uiuians.providers.wordpress.api.providers;

import android.text.Html;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.thedaw.uiuians.attachmentviewer.model.MediaAttachment;
import com.thedaw.uiuians.providers.wordpress.CategoryItem;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import com.thedaw.uiuians.providers.wordpress.api.WordpressGetTaskInfo;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JetPackProvider implements WordpressProvider {
    private static final String JETPACK_BASE = "https://public-api.wordpress.com/rest/v1.1/sites/";
    private static final SimpleDateFormat JETPACK_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.getDefault());
    private static final String JETPACK_FIELDS = "&fields=ID,author,title,URL,content,discussion,featured_image,post_thumbnail,tags,discussion,date,attachments";

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public String getRecentPosts(WordpressGetTaskInfo wordpressGetTaskInfo) {
        return JETPACK_BASE + wordpressGetTaskInfo.baseurl + "/posts/?number=" + 15 + JETPACK_FIELDS + "&page=";
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public String getTagPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(JETPACK_BASE);
        sb.append(wordpressGetTaskInfo.baseurl);
        sb.append("/posts/?number=");
        if (wordpressGetTaskInfo.simpleMode.booleanValue()) {
            sb.append(4);
        } else {
            sb.append(15);
        }
        sb.append("&tag=");
        sb.append(str);
        sb.append("&page=");
        return sb.toString();
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public String getCategoryPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        return JETPACK_BASE + wordpressGetTaskInfo.baseurl + "/posts/?number=" + 15 + "&category=" + str + "&page=";
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public String getSearchPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        return JETPACK_BASE + wordpressGetTaskInfo.baseurl + "/posts/?number=" + 15 + "&search=" + str + "&page=";
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public ArrayList<CategoryItem> getCategories(WordpressGetTaskInfo wordpressGetTaskInfo) {
        JSONObject jSONObjectFromUrl = Helper.getJSONObjectFromUrl(JETPACK_BASE + wordpressGetTaskInfo.baseurl + "/categories" + "?order_by=count&order=DESC&fields=ID,slug,name,post_count&number=15");
        ArrayList<CategoryItem> arrayList = null;
        if (jSONObjectFromUrl == null || !jSONObjectFromUrl.has("categories")) {
            return null;
        }
        try {
            JSONArray jSONArray = jSONObjectFromUrl.getJSONArray("categories");
            for (int i = 0; i < jSONArray.length(); i++) {
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                }
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                arrayList.add(new CategoryItem(jSONObject.getString("slug"), jSONObject.getString("name"), jSONObject.getInt("post_count")));
            }
        } catch (JSONException e) {
            Log.printStackTrace(e);
        }
        return arrayList;
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public ArrayList<PostItem> parsePostsFromUrl(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        Exception e;
        JSONObject jSONObjectFromUrl = Helper.getJSONObjectFromUrl(str);
        ArrayList<PostItem> arrayList = null;
        if (jSONObjectFromUrl == null) {
            return null;
        }
        try {
            wordpressGetTaskInfo.pages = Integer.valueOf((jSONObjectFromUrl.getInt("found") / 15) + (jSONObjectFromUrl.getInt("found") % 15 == 0 ? 0 : 1));
            if (!jSONObjectFromUrl.has("posts")) {
                return null;
            }
            JSONArray jSONArray = jSONObjectFromUrl.getJSONArray("posts");
            ArrayList<PostItem> arrayList2 = new ArrayList<>();
            for (int i = 0; i < jSONArray.length(); i++) {
                try {
                    try {
                        PostItem itemFromJsonObject = itemFromJsonObject(jSONArray.getJSONObject(i));
                        if (!itemFromJsonObject.getId().equals(wordpressGetTaskInfo.ignoreId)) {
                            arrayList2.add(itemFromJsonObject);
                        }
                    } catch (Exception e2) {
                        Log.v("INFO", "Item " + i + " of " + jSONArray.length() + " has been skipped due to exception!");
                        Log.printStackTrace(e2);
                    }
                } catch (Exception e3) {
                    e = e3;
                    arrayList = arrayList2;
                    Log.printStackTrace(e);
                    return arrayList;
                }
            }
            return arrayList2;
        } catch (Exception e4) {
            e = e4;
            Log.printStackTrace(e);
            return arrayList;
        }
    }

    public static String getPostCommentsUrl(String str, String str2) {
        return JETPACK_BASE + str + "/posts/" + str2 + "/replies?order=ASC";
    }

    public static PostItem itemFromJsonObject(JSONObject jSONObject) throws JSONException {
        PostItem postItem = new PostItem(PostItem.PostType.JETPACK);
        postItem.setId(Long.valueOf(jSONObject.getLong("ID")));
        postItem.setAuthor(jSONObject.getJSONObject("author").getString("name"));
        try {
            postItem.setDate(JETPACK_DATE_FORMAT.parse(jSONObject.getString("date")));
        } catch (ParseException e) {
            Log.printStackTrace(e);
        }
        postItem.setTitle(Html.fromHtml(jSONObject.getString("title")).toString());
        postItem.setUrl(jSONObject.getString("URL"));
        postItem.setContent(jSONObject.getString(FirebaseAnalytics.Param.CONTENT));
        postItem.setCommentCount(Long.valueOf(jSONObject.getJSONObject("discussion").getLong("comment_count")));
        postItem.setFeaturedImageUrl(jSONObject.getString("featured_image"));
        long j = -1;
        if (!jSONObject.isNull("post_thumbnail")) {
            j = jSONObject.getJSONObject("post_thumbnail").getLong("ID");
            postItem.setThumbnailUrl(jSONObject.getJSONObject("post_thumbnail").getString("URL"));
        }
        if (jSONObject.has("attachments") && jSONObject.getJSONObject("attachments").names() != null) {
            JSONObject jSONObject2 = jSONObject.getJSONObject("attachments");
            for (int i = 0; i < jSONObject2.names().length(); i++) {
                JSONObject jSONObject3 = jSONObject2.getJSONObject(jSONObject2.names().getString(i));
                String str = null;
                String string = (!jSONObject3.has("thumbnails") || !jSONObject3.getJSONObject("thumbnails").has("thumbnail")) ? null : jSONObject3.getJSONObject("thumbnails").getString("thumbnail");
                if (jSONObject3.has("title")) {
                    str = jSONObject3.getString("title");
                }
                postItem.addAttachment(new MediaAttachment(jSONObject3.getString("URL"), jSONObject3.getString("mime_type"), string, str));
                if (jSONObject3.getLong("ID") == j && jSONObject3.has("thumbnails") && jSONObject3.getJSONObject("thumbnails").has(FirebaseAnalytics.Param.MEDIUM)) {
                    postItem.setThumbnailUrl(jSONObject3.getJSONObject("thumbnails").getString(FirebaseAnalytics.Param.MEDIUM));
                }
            }
        }
        JSONObject jSONObject4 = jSONObject.getJSONObject("tags");
        if (!(jSONObject4 == null || jSONObject4.names() == null || jSONObject4.names().length() <= 0)) {
            postItem.setTag(jSONObject4.getJSONObject(jSONObject4.names().getString(0)).getString("slug"));
        }
        postItem.setPostCompleted();
        return postItem;
    }
}

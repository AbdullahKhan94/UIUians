package com.thedaw.uiuians.providers.wordpress.api.providers;

import android.text.Html;
import com.google.android.exoplayer2.text.ttml.TtmlNode;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.thedaw.uiuians.attachmentviewer.model.MediaAttachment;
import com.thedaw.uiuians.providers.wordpress.CategoryItem;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import com.thedaw.uiuians.providers.wordpress.api.JsonApiPostLoader;
import com.thedaw.uiuians.providers.wordpress.api.WordpressGetTaskInfo;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonApiProvider implements WordpressProvider {
    private static final String API_LOC = "/?json=";
    private static final String API_LOC_FRIENDLY = "/api/";
    private static final String PARAMS = "date_format=U&exclude=comments,categories,custom_fields";
    private static final int TIME_CORRECT = 0;
    public static final boolean USE_WP_FRIENDLY = true;

    public static String getApiLoc() {
        return API_LOC_FRIENDLY;
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public String getRecentPosts(WordpressGetTaskInfo wordpressGetTaskInfo) {
        return wordpressGetTaskInfo.baseurl + getApiLoc() + "get_recent_posts" + getParams(PARAMS) + "&count=" + 15 + "&page=";
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public String getTagPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(wordpressGetTaskInfo.baseurl);
        sb.append(getApiLoc());
        sb.append("get_tag_posts");
        sb.append(getParams(PARAMS));
        sb.append("&count=");
        if (wordpressGetTaskInfo.simpleMode.booleanValue()) {
            sb.append(4);
        } else {
            sb.append(15);
        }
        sb.append("&tag_slug=");
        sb.append(str);
        sb.append("&page=");
        return sb.toString();
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public String getCategoryPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        return wordpressGetTaskInfo.baseurl + getApiLoc() + "get_category_posts" + getParams(PARAMS) + "&count=" + 15 + "&category_slug=" + str + "&page=";
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public String getSearchPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        return wordpressGetTaskInfo.baseurl + getApiLoc() + "get_search_results" + getParams(PARAMS) + "&count=" + 15 + "&search=" + str + "&page=";
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x006b A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x006c  */
    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public ArrayList<CategoryItem> getCategories(WordpressGetTaskInfo wordpressGetTaskInfo) {
        ArrayList arrayList;
        JSONException e;
        JSONObject jSONObjectFromUrl = Helper.getJSONObjectFromUrl(wordpressGetTaskInfo.baseurl + getApiLoc() + "GET_CATEGORY_INDEX");
        if (jSONObjectFromUrl == null || !jSONObjectFromUrl.has("categories")) {
            return null;
        }
        try {
            JSONArray jSONArray = jSONObjectFromUrl.getJSONArray("categories");
            arrayList = null;
            for (int i = 0; i < jSONArray.length(); i++) {
                try {
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    JSONObject jSONObject = jSONArray.getJSONObject(i);
                    arrayList.add(new CategoryItem(jSONObject.getString("slug"), jSONObject.getString("title"), jSONObject.getInt("post_count")));
                } catch (JSONException e2) {
                    e = e2;
                    Log.printStackTrace(e);
                    if (arrayList == null) {
                    }
                }
            }
        } catch (JSONException e3) {
            e = e3;
            arrayList = null;
            Log.printStackTrace(e);
            if (arrayList == null) {
            }
        }
        if (arrayList == null) {
            return null;
        }
        Collections.sort(arrayList, new Comparator<CategoryItem>() {
            /* class com.thedaw.uiuians.providers.wordpress.api.providers.JsonApiProvider.AnonymousClass1 */

            public int compare(CategoryItem categoryItem, CategoryItem categoryItem2) {
                return Integer.valueOf(categoryItem2.getPostCount()).compareTo(Integer.valueOf(categoryItem.getPostCount()));
            }
        });
        return new ArrayList<>(arrayList.subList(0, Math.min(arrayList.size(), 15)));
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public ArrayList<PostItem> parsePostsFromUrl(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        Exception e;
        JSONObject jSONObjectFromUrl = Helper.getJSONObjectFromUrl(str);
        ArrayList<PostItem> arrayList = null;
        if (jSONObjectFromUrl == null) {
            return null;
        }
        try {
            wordpressGetTaskInfo.pages = Integer.valueOf(jSONObjectFromUrl.getInt("pages"));
            if (!jSONObjectFromUrl.has("posts")) {
                return null;
            }
            JSONArray jSONArray = jSONObjectFromUrl.getJSONArray("posts");
            ArrayList<PostItem> arrayList2 = new ArrayList<>();
            for (int i = 0; i < jSONArray.length(); i++) {
                try {
                    try {
                        PostItem itemFromJsonObject = itemFromJsonObject(jSONArray.getJSONObject(i));
                        new JsonApiPostLoader(itemFromJsonObject, wordpressGetTaskInfo.baseurl, null).start();
                        if (!itemFromJsonObject.getId().equals(wordpressGetTaskInfo.ignoreId)) {
                            arrayList2.add(itemFromJsonObject);
                        }
                    } catch (Exception e2) {
                        Log.v("INFO", "Item " + i + " of " + jSONArray.length() + " has been skipped due to exception!");
                        Log.printStackTrace(e2);
                    }
                } catch (Exception e3) {
                    e = e3;
                    arrayList = arrayList2;
                    Log.printStackTrace(e);
                    return arrayList;
                }
            }
            return arrayList2;
        } catch (Exception e4) {
            e = e4;
            Log.printStackTrace(e);
            return arrayList;
        }
    }

    public static PostItem itemFromJsonObject(JSONObject jSONObject) throws JSONException {
        PostItem postItem = new PostItem(PostItem.PostType.JSON);
        postItem.setTitle(Html.fromHtml(jSONObject.getString("title")).toString());
        postItem.setDate(new Date((jSONObject.getLong("date") + 0) * 1000));
        postItem.setId(Long.valueOf(jSONObject.getLong(TtmlNode.ATTR_ID)));
        postItem.setUrl(jSONObject.getString("url"));
        postItem.setContent(jSONObject.getString(FirebaseAnalytics.Param.CONTENT));
        if (jSONObject.has("author")) {
            Object obj = jSONObject.get("author");
            if (obj instanceof JSONArray) {
                JSONArray jSONArray = (JSONArray) obj;
                if (jSONArray.length() > 0) {
                    obj = jSONArray.getJSONObject(0);
                }
            }
            if (obj instanceof JSONObject) {
                JSONObject jSONObject2 = (JSONObject) obj;
                if (jSONObject2.has("name")) {
                    postItem.setAuthor(jSONObject2.getString("name"));
                }
            }
        }
        if (jSONObject.has("tags") && jSONObject.getJSONArray("tags").length() > 0) {
            postItem.setTag(((JSONObject) jSONObject.getJSONArray("tags").get(0)).getString("slug"));
        }
        try {
            if (jSONObject.has("thumbnail")) {
                String string = jSONObject.getString("thumbnail");
                if (!string.equals("")) {
                    postItem.setThumbnailUrl(string);
                }
            }
            if (jSONObject.has("attachments")) {
                JSONArray jSONArray2 = jSONObject.getJSONArray("attachments");
                for (int i = 0; i < jSONArray2.length(); i++) {
                    JSONObject jSONObject3 = jSONArray2.getJSONObject(i);
                    String str = null;
                    if (jSONObject3.has("images") && jSONObject3.optJSONObject("images") != null) {
                        if (jSONObject3.getJSONObject("images").has("post-thumbnail")) {
                            str = jSONObject3.getJSONObject("images").getJSONObject("post-thumbnail").getString("url");
                        } else if (jSONObject3.getJSONObject("images").has("thumbnail")) {
                            str = jSONObject3.getJSONObject("images").getJSONObject("thumbnail").getString("url");
                        }
                    }
                    postItem.addAttachment(new MediaAttachment(jSONObject3.getString("url"), jSONObject3.getString("mime_type"), str, jSONObject3.getString("title")));
                }
            }
        } catch (JSONException e) {
            Log.printStackTrace(e);
        }
        return postItem;
    }

    public static String getPostUrl(long j, String str) {
        return str + getApiLoc() + "get_post" + getParams("post_id=") + j;
    }

    public static String getParams(String str) {
        return "?" + str;
    }
}

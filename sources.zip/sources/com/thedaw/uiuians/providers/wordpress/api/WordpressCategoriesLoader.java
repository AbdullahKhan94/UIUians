package com.thedaw.uiuians.providers.wordpress.api;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.wordpress.CategoryItem;
import com.thedaw.uiuians.providers.wordpress.api.WordpressCategoriesTask;
import com.thedaw.uiuians.providers.wordpress.api.WordpressGetTaskInfo;
import com.thedaw.uiuians.providers.wordpress.ui.WordpressFragment;
import com.thedaw.uiuians.util.Helper;
import java.util.ArrayList;
import java.util.Iterator;

public class WordpressCategoriesLoader implements WordpressGetTaskInfo.ListListener {
    private ArrayList<CategoryItem> categoryItems;
    private WordpressGetTaskInfo mInfo;

    public WordpressCategoriesLoader(WordpressGetTaskInfo wordpressGetTaskInfo) {
        this.mInfo = wordpressGetTaskInfo;
    }

    public void load() {
        new WordpressCategoriesTask(this.mInfo, new WordpressCategoriesTask.WordpressCategoriesCallback() {
            /* class com.thedaw.uiuians.providers.wordpress.api.WordpressCategoriesLoader.AnonymousClass1 */

            @Override // com.thedaw.uiuians.providers.wordpress.api.WordpressCategoriesTask.WordpressCategoriesCallback
            public void categoriesFailed() {
            }

            @Override // com.thedaw.uiuians.providers.wordpress.api.WordpressCategoriesTask.WordpressCategoriesCallback
            public void categoriesLoaded(ArrayList<CategoryItem> arrayList) {
                WordpressCategoriesLoader.this.categoryItems = arrayList;
                if (WordpressCategoriesLoader.this.mInfo.adapter == null || WordpressCategoriesLoader.this.mInfo.adapter.getCount() <= 0) {
                    WordpressCategoriesLoader.this.mInfo.setListener(WordpressCategoriesLoader.this);
                } else {
                    WordpressCategoriesLoader.this.createSlider(arrayList);
                }
            }
        }).execute(new String[0]);
    }

    public void createSlider(ArrayList<CategoryItem> arrayList) {
        LayoutInflater from = LayoutInflater.from(this.mInfo.context);
        HorizontalScrollView horizontalScrollView = (HorizontalScrollView) from.inflate(R.layout.listview_slider, (ViewGroup) null);
        Iterator<CategoryItem> it = arrayList.iterator();
        while (it.hasNext()) {
            final CategoryItem next = it.next();
            FrameLayout frameLayout = (FrameLayout) from.inflate(R.layout.listview_slider_chip, (ViewGroup) null);
            TextView textView = (TextView) frameLayout.findViewById(R.id.category_chip);
            textView.setText(next.getName());
            ((TextView) frameLayout.findViewById(R.id.category_chip_number)).setText(Helper.formatValue((double) next.getPostCount()));
            textView.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.wordpress.api.WordpressCategoriesLoader.AnonymousClass2 */

                public void onClick(View view) {
                    HolderActivity.startActivity(WordpressCategoriesLoader.this.mInfo.context, WordpressFragment.class, new String[]{WordpressCategoriesLoader.this.mInfo.baseurl, next.getId()});
                }
            });
            ((LinearLayout) horizontalScrollView.findViewById(R.id.slider_content)).addView(frameLayout);
        }
        this.mInfo.adapter.setSlider(horizontalScrollView);
        horizontalScrollView.setAlpha(0.0f);
        horizontalScrollView.animate().alpha(1.0f).setDuration(500).start();
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.WordpressGetTaskInfo.ListListener
    public void completedWithPosts() {
        createSlider(this.categoryItems);
    }
}

package com.thedaw.uiuians.providers.wordpress.api.providers;

import android.text.Html;
import com.google.android.exoplayer2.text.ttml.TtmlNode;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.onesignal.shortcutbadger.impl.NewHtcHomeBadger;
import com.thedaw.uiuians.providers.soundcloud.helpers.SoundCloudArtworkHelper;
import com.thedaw.uiuians.providers.wordpress.CategoryItem;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import com.thedaw.uiuians.providers.wordpress.api.RestApiPostLoader;
import com.thedaw.uiuians.providers.wordpress.api.WordpressGetTaskInfo;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import io.fabric.sdk.android.services.network.HttpRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RestApiProvider implements WordpressProvider {
    private static final SimpleDateFormat REST_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault());
    private static final String REST_FIELDS = "&_embed=1";

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public String getRecentPosts(WordpressGetTaskInfo wordpressGetTaskInfo) {
        return wordpressGetTaskInfo.baseurl + "posts/?per_page=" + 15 + REST_FIELDS + "&page=";
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public String getTagPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(wordpressGetTaskInfo.baseurl);
        sb.append("posts/?per_page=");
        if (wordpressGetTaskInfo.simpleMode.booleanValue()) {
            sb.append(4);
        } else {
            sb.append(15);
        }
        sb.append(REST_FIELDS);
        sb.append("&tags=");
        sb.append(str);
        sb.append("&page=");
        return sb.toString();
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public String getCategoryPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        return wordpressGetTaskInfo.baseurl + "posts/?per_page=" + 15 + REST_FIELDS + "&categories=" + str + "&page=";
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public String getSearchPosts(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        return wordpressGetTaskInfo.baseurl + "posts/?per_page=" + 15 + REST_FIELDS + "&search=" + str + "&page=";
    }

    public static String getPostCommentsUrl(String str, String str2) {
        return str + "comments/?post=" + str2 + REST_FIELDS + "&orderby=date_gmt&order=asc" + "&per_page=50";
    }

    public static String getPostMediaUrl(String str, String str2) {
        return str + "media?parent=" + str2;
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public ArrayList<CategoryItem> getCategories(WordpressGetTaskInfo wordpressGetTaskInfo) {
        JSONArray jSONArrayFromUrl = Helper.getJSONArrayFromUrl(wordpressGetTaskInfo.baseurl + "categories" + "?orderby=count&order=desc&per_page=15");
        ArrayList<CategoryItem> arrayList = null;
        if (jSONArrayFromUrl == null || jSONArrayFromUrl.length() == 0) {
            return null;
        }
        for (int i = 0; i < jSONArrayFromUrl.length(); i++) {
            try {
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                }
                JSONObject jSONObject = jSONArrayFromUrl.getJSONObject(i);
                arrayList.add(new CategoryItem(jSONObject.getString(TtmlNode.ATTR_ID), jSONObject.getString("name"), jSONObject.getInt(NewHtcHomeBadger.COUNT)));
            } catch (JSONException e) {
                Log.printStackTrace(e);
            }
        }
        return arrayList;
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider
    public ArrayList<PostItem> parsePostsFromUrl(WordpressGetTaskInfo wordpressGetTaskInfo, String str) {
        Exception e;
        ArrayList<PostItem> arrayList = null;
        try {
            JSONArray jSONArrFromUrl = getJSONArrFromUrl(str, wordpressGetTaskInfo);
            if (jSONArrFromUrl == null) {
                return null;
            }
            ArrayList<PostItem> arrayList2 = new ArrayList<>();
            for (int i = 0; i < jSONArrFromUrl.length(); i++) {
                try {
                    try {
                        PostItem itemFromJsonObject = itemFromJsonObject(jSONArrFromUrl.getJSONObject(i));
                        new RestApiPostLoader(itemFromJsonObject, wordpressGetTaskInfo.baseurl, null).start();
                        if (!itemFromJsonObject.getId().equals(wordpressGetTaskInfo.ignoreId)) {
                            arrayList2.add(itemFromJsonObject);
                        }
                    } catch (Exception e2) {
                        Log.v("INFO", "Item " + i + " of " + jSONArrFromUrl.length() + " has been skipped due to exception!");
                        Log.printStackTrace(e2);
                    }
                } catch (Exception e3) {
                    e = e3;
                    arrayList = arrayList2;
                    Log.printStackTrace(e);
                    return arrayList;
                }
            }
            return arrayList2;
        } catch (Exception e4) {
            e = e4;
            Log.printStackTrace(e);
            return arrayList;
        }
    }

    public static PostItem itemFromJsonObject(JSONObject jSONObject) throws JSONException {
        PostItem postItem = new PostItem(PostItem.PostType.REST);
        postItem.setId(Long.valueOf(jSONObject.getLong(TtmlNode.ATTR_ID)));
        postItem.setAuthor(jSONObject.getJSONObject("_embedded").getJSONArray("author").getJSONObject(0).getString("name"));
        try {
            postItem.setDate(REST_DATE_FORMAT.parse(jSONObject.getString("date")));
        } catch (ParseException e) {
            Log.printStackTrace(e);
        }
        postItem.setTitle(Html.fromHtml(jSONObject.getJSONObject("title").getString("rendered")).toString());
        postItem.setUrl(jSONObject.getString("link"));
        postItem.setContent(jSONObject.getJSONObject(FirebaseAnalytics.Param.CONTENT).getString("rendered"));
        if (!jSONObject.getJSONObject("_embedded").has("replies") || jSONObject.getJSONObject("_embedded").getJSONArray("replies") == null) {
            postItem.setCommentCount(0L);
        } else {
            postItem.setCommentCount(Long.valueOf((long) jSONObject.getJSONObject("_embedded").getJSONArray("replies").getJSONArray(0).length()));
        }
        if (jSONObject.getJSONObject("_embedded").has("wp:featuredmedia") && jSONObject.getJSONObject("_embedded").getJSONArray("wp:featuredmedia").length() > 0 && jSONObject.getJSONObject("_embedded").getJSONArray("wp:featuredmedia").getJSONObject(0).getString("media_type").equals("image")) {
            JSONObject jSONObject2 = jSONObject.getJSONObject("_embedded").getJSONArray("wp:featuredmedia").getJSONObject(0).getJSONObject("media_details").getJSONObject("sizes");
            if (jSONObject2.has(SoundCloudArtworkHelper.LARGE)) {
                postItem.setFeaturedImageUrl(jSONObject2.getJSONObject(SoundCloudArtworkHelper.LARGE).getString("source_url"));
            } else {
                postItem.setFeaturedImageUrl(jSONObject2.getJSONObject("full").getString("source_url"));
            }
            postItem.setThumbnailUrl(jSONObject2.getJSONObject(FirebaseAnalytics.Param.MEDIUM).getString("source_url"));
        }
        JSONArray jSONArray = jSONObject.getJSONArray("tags");
        if (jSONArray != null && jSONArray.length() > 0) {
            postItem.setTag(Long.toString(jSONArray.getLong(0)));
        }
        return postItem;
    }

    private JSONArray getJSONArrFromUrl(String str, WordpressGetTaskInfo wordpressGetTaskInfo) {
        Log.v("INFO", "Requesting: " + str);
        StringBuffer stringBuffer = new StringBuffer("");
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection.setRequestProperty("User-Agent", "Universal/2.0 (Android)");
            httpURLConnection.setRequestMethod(HttpRequest.METHOD_GET);
            httpURLConnection.setDoInput(true);
            httpURLConnection.connect();
            int responseCode = httpURLConnection.getResponseCode();
            if (responseCode != 200 && (responseCode == 302 || responseCode == 301 || responseCode == 303)) {
                String headerField = httpURLConnection.getHeaderField(HttpRequest.HEADER_LOCATION);
                String headerField2 = httpURLConnection.getHeaderField("Set-Cookie");
                HttpURLConnection httpURLConnection2 = (HttpURLConnection) new URL(headerField).openConnection();
                httpURLConnection2.setRequestProperty("Cookie", headerField2);
                httpURLConnection2.setRequestProperty("User-Agent", "Universal/2.0 (Android)");
                httpURLConnection2.setRequestMethod(HttpRequest.METHOD_GET);
                httpURLConnection2.setDoInput(true);
                Log.v("INFO", "Redirect to URL: " + headerField);
                httpURLConnection = httpURLConnection2;
            }
            if (httpURLConnection.getResponseCode() == 200) {
                wordpressGetTaskInfo.pages = Integer.valueOf(httpURLConnection.getHeaderFieldInt("X-WP-TotalPages", 1));
            }
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                stringBuffer.append(readLine);
            }
        } catch (IOException e) {
            Log.printStackTrace(e);
        }
        try {
            return new JSONArray(stringBuffer.toString());
        } catch (Exception e2) {
            Log.e("INFO", "Error parsing JSON. Printing stacktrace now");
            Log.printStackTrace(e2);
            return null;
        }
    }
}

package com.thedaw.uiuians.providers.wordpress.api;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.thedaw.uiuians.attachmentviewer.model.MediaAttachment;
import com.thedaw.uiuians.providers.soundcloud.helpers.SoundCloudArtworkHelper;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import com.thedaw.uiuians.providers.wordpress.api.JsonApiPostLoader;
import com.thedaw.uiuians.providers.wordpress.api.providers.RestApiProvider;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

public final class RestApiPostLoader extends Thread {
    private String apiBase;
    private PostItem item;
    private JsonApiPostLoader.BackgroundPostCompleterListener listener;

    public RestApiPostLoader(PostItem postItem, String str, JsonApiPostLoader.BackgroundPostCompleterListener backgroundPostCompleterListener) {
        this.item = postItem;
        this.apiBase = str;
        this.listener = backgroundPostCompleterListener;
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x009f A[Catch:{ Exception -> 0x00d8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00be A[SYNTHETIC] */
    public void run() {
        String str;
        String str2;
        JSONArray jSONArrayFromUrl = Helper.getJSONArrayFromUrl(RestApiProvider.getPostMediaUrl(this.apiBase, "" + this.item.getId()));
        if (jSONArrayFromUrl != null) {
            for (int i = 0; i < jSONArrayFromUrl.length(); i++) {
                try {
                    JSONObject jSONObject = jSONArrayFromUrl.getJSONObject(i);
                    String string = jSONObject.getString("mime_type");
                    if (string.startsWith(MediaAttachment.MIME_PATTERN_IMAGE)) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("media_details").getJSONObject("sizes");
                        if (jSONObject2.has(SoundCloudArtworkHelper.LARGE)) {
                            str = jSONObject2.getJSONObject(SoundCloudArtworkHelper.LARGE).getString("source_url");
                        } else {
                            str = jSONObject.getString("source_url");
                        }
                        if (jSONObject2.has(FirebaseAnalytics.Param.MEDIUM)) {
                            str2 = jSONObject2.getJSONObject(FirebaseAnalytics.Param.MEDIUM).getString("source_url");
                            MediaAttachment mediaAttachment = new MediaAttachment(str, jSONObject.getString("mime_type"), str2, jSONObject.getJSONObject("title").getString("rendered"));
                            if (!string.startsWith(MediaAttachment.MIME_PATTERN_AUDIO)) {
                                JSONObject jSONObject3 = jSONObject.getJSONObject("media_details");
                                mediaAttachment.setAudioMeta(jSONObject3.getString("artist"), jSONObject3.getString("album"), jSONObject3.getLong("length") * 1000);
                            }
                            this.item.addAttachment(mediaAttachment);
                        }
                    } else {
                        str = jSONObject.getString("source_url");
                    }
                    str2 = null;
                    MediaAttachment mediaAttachment2 = new MediaAttachment(str, jSONObject.getString("mime_type"), str2, jSONObject.getJSONObject("title").getString("rendered"));
                    if (!string.startsWith(MediaAttachment.MIME_PATTERN_AUDIO)) {
                    }
                    this.item.addAttachment(mediaAttachment2);
                } catch (Exception e) {
                    Log.printStackTrace(e);
                    if (this.listener != null) {
                        this.listener.completed(null);
                        return;
                    }
                    return;
                }
            }
            this.item.setPostCompleted();
            if (this.listener != null) {
                this.listener.completed(this.item);
            }
        }
    }
}

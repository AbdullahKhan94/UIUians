package com.thedaw.uiuians.providers.wordpress.api;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import com.thedaw.uiuians.providers.wordpress.WordpressListAdapter;
import com.thedaw.uiuians.providers.wordpress.api.providers.JetPackProvider;
import com.thedaw.uiuians.providers.wordpress.api.providers.JsonApiProvider;
import com.thedaw.uiuians.providers.wordpress.api.providers.RestApiProvider;
import com.thedaw.uiuians.providers.wordpress.api.providers.WordpressProvider;
import java.util.ArrayList;

public class WordpressGetTaskInfo {
    public WordpressListAdapter adapter = null;
    public String baseurl;
    public Activity context;
    public Integer curpage = 0;
    public Long ignoreId = 0L;
    public boolean isLoading;
    public RecyclerView listView = null;
    private ListListener listener;
    public Integer pages;
    public ArrayList<PostItem> posts;
    public WordpressProvider provider = null;
    public Boolean simpleMode;

    public interface ListListener {
        void completedWithPosts();
    }

    public WordpressGetTaskInfo(RecyclerView recyclerView, Activity activity, String str, Boolean bool) {
        this.listView = recyclerView;
        this.posts = new ArrayList<>();
        this.context = activity;
        this.baseurl = str;
        this.simpleMode = bool;
        if (!str.startsWith("http")) {
            this.provider = new JetPackProvider();
        } else if (str.contains("wp-json/wp/v2/")) {
            this.provider = new RestApiProvider();
        } else {
            this.provider = new JsonApiProvider();
        }
    }

    public void setListener(ListListener listListener) {
        this.listener = listListener;
    }

    public void completedWithPosts() {
        if (this.listener != null) {
            this.listener.completedWithPosts();
        }
    }
}

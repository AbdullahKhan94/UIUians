package com.thedaw.uiuians.providers.wordpress;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import com.thedaw.uiuians.providers.wordpress.ui.WordpressFragment;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import com.thedaw.uiuians.util.ViewModeUtils;
import java.util.ArrayList;

public class WordpressListAdapter extends InfiniteRecyclerViewAdapter {
    private static final int HEADER_IMAGE = 2;
    private static final int HEADER_TEXT = 3;
    private static final int POST = 1;
    private static final int POST_COMPACT = 0;
    private static final int SLIDER = 4;
    private ArrayList<PostItem> listData;
    private AdapterView.OnItemClickListener listener;
    private Context mContext;
    private int number;
    private boolean simpleMode;
    private View sliderView;
    private ViewModeUtils viewModeUtils;

    @Override // android.support.v7.widget.RecyclerView.Adapter
    public long getItemId(int i) {
        return (long) i;
    }

    public WordpressListAdapter(Context context, ArrayList<PostItem> arrayList, InfiniteRecyclerViewAdapter.LoadMoreListener loadMoreListener, AdapterView.OnItemClickListener onItemClickListener, boolean z) {
        super(context, loadMoreListener);
        this.mContext = context;
        this.listener = onItemClickListener;
        this.simpleMode = z;
        this.listData = arrayList;
        this.viewModeUtils = new ViewModeUtils(context, WordpressFragment.class);
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getCount() {
        return this.listData.size();
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getViewType(int i) {
        if (this.simpleMode) {
            return 0;
        }
        PostItem postItem = this.listData.get(i);
        if (postItem.getPostType() == PostItem.PostType.SLIDER) {
            return 4;
        }
        if (i == 0 || this.viewModeUtils.getViewMode() == 2) {
            return headerType(postItem);
        }
        if (this.viewModeUtils.getViewMode() == 1) {
            return 1;
        }
        return 0;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public RecyclerView.ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        switch (i) {
            case 0:
                return new ItemViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_wordpress_list_row, viewGroup, false));
            case 1:
                return new ItemViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listview_row, viewGroup, false));
            case 2:
                HeaderImageViewHolder headerImageViewHolder = new HeaderImageViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listview_highlight, viewGroup, false));
                requestFullSpan(headerImageViewHolder);
                return headerImageViewHolder;
            case 3:
                HeaderTextViewHolder headerTextViewHolder = new HeaderTextViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listview_highlight_text, viewGroup, false));
                requestFullSpan(headerTextViewHolder);
                return headerTextViewHolder;
            case 4:
                SliderViewHolder sliderViewHolder = new SliderViewHolder(this.sliderView);
                requestFullSpan(sliderViewHolder);
                return sliderViewHolder;
            default:
                return null;
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public void doBindViewHolder(final RecyclerView.ViewHolder viewHolder, final int i) {
        PostItem postItem = this.listData.get(i);
        if (viewHolder instanceof HeaderImageViewHolder) {
            HeaderImageViewHolder headerImageViewHolder = (HeaderImageViewHolder) viewHolder;
            headerImageViewHolder.imageView.setImageBitmap(null);
            Picasso.get().load(postItem.getImageCandidate()).placeholder(R.drawable.placeholder).fit().centerCrop().into(headerImageViewHolder.imageView);
            headerImageViewHolder.headlineView.setText(postItem.getTitle());
            headerImageViewHolder.dateView.setText(DateUtils.getRelativeDateTimeString(this.mContext, postItem.getDate().getTime(), 1000, 604800000, 524288));
        } else if (viewHolder instanceof HeaderTextViewHolder) {
            HeaderTextViewHolder headerTextViewHolder = (HeaderTextViewHolder) viewHolder;
            headerTextViewHolder.itemView.findViewById(R.id.background).setBackgroundResource(randomGradientResource());
            headerTextViewHolder.headlineView.setText(postItem.getTitle());
            headerTextViewHolder.dateView.setText(DateUtils.getRelativeDateTimeString(this.mContext, postItem.getDate().getTime(), 1000, 604800000, 524288));
        } else if (!(viewHolder instanceof SliderViewHolder) && (viewHolder instanceof ItemViewHolder)) {
            ItemViewHolder itemViewHolder = (ItemViewHolder) viewHolder;
            itemViewHolder.imageView.setImageBitmap(null);
            itemViewHolder.headlineView.setText(postItem.getTitle());
            if (postItem.getDate() != null) {
                itemViewHolder.reportedDateView.setVisibility(0);
                itemViewHolder.reportedDateView.setText(DateUtils.getRelativeDateTimeString(this.mContext, postItem.getDate().getTime(), 1000, 604800000, 524288));
            } else {
                itemViewHolder.reportedDateView.setVisibility(8);
            }
            itemViewHolder.imageView.setVisibility(8);
            boolean z = true;
            if (this.viewModeUtils.getViewMode() != 1) {
                z = false;
            }
            String imageCandidate = z ? postItem.getImageCandidate() : postItem.getThumbnailCandidate();
            if (imageCandidate != null && !imageCandidate.equals("")) {
                itemViewHolder.imageView.setVisibility(0);
                Picasso.get().load(imageCandidate).fit().centerInside().into(itemViewHolder.imageView);
            }
        }
        if (!(viewHolder instanceof SliderViewHolder)) {
            viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.wordpress.WordpressListAdapter.AnonymousClass1 */

                public void onClick(View view) {
                    WordpressListAdapter.this.listener.onItemClick(null, viewHolder.itemView, i, 0);
                }
            });
        }
    }

    private int headerType(PostItem postItem) {
        return (postItem.getImageCandidate() == null || postItem.getImageCandidate().equals("")) ? 3 : 2;
    }

    private int randomGradientResource() {
        this.number++;
        if (this.number == 6) {
            this.number = 1;
        }
        return Helper.getGradient(this.number);
    }

    public void setSlider(View view) {
        if (this.sliderView == null && this.viewModeUtils.getViewMode() != 2 && this.listData.size() > 0) {
            this.listData.add(1, new PostItem(PostItem.PostType.SLIDER));
        }
        this.sliderView = view;
        notifyDataSetChanged();
    }

    public void removeSlider() {
        if (this.sliderView != null && this.listData.size() > 0 && this.listData.get(1).getPostType() == PostItem.PostType.SLIDER) {
            this.listData.remove(1);
            this.sliderView = null;
        }
    }

    private static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView headlineView;
        ImageView imageView;
        TextView reportedDateView;

        ItemViewHolder(View view) {
            super(view);
            this.headlineView = (TextView) view.findViewById(R.id.title);
            this.reportedDateView = (TextView) view.findViewById(R.id.date);
            this.imageView = (ImageView) view.findViewById(R.id.thumbImage);
        }
    }

    private static class SliderViewHolder extends RecyclerView.ViewHolder {
        SliderViewHolder(View view) {
            super(view);
        }
    }

    private static class HeaderImageViewHolder extends HeaderViewHolder {
        HeaderImageViewHolder(View view) {
            super(view);
        }
    }

    private static class HeaderTextViewHolder extends HeaderViewHolder {
        HeaderTextViewHolder(View view) {
            super(view);
        }
    }

    private static abstract class HeaderViewHolder extends RecyclerView.ViewHolder {
        TextView dateView;
        TextView headlineView;
        ImageView imageView;

        HeaderViewHolder(View view) {
            super(view);
            this.dateView = (TextView) view.findViewById(R.id.textViewDate);
            this.headlineView = (TextView) view.findViewById(R.id.textViewHighlight);
            this.imageView = (ImageView) view.findViewById(R.id.imageViewHighlight);
        }
    }
}

package com.thedaw.uiuians.providers.wordpress;

import com.thedaw.uiuians.attachmentviewer.model.MediaAttachment;
import com.thedaw.uiuians.util.SerializableJSONArray;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import org.json.JSONArray;

public class PostItem implements Serializable {
    private static final long serialVersionUID = 1;
    private ArrayList<MediaAttachment> attachments;
    private String author;
    private Long commentCount;
    private SerializableJSONArray commentsArray;
    private String content;
    private Date date;
    private String featuredImageUrl;
    private Long id;
    private boolean isCompleted = false;
    private String tag;
    private String thumbnailUrl;
    private String title;
    private PostType type;
    private String url;

    public enum PostType {
        JETPACK,
        JSON,
        REST,
        SLIDER
    }

    public PostItem(PostType postType) {
        this.type = postType;
        this.attachments = new ArrayList<>();
    }

    public String getImageCandidate() {
        if (getFeaturedImageUrl() != null && !getFeaturedImageUrl().equals("")) {
            return getFeaturedImageUrl();
        }
        if (getAttachments().size() > 0 && getAttachments().get(0).getMime().startsWith(MediaAttachment.MIME_PATTERN_IMAGE)) {
            return getAttachments().get(0).getUrl();
        }
        if (getAttachments().size() > 0 && getAttachments().get(0).getThumbnailUrl() != null) {
            return getAttachments().get(0).getThumbnailUrl();
        }
        if (getThumbnailUrl() == null || getThumbnailUrl().equals("") || getThumbnailUrl().equals("(null)")) {
            return null;
        }
        return getThumbnailUrl();
    }

    public String getThumbnailCandidate() {
        if (getThumbnailUrl() != null && !getThumbnailUrl().equals("") && !getThumbnailUrl().equals("(null)")) {
            return getThumbnailUrl();
        }
        if (getFeaturedImageUrl() != null && !getFeaturedImageUrl().equals("")) {
            return getFeaturedImageUrl();
        }
        if (getAttachments().size() > 0 && getAttachments().get(0).getThumbnailUrl() != null) {
            return getAttachments().get(0).getThumbnailUrl();
        }
        if (getAttachments().size() <= 0 || !getAttachments().get(0).getMime().startsWith(MediaAttachment.MIME_PATTERN_IMAGE)) {
            return null;
        }
        return getAttachments().get(0).getUrl();
    }

    public String getUrl() {
        return this.url;
    }

    public void setUrl(String str) {
        this.url = str;
    }

    public String getContent() {
        return this.content;
    }

    public void setContent(String str) {
        this.content = str;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long l) {
        this.id = l;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getAuthor() {
        return this.author;
    }

    public void setAuthor(String str) {
        this.author = str;
    }

    public Date getDate() {
        return this.date;
    }

    public void setDate(Date date2) {
        this.date = date2;
    }

    public String getTag() {
        return this.tag;
    }

    public void setTag(String str) {
        this.tag = str;
    }

    public ArrayList<MediaAttachment> getAttachments() {
        return this.attachments;
    }

    public void addAttachment(MediaAttachment mediaAttachment) {
        this.attachments.add(mediaAttachment);
    }

    public String getThumbnailUrl() {
        return this.thumbnailUrl;
    }

    public void setThumbnailUrl(String str) {
        this.thumbnailUrl = str;
    }

    public String getFeaturedImageUrl() {
        return this.featuredImageUrl;
    }

    public void setFeaturedImageUrl(String str) {
        this.featuredImageUrl = str;
    }

    public JSONArray getCommentsArray() {
        if (this.commentsArray != null) {
            return this.commentsArray.getJSONArray();
        }
        return null;
    }

    public void setCommentsArray(JSONArray jSONArray) {
        this.commentsArray = new SerializableJSONArray(jSONArray);
    }

    public Long getCommentCount() {
        if (this.commentCount == null) {
            return 0L;
        }
        return this.commentCount;
    }

    public void setCommentCount(Long l) {
        this.commentCount = l;
    }

    public void setPostCompleted() {
        this.isCompleted = true;
    }

    public boolean isCompleted() {
        return this.isCompleted;
    }

    public PostType getPostType() {
        return this.type;
    }
}

package com.thedaw.uiuians.providers.wordpress.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import com.thedaw.uiuians.providers.wordpress.WordpressListAdapter;
import com.thedaw.uiuians.providers.wordpress.api.WordpressCategoriesLoader;
import com.thedaw.uiuians.providers.wordpress.api.WordpressGetTaskInfo;
import com.thedaw.uiuians.providers.wordpress.api.WordpressPostsLoader;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import com.thedaw.uiuians.util.Log;
import com.thedaw.uiuians.util.ThemeUtils;
import com.thedaw.uiuians.util.ViewModeUtils;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class WordpressFragment extends Fragment implements InfiniteRecyclerViewAdapter.LoadMoreListener {
    private String[] arguments;
    private RelativeLayout ll;
    private Activity mAct;
    private WordpressGetTaskInfo mInfo;
    private RecyclerView postList = null;
    private SwipeRefreshLayout swipeRefreshLayout;
    private String urlSession;
    ViewModeUtils viewModeUtils;

    @Override // android.support.v4.app.Fragment
    @SuppressLint({"InflateParams"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreate(bundle);
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list_refresh, viewGroup, false);
        setHasOptionsMenu(true);
        this.arguments = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        AnonymousClass1 r4 = new AdapterView.OnItemClickListener() {
            /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressFragment.AnonymousClass1 */

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                PostItem postItem = WordpressFragment.this.mInfo.posts.get(i);
                if (!postItem.getPostType().equals(PostItem.PostType.SLIDER)) {
                    Intent intent = new Intent(WordpressFragment.this.mAct, WordpressDetailActivity.class);
                    intent.putExtra("postitem", postItem);
                    intent.putExtra(WordpressDetailActivity.EXTRA_API_BASE, WordpressFragment.this.arguments[0]);
                    if (WordpressFragment.this.arguments.length > 2) {
                        intent.putExtra(WordpressDetailActivity.EXTRA_DISQUS, WordpressFragment.this.arguments[2]);
                    }
                    WordpressFragment.this.startActivity(intent);
                }
            }
        };
        this.postList = (RecyclerView) this.ll.findViewById(R.id.list);
        this.swipeRefreshLayout = (SwipeRefreshLayout) this.ll.findViewById(R.id.swipeRefreshLayout);
        this.mInfo = new WordpressGetTaskInfo(this.postList, getActivity(), this.arguments[0], false);
        this.mInfo.adapter = new WordpressListAdapter(getContext(), this.mInfo.posts, this, r4, this.mInfo.simpleMode.booleanValue());
        this.postList.setAdapter(this.mInfo.adapter);
        this.postList.setLayoutManager(new LinearLayoutManager(this.ll.getContext(), 1, false));
        this.swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressFragment.AnonymousClass2 */

            @Override // android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener
            public void onRefresh() {
                if (!WordpressFragment.this.mInfo.isLoading) {
                    WordpressFragment.this.getPosts();
                } else {
                    Toast.makeText(WordpressFragment.this.mAct, WordpressFragment.this.getString(R.string.already_loading), 1).show();
                }
                WordpressFragment.this.swipeRefreshLayout.setRefreshing(false);
            }
        });
        return this.ll;
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        getPosts();
    }

    public void getPosts() {
        if (this.arguments.length <= 1 || this.arguments[1].equals("")) {
            this.urlSession = WordpressPostsLoader.getRecentPosts(this.mInfo);
            new WordpressCategoriesLoader(this.mInfo).load();
            return;
        }
        this.urlSession = WordpressPostsLoader.getCategoryPosts(this.mInfo, this.arguments[1]);
    }

    @Override // android.support.v4.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        this.viewModeUtils = new ViewModeUtils(getContext(), getClass());
        this.viewModeUtils.inflateOptionsMenu(menu, menuInflater);
        menuInflater.inflate(R.menu.menu_search, menu);
        final SearchView searchView = new SearchView(this.mAct);
        searchView.setQueryHint(getResources().getString(R.string.search_hint));
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressFragment.AnonymousClass3 */

            @Override // android.support.v7.widget.SearchView.OnQueryTextListener
            public boolean onQueryTextChange(String str) {
                return false;
            }

            @Override // android.support.v7.widget.SearchView.OnQueryTextListener
            public boolean onQueryTextSubmit(String str) {
                try {
                    str = URLEncoder.encode(str, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    Log.printStackTrace(e);
                }
                searchView.clearFocus();
                WordpressFragment.this.urlSession = WordpressPostsLoader.getSearchPosts(WordpressFragment.this.mInfo, str);
                return true;
            }
        });
        searchView.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressFragment.AnonymousClass4 */

            public void onViewAttachedToWindow(View view) {
            }

            public void onViewDetachedFromWindow(View view) {
                if (!WordpressFragment.this.mInfo.isLoading) {
                    WordpressFragment.this.getPosts();
                }
            }
        });
        menu.findItem(R.id.menu_search).setActionView(searchView);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        this.viewModeUtils.handleSelection(menuItem, new ViewModeUtils.ChangeListener() {
            /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressFragment.AnonymousClass5 */

            @Override // com.thedaw.uiuians.util.ViewModeUtils.ChangeListener
            public void modeChanged() {
                if (WordpressFragment.this.viewModeUtils.getViewMode() == 2) {
                    WordpressFragment.this.mInfo.adapter.removeSlider();
                }
                WordpressFragment.this.mInfo.adapter.notifyDataSetChanged();
            }
        });
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter.LoadMoreListener
    public void onMoreRequested() {
        if (!this.mInfo.isLoading && this.mInfo.curpage.intValue() < this.mInfo.pages.intValue()) {
            WordpressPostsLoader.loadMorePosts(this.mInfo, this.urlSession);
        }
    }
}

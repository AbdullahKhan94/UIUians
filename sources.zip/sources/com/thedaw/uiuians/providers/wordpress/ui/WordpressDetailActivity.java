package com.thedaw.uiuians.providers.wordpress.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.format.DateUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewStub;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.attachmentviewer.model.MediaAttachment;
import com.thedaw.uiuians.attachmentviewer.ui.AttachmentActivity;
import com.thedaw.uiuians.comments.CommentsActivity;
import com.thedaw.uiuians.providers.fav.FavDbAdapter;
import com.thedaw.uiuians.providers.wordpress.PostItem;
import com.thedaw.uiuians.providers.wordpress.WordpressListAdapter;
import com.thedaw.uiuians.providers.wordpress.api.JsonApiPostLoader;
import com.thedaw.uiuians.providers.wordpress.api.RestApiPostLoader;
import com.thedaw.uiuians.providers.wordpress.api.WordpressGetTaskInfo;
import com.thedaw.uiuians.providers.wordpress.api.WordpressPostsLoader;
import com.thedaw.uiuians.providers.wordpress.api.providers.JetPackProvider;
import com.thedaw.uiuians.providers.wordpress.api.providers.RestApiProvider;
import com.thedaw.uiuians.util.DetailActivity;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.WebHelper;
import java.util.ArrayList;
import java.util.Iterator;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class WordpressDetailActivity extends DetailActivity implements JsonApiPostLoader.BackgroundPostCompleterListener {
    public static final String EXTRA_API_BASE = "apiurl";
    public static final String EXTRA_DISQUS = "disqus";
    public static final String EXTRA_POSTITEM = "postitem";
    public static final boolean PRELOAD_POSTS = true;
    private static final boolean REMOVE_FIRST_IMG = true;
    private String apiBase;
    private String disqusParseable;
    private WebView htmlTextView;
    private FavDbAdapter mDbHelper;
    private TextView mTitle;
    private PostItem post;

    @Override // android.support.v4.app.SupportActivity, com.thedaw.uiuians.util.DetailActivity, android.support.v7.app.AppCompatActivity, android.support.v4.app.FragmentActivity
    public void onCreate(Bundle bundle) {
        String str;
        super.onCreate(bundle);
        setContentView(R.layout.activity_details);
        ViewStub viewStub = (ViewStub) findViewById(R.id.layout_stub);
        viewStub.setLayoutResource(R.layout.activity_wordpress_details);
        viewStub.inflate();
        this.mToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(this.mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.thumb = (ImageView) findViewById(R.id.image);
        this.coolblue = (RelativeLayout) findViewById(R.id.coolblue);
        this.mTitle = (TextView) findViewById(R.id.title);
        TextView textView = (TextView) findViewById(R.id.dateauthorview);
        Bundle extras = getIntent().getExtras();
        this.post = (PostItem) getIntent().getSerializableExtra("postitem");
        this.disqusParseable = getIntent().getStringExtra(EXTRA_DISQUS);
        this.apiBase = getIntent().getStringExtra(EXTRA_API_BASE);
        if (this.post != null && extras != null) {
            if (this.post.getDate() != null) {
                str = getResources().getString(R.string.wordpress_subtitle_start) + ((Object) DateUtils.getRelativeDateTimeString(this, this.post.getDate().getTime(), 1000, 604800000, 524288)) + getResources().getString(R.string.wordpress_subtitle_end) + this.post.getAuthor();
            } else {
                str = this.post.getAuthor();
            }
            this.mTitle.setText(this.post.getTitle());
            textView.setText(str);
            loadHeaderImage();
            configureFAB();
            setUpHeader(this.post.getImageCandidate());
            Helper.admobLoader(this, findViewById(R.id.adView));
            configureContentWebView();
            if (this.post.getPostType() == PostItem.PostType.JSON && !this.post.isCompleted()) {
                new JsonApiPostLoader(this.post, getIntent().getStringExtra(EXTRA_API_BASE), this).start();
            } else if (this.post.getPostType() != PostItem.PostType.REST || this.post.isCompleted()) {
                loadPostBody(this.post);
            } else {
                new RestApiPostLoader(this.post, getIntent().getStringExtra(EXTRA_API_BASE), this).start();
                loadPostBody(this.post);
            }
            configureFavoritesButton();
            loadRelatedPosts();
        }
    }

    private void configureContentWebView() {
        this.htmlTextView = (WebView) findViewById(R.id.htmlTextView);
        this.htmlTextView.getSettings().setJavaScriptEnabled(true);
        this.htmlTextView.setBackgroundColor(0);
        this.htmlTextView.getSettings().setDefaultFontSize(WebHelper.getWebViewFontSize(this));
        this.htmlTextView.getSettings().setCacheMode(2);
        this.htmlTextView.setWebViewClient(new WebViewClient() {
            /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressDetailActivity.AnonymousClass1 */

            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                if (str == null || (!str.endsWith(".png") && !str.endsWith(".jpg") && !str.endsWith(".jpeg"))) {
                    boolean z = false;
                    if (str == null || (!str.startsWith("http://") && !str.startsWith("https://"))) {
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
                        if (WordpressDetailActivity.this.getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
                            z = true;
                        }
                        if (z) {
                            WordpressDetailActivity.this.startActivity(intent);
                        }
                        return true;
                    }
                    HolderActivity.startWebViewActivity(WordpressDetailActivity.this, str, false, false, null);
                    return true;
                }
                AttachmentActivity.startActivity(WordpressDetailActivity.this, MediaAttachment.withImage(str));
                return true;
            }
        });
    }

    private void configureFAB() {
        String imageCandidate = this.post.getImageCandidate();
        if (imageCandidate != null && !imageCandidate.equals("")) {
            imageCandidate.equals("null");
        }
        if (this.post.getAttachments() != null) {
            this.post.getAttachments().size();
        }
    }

    private void loadHeaderImage() {
        String imageCandidate = this.post.getImageCandidate();
        if (imageCandidate != null && !imageCandidate.equals("") && !imageCandidate.equals("null")) {
            Picasso.get().load(imageCandidate).fit().centerCrop().into(this.thumb);
            this.thumb.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressDetailActivity.AnonymousClass3 */

                public void onClick(View view) {
                    if (WordpressDetailActivity.this.post.getAttachments() != null) {
                        String imageCandidate = WordpressDetailActivity.this.post.getImageCandidate();
                        ArrayList arrayList = new ArrayList();
                        Iterator<MediaAttachment> it = WordpressDetailActivity.this.post.getAttachments().iterator();
                        boolean z = false;
                        while (it.hasNext()) {
                            MediaAttachment next = it.next();
                            if (imageCandidate.equals(next.getUrl()) || imageCandidate.equals(next.getThumbnailUrl())) {
                                arrayList.add(0, next);
                                z = true;
                            } else {
                                arrayList.add(next);
                            }
                        }
                        if (!z) {
                            arrayList.add(0, MediaAttachment.withImage(imageCandidate));
                        }
                        AttachmentActivity.startActivity(WordpressDetailActivity.this, arrayList);
                    }
                }
            });
            findViewById(R.id.scroller).setOnTouchListener(new View.OnTouchListener() {
                /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressDetailActivity.AnonymousClass4 */

                @SuppressLint({"ClickableViewAccessibility"})
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    return WordpressDetailActivity.this.findViewById(R.id.progressBar).getVisibility() == 0 && Build.VERSION.SDK_INT <= 16;
                }
            });
        }
    }

    private void configureFavoritesButton() {
        ((Button) findViewById(R.id.favorite)).setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressDetailActivity.AnonymousClass5 */

            public void onClick(View view) {
                WordpressDetailActivity.this.mDbHelper = new FavDbAdapter(WordpressDetailActivity.this);
                WordpressDetailActivity.this.mDbHelper.open();
                if (WordpressDetailActivity.this.mDbHelper.checkEvent(WordpressDetailActivity.this.post.getTitle(), WordpressDetailActivity.this.post, 1)) {
                    WordpressDetailActivity.this.mDbHelper.addFavorite(WordpressDetailActivity.this.post.getTitle(), WordpressDetailActivity.this.post, 1);
                    Toast.makeText(WordpressDetailActivity.this, WordpressDetailActivity.this.getResources().getString(R.string.favorite_success), 1).show();
                    return;
                }
                Toast.makeText(WordpressDetailActivity.this, WordpressDetailActivity.this.getResources().getString(R.string.favorite_duplicate), 1).show();
            }
        });
    }

    private void loadRelatedPosts() {
        if (this.post.getTag() != null && getIntent().getStringExtra(EXTRA_API_BASE) != null) {
            RecyclerView recyclerView = (RecyclerView) findViewById(R.id.related_list);
            final WordpressGetTaskInfo wordpressGetTaskInfo = new WordpressGetTaskInfo(recyclerView, this, getIntent().getStringExtra(EXTRA_API_BASE), true);
            wordpressGetTaskInfo.ignoreId = this.post.getId();
            wordpressGetTaskInfo.setListener(new WordpressGetTaskInfo.ListListener() {
                /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressDetailActivity.AnonymousClass6 */

                @Override // com.thedaw.uiuians.providers.wordpress.api.WordpressGetTaskInfo.ListListener
                public void completedWithPosts() {
                    WordpressDetailActivity.this.findViewById(R.id.related).setVisibility(0);
                }
            });
            wordpressGetTaskInfo.adapter = new WordpressListAdapter(this, wordpressGetTaskInfo.posts, null, new AdapterView.OnItemClickListener() {
                /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressDetailActivity.AnonymousClass7 */

                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                    Intent intent = new Intent(WordpressDetailActivity.this, WordpressDetailActivity.class);
                    intent.putExtra("postitem", wordpressGetTaskInfo.posts.get(i));
                    intent.putExtra(WordpressDetailActivity.EXTRA_API_BASE, WordpressDetailActivity.this.getIntent().getStringExtra(WordpressDetailActivity.EXTRA_API_BASE));
                    if (WordpressDetailActivity.this.disqusParseable != null) {
                        intent.putExtra(WordpressDetailActivity.EXTRA_DISQUS, WordpressDetailActivity.this.disqusParseable);
                    }
                    WordpressDetailActivity.this.startActivity(intent);
                    WordpressDetailActivity.this.finish();
                }
            }, wordpressGetTaskInfo.simpleMode.booleanValue());
            recyclerView.setAdapter(wordpressGetTaskInfo.adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, 1, false));
            WordpressPostsLoader.getTagPosts(wordpressGetTaskInfo, this.post.getTag());
        }
    }

    @Override // com.thedaw.uiuians.util.DetailActivity, android.support.v4.app.FragmentActivity
    public void onPause() {
        super.onPause();
        this.htmlTextView.onPause();
    }

    @Override // com.thedaw.uiuians.util.DetailActivity, android.support.v4.app.FragmentActivity
    public void onResume() {
        super.onResume();
        if (this.htmlTextView != null) {
            this.htmlTextView.onResume();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.wordpress_detail_menu, menu);
        onMenuItemsSet(menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId != 16908332) {
            switch (itemId) {
                case R.id.menu_share:
                    shareContent();
                    return true;
                case R.id.menu_view:
                    HolderActivity.startWebViewActivity(this, this.post.getUrl(), false, false, null);
                    return true;
                default:
                    return super.onOptionsItemSelected(menuItem);
            }
        } else {
            finish();
            return true;
        }
    }

    private void shareContent() {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.TEXT", this.post.getTitle() + "\n" + this.post.getUrl());
        intent.setType("text/plain");
        startActivity(Intent.createChooser(intent, getString(R.string.share_header)));
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void loadPostBody(final PostItem postItem) {
        if (postItem != null) {
            setHTML(postItem.getContent());
            if ((postItem.getCommentCount() != null && postItem.getCommentCount().longValue() != 0 && postItem.getCommentsArray() != null) || this.disqusParseable != null || ((this.post.getPostType() == PostItem.PostType.JETPACK || this.post.getPostType() == PostItem.PostType.REST) && postItem.getCommentCount().longValue() != 0)) {
                Button button = (Button) findViewById(R.id.comments);
                if (postItem.getCommentCount().longValue() == 0 || (postItem.getCommentCount().longValue() == 10 && this.post.getPostType() == PostItem.PostType.REST)) {
                    button.setText(getResources().getString(R.string.comments));
                } else {
                    button.setText(Helper.formatValue((double) postItem.getCommentCount().longValue()) + " " + getResources().getString(R.string.comments));
                }
                button.setOnClickListener(new View.OnClickListener() {
                    /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressDetailActivity.AnonymousClass8 */

                    public void onClick(View view) {
                        Intent intent = new Intent(WordpressDetailActivity.this, CommentsActivity.class);
                        if (WordpressDetailActivity.this.disqusParseable != null) {
                            intent.putExtra(CommentsActivity.DATA_PARSEABLE, WordpressDetailActivity.this.disqusParseable);
                            intent.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.DISQUS);
                            intent.putExtra(CommentsActivity.DATA_ID, WordpressDetailActivity.this.post.getId().toString());
                        } else if (WordpressDetailActivity.this.post.getPostType() == PostItem.PostType.JETPACK) {
                            intent.putExtra(CommentsActivity.DATA_PARSEABLE, JetPackProvider.getPostCommentsUrl(WordpressDetailActivity.this.apiBase, WordpressDetailActivity.this.post.getId().toString()));
                            intent.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.WORDPRESS_JETPACK);
                        } else if (WordpressDetailActivity.this.post.getPostType() == PostItem.PostType.REST) {
                            intent.putExtra(CommentsActivity.DATA_PARSEABLE, RestApiProvider.getPostCommentsUrl(WordpressDetailActivity.this.apiBase, WordpressDetailActivity.this.post.getId().toString()));
                            intent.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.WORDPRESS_REST);
                        } else if (WordpressDetailActivity.this.post.getPostType() == PostItem.PostType.JSON) {
                            intent.putExtra(CommentsActivity.DATA_PARSEABLE, postItem.getCommentsArray().toString());
                            intent.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.WORDPRESS_JSON);
                        }
                        WordpressDetailActivity.this.startActivity(intent);
                    }
                });
                return;
            }
            return;
        }
        findViewById(R.id.progressBar).setVisibility(8);
        Helper.noConnection(this);
    }

    public void setHTML(String str) {
        Document parse = Jsoup.parse(str);
        if (!(parse.select("img") == null || parse.select("img").first() == null)) {
            parse.select("img").first().remove();
        }
        this.htmlTextView.loadDataWithBaseURL(this.post.getUrl(), WebHelper.docToBetterHTML(parse, this), "text/html", "UTF-8", "");
        this.htmlTextView.setVisibility(0);
        findViewById(R.id.progressBar).setVisibility(8);
    }

    @Override // com.thedaw.uiuians.providers.wordpress.api.JsonApiPostLoader.BackgroundPostCompleterListener
    public void completed(final PostItem postItem) {
        runOnUiThread(new Runnable() {
            /* class com.thedaw.uiuians.providers.wordpress.ui.WordpressDetailActivity.AnonymousClass9 */

            public void run() {
                try {
                    if (postItem.getPostType() == PostItem.PostType.JSON) {
                        WordpressDetailActivity.this.loadPostBody(postItem);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}

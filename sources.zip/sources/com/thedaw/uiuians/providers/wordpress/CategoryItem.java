package com.thedaw.uiuians.providers.wordpress;

public class CategoryItem {
    private String id;
    private String name;
    private int postCount;

    public CategoryItem(String str, String str2, int i) {
        this.id = str;
        this.name = str2;
        this.postCount = i;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public int getPostCount() {
        return this.postCount;
    }

    public void setPostCount(int i) {
        this.postCount = i;
    }

    public String toString() {
        return "Id: " + this.id + " Name: " + this.name + " Postcount: " + this.postCount;
    }
}

package com.thedaw.uiuians.providers.overview;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.drawer.NavItem;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import java.util.List;

public class CategoryAdapter extends InfiniteRecyclerViewAdapter {
    private static final int IMAGE_TYPE = 1;
    private static final int TEXT_TYPE = 0;
    private OnOverViewClick callback;
    private Context context;
    private List<NavItem> data;
    private int number;

    public interface OnOverViewClick {
        void onOverViewSelected(NavItem navItem);
    }

    public CategoryAdapter(List<NavItem> list, Context context2, OnOverViewClick onOverViewClick) {
        super(context2, null);
        this.data = list;
        this.context = context2;
        this.callback = onOverViewClick;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getViewType(int i) {
        if (i < 0 || i >= this.data.size()) {
            return super.getItemViewType(i);
        }
        return (this.data.get(i).getCategoryImageUrl() == null || this.data.get(i).getCategoryImageUrl().isEmpty()) ? 0 : 1;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public RecyclerView.ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        if (i == 0) {
            return new TextViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_overview_card_text, viewGroup, false));
        }
        if (i == 1) {
            return new ImageViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_overview_card_image, viewGroup, false));
        }
        return null;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public void doBindViewHolder(final RecyclerView.ViewHolder viewHolder, int i) {
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.overview.CategoryAdapter.AnonymousClass1 */

            public void onClick(View view) {
                CategoryAdapter.this.callback.onOverViewSelected((NavItem) CategoryAdapter.this.data.get(viewHolder.getAdapterPosition()));
            }
        });
        if (viewHolder instanceof TextViewHolder) {
            TextViewHolder textViewHolder = (TextViewHolder) viewHolder;
            textViewHolder.title.setText(this.data.get(i).getText(this.context));
            textViewHolder.background.setBackgroundResource(randomGradientResource());
        } else if (viewHolder instanceof ImageViewHolder) {
            ImageViewHolder imageViewHolder = (ImageViewHolder) viewHolder;
            Picasso.get().load(this.data.get(i).getCategoryImageUrl()).placeholder(R.color.black_more_translucent).into(imageViewHolder.image);
            imageViewHolder.title.setText(this.data.get(i).getText(this.context));
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getCount() {
        return this.data.size();
    }

    private class ImageViewHolder extends RecyclerView.ViewHolder {
        public ImageView image;
        public View itemView;
        public TextView title;

        private ImageViewHolder(View view) {
            super(view);
            this.itemView = view;
            this.title = (TextView) view.findViewById(R.id.title);
            this.image = (ImageView) view.findViewById(R.id.image);
        }
    }

    private class TextViewHolder extends RecyclerView.ViewHolder {
        public View background;
        public View itemView;
        public TextView title;

        private TextViewHolder(View view) {
            super(view);
            this.itemView = view;
            this.background = view.findViewById(R.id.background);
            this.title = (TextView) view.findViewById(R.id.title);
        }
    }

    private int randomGradientResource() {
        this.number++;
        if (this.number == 6) {
            this.number = 1;
        }
        return Helper.getGradient(this.number);
    }
}

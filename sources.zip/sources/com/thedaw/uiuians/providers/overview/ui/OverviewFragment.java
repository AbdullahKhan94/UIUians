package com.thedaw.uiuians.providers.overview.ui;

import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.drawer.NavItem;
import com.thedaw.uiuians.providers.overview.CategoryAdapter;
import com.thedaw.uiuians.providers.overview.OverviewParser;
import com.thedaw.uiuians.util.Helper;
import java.util.ArrayList;

public class OverviewFragment extends Fragment implements CategoryAdapter.OnOverViewClick {
    private DividerItemDecoration horizontalDec;
    private ArrayList<NavItem> items;
    private RecyclerView mRecyclerView;
    private CategoryAdapter multipleItemAdapter;
    private String overviewString;
    private ViewTreeObserver.OnGlobalLayoutListener recyclerListener;
    private RelativeLayout rl;

    @Override // android.support.v4.app.Fragment
    @Nullable
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.rl = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list, (ViewGroup) null);
        setHasOptionsMenu(true);
        this.mRecyclerView = (RecyclerView) this.rl.findViewById(R.id.list);
        final StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(1, 1);
        this.mRecyclerView.setLayoutManager(staggeredGridLayoutManager);
        this.items = new ArrayList<>();
        this.multipleItemAdapter = new CategoryAdapter(this.items, getContext(), this);
        this.mRecyclerView.setAdapter(this.multipleItemAdapter);
        this.multipleItemAdapter.setModeAndNotify(3);
        this.overviewString = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        this.recyclerListener = new ViewTreeObserver.OnGlobalLayoutListener() {
            /* class com.thedaw.uiuians.providers.overview.ui.OverviewFragment.AnonymousClass1 */

            public void onGlobalLayout() {
                int measuredWidth = OverviewFragment.this.mRecyclerView.getMeasuredWidth();
                if (measuredWidth > 0) {
                    OverviewFragment.this.mRecyclerView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    int max = Math.max(1, (int) Math.floor((double) (((float) measuredWidth) / OverviewFragment.this.getResources().getDimension(R.dimen.card_width_overview))));
                    staggeredGridLayoutManager.setSpanCount(max);
                    staggeredGridLayoutManager.requestLayout();
                    if (max > 1) {
                        OverviewFragment.this.mRecyclerView.addItemDecoration(OverviewFragment.this.horizontalDec);
                    } else {
                        OverviewFragment.this.mRecyclerView.removeItemDecoration(OverviewFragment.this.horizontalDec);
                    }
                }
            }
        };
        this.mRecyclerView.getViewTreeObserver().addOnGlobalLayoutListener(this.recyclerListener);
        this.horizontalDec = new DividerItemDecoration(this.mRecyclerView.getContext(), 0);
        this.mRecyclerView.addItemDecoration(new DividerItemDecoration(this.mRecyclerView.getContext(), 1));
        loadItems();
        return this.rl;
    }

    public void loadItems() {
        new OverviewParser(this.overviewString, getActivity(), new OverviewParser.CallBack() {
            /* class com.thedaw.uiuians.providers.overview.ui.OverviewFragment.AnonymousClass2 */

            @Override // com.thedaw.uiuians.providers.overview.OverviewParser.CallBack
            public void categoriesLoaded(ArrayList<NavItem> arrayList, boolean z) {
                if (!z) {
                    OverviewFragment.this.items.addAll(arrayList);
                    OverviewFragment.this.multipleItemAdapter.setModeAndNotify(1);
                } else if (!OverviewFragment.this.overviewString.contains("http") || Helper.isOnlineShowDialog(OverviewFragment.this.getActivity())) {
                    Toast.makeText(OverviewFragment.this.getActivity(), (int) R.string.invalid_configuration, 1).show();
                    OverviewFragment.this.multipleItemAdapter.setModeAndNotify(2);
                }
            }
        }).execute(new Void[0]);
    }

    @Override // android.support.v4.app.Fragment
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.mRecyclerView.getViewTreeObserver().addOnGlobalLayoutListener(this.recyclerListener);
    }

    @Override // com.thedaw.uiuians.providers.overview.CategoryAdapter.OnOverViewClick
    public void onOverViewSelected(NavItem navItem) {
        HolderActivity.startActivity(getActivity(), navItem.getFragment(), navItem.getData());
    }
}

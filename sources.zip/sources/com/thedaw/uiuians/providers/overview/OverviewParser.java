package com.thedaw.uiuians.providers.overview;

import android.app.Activity;
import android.os.AsyncTask;
import com.thedaw.uiuians.ConfigParser;
import com.thedaw.uiuians.drawer.NavItem;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;

public class OverviewParser extends AsyncTask<Void, Void, Void> {
    private CallBack callback;
    private Activity context;
    private boolean facedException;
    private ArrayList<NavItem> result;
    private String sourceLocation;

    public interface CallBack {
        void categoriesLoaded(ArrayList<NavItem> arrayList, boolean z);
    }

    public OverviewParser(String str, Activity activity, CallBack callBack) {
        this.sourceLocation = str;
        this.context = activity;
        this.callback = callBack;
    }

    /* access modifiers changed from: protected */
    public void onPreExecute() {
        super.onPreExecute();
    }

    /* access modifiers changed from: protected */
    public Void doInBackground(Void... voidArr) {
        JSONArray jSONArray;
        try {
            if (this.sourceLocation.contains("http")) {
                jSONArray = new JSONArray(Helper.getDataFromUrl(this.sourceLocation));
            } else {
                String loadJSONFromAsset = Helper.loadJSONFromAsset(this.context, this.sourceLocation);
                if (loadJSONFromAsset != null) {
                    jSONArray = new JSONArray(loadJSONFromAsset);
                }
                jSONArray = null;
            }
        } catch (JSONException e) {
            Log.e("INFO", "JSON was invalid");
            this.facedException = true;
            e.printStackTrace();
        }
        if (jSONArray != null) {
            this.result = new ArrayList<>();
            for (int i = 0; i < jSONArray.length(); i++) {
                try {
                    this.result.add(ConfigParser.navItemFromJSON(this.context, jSONArray.getJSONObject(i)));
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    Log.e("INFO", "JSON was invalid");
                    this.facedException = true;
                }
            }
        } else {
            Log.e("INFO", "JSON Could not be retrieved");
            this.facedException = true;
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(Void r3) {
        if (this.callback != null) {
            this.callback.categoriesLoaded(this.result, this.facedException);
        }
    }
}

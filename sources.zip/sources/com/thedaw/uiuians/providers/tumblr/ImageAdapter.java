package com.thedaw.uiuians.providers.tumblr;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.tumblr.ui.TumblrPagerActivity;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import java.util.ArrayList;

public class ImageAdapter extends InfiniteRecyclerViewAdapter {
    private ArrayList<TumblrItem> listData;
    private Context mContext;

    @Override // android.support.v7.widget.RecyclerView.Adapter
    public long getItemId(int i) {
        return (long) i;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getViewType(int i) {
        return 0;
    }

    public ImageAdapter(Context context, ArrayList<TumblrItem> arrayList, InfiniteRecyclerViewAdapter.LoadMoreListener loadMoreListener) {
        super(context, loadMoreListener);
        this.listData = arrayList;
        this.mContext = context;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public RecyclerView.ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        return new ItemViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_tumblr_row, viewGroup, false));
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public void doBindViewHolder(RecyclerView.ViewHolder viewHolder, final int i) {
        if (viewHolder instanceof ItemViewHolder) {
            Picasso.get().load(this.listData.get(i).getUrl()).placeholder(R.drawable.placeholder).fit().centerCrop().into(((ItemViewHolder) viewHolder).imageView);
            viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.tumblr.ImageAdapter.AnonymousClass1 */

                public void onClick(View view) {
                    ImageAdapter.this.startImagePagerActivity(i);
                }
            });
        }
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getCount() {
        return this.listData.size();
    }

    private static class ItemViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;

        private ItemViewHolder(View view) {
            super(view);
            this.imageView = (ImageView) view.findViewById(R.id.image);
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void startImagePagerActivity(int i) {
        Intent intent = new Intent(this.mContext, TumblrPagerActivity.class);
        ArrayList<? extends Parcelable> arrayList = new ArrayList<>();
        for (int i2 = 0; i2 < getCount(); i2++) {
            arrayList.add(this.listData.get(i2));
        }
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("com.nostra13.example.universalimageloader.IMAGES", arrayList);
        intent.putExtras(bundle);
        intent.putExtra("com.nostra13.example.universalimageloader.IMAGE_POSITION", i);
        this.mContext.startActivity(intent);
    }
}

package com.thedaw.uiuians.providers.tumblr;

import android.os.Parcel;
import android.os.Parcelable;

public class TumblrItem implements Parcelable {
    public static final Parcelable.Creator<TumblrItem> CREATOR = new Parcelable.Creator<TumblrItem>() {
        /* class com.thedaw.uiuians.providers.tumblr.TumblrItem.AnonymousClass1 */

        @Override // android.os.Parcelable.Creator
        public TumblrItem createFromParcel(Parcel parcel) {
            return new TumblrItem(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public TumblrItem[] newArray(int i) {
            return new TumblrItem[i];
        }
    };
    protected String id;
    protected String link;
    protected String url;

    public TumblrItem() {
    }

    public TumblrItem(String str, String str2, String str3) {
        this.id = str;
        this.link = str2;
        this.url = str3;
    }

    public String getUrl() {
        return this.url;
    }

    public String getId() {
        return this.id;
    }

    public String getLink() {
        return this.link;
    }

    public TumblrItem(Parcel parcel) {
        this.id = parcel.readString();
        this.link = parcel.readString();
        this.url = parcel.readString();
    }

    public int describeContents() {
        return hashCode();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.id);
        parcel.writeString(this.link);
        parcel.writeString(this.url);
    }
}

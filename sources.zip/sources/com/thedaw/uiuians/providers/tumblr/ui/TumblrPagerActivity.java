package com.thedaw.uiuians.providers.tumblr.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.tumblr.TumblrItem;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import uk.co.senab.photoview.PhotoViewAttacher;

public class TumblrPagerActivity extends Activity {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    private static final String STATE_POSITION = "STATE_POSITION";
    ViewPager imagePager;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_tumblr_pager);
        Bundle extras = getIntent().getExtras();
        ArrayList parcelableArrayList = extras.getParcelableArrayList("com.nostra13.example.universalimageloader.IMAGES");
        int i = extras.getInt("com.nostra13.example.universalimageloader.IMAGE_POSITION", 0);
        if (bundle != null) {
            i = bundle.getInt(STATE_POSITION);
        }
        this.imagePager = (ViewPager) findViewById(R.id.pager);
        if (parcelableArrayList != null) {
            this.imagePager.setAdapter(new ImagePagerAdapter(parcelableArrayList));
            this.imagePager.setCurrentItem(i);
        }
        Helper.admobLoader(this, findViewById(R.id.adView));
    }

    public void onSaveInstanceState(Bundle bundle) {
        bundle.putInt(STATE_POSITION, this.imagePager.getCurrentItem());
    }

    private class ImagePagerAdapter extends PagerAdapter {
        static final /* synthetic */ boolean $assertionsDisabled = false;
        private ArrayList<TumblrItem> images;
        private LayoutInflater inflater;

        @Override // android.support.v4.view.PagerAdapter
        public void restoreState(Parcelable parcelable, ClassLoader classLoader) {
        }

        @Override // android.support.v4.view.PagerAdapter
        public Parcelable saveState() {
            return null;
        }

        ImagePagerAdapter(ArrayList<TumblrItem> arrayList) {
            this.images = arrayList;
            this.inflater = TumblrPagerActivity.this.getLayoutInflater();
        }

        @Override // android.support.v4.view.PagerAdapter
        public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
            viewGroup.removeView((View) obj);
        }

        @Override // android.support.v4.view.PagerAdapter
        public int getCount() {
            return this.images.size();
        }

        @Override // android.support.v4.view.PagerAdapter
        public Object instantiateItem(ViewGroup viewGroup, final int i) {
            View inflate = this.inflater.inflate(R.layout.activity_tumblr_pager_image, viewGroup, false);
            final ImageView imageView = (ImageView) inflate.findViewById(R.id.image);
            final Button button = (Button) inflate.findViewById(R.id.btnShare);
            Button button2 = (Button) inflate.findViewById(R.id.btnSet);
            final Button button3 = (Button) inflate.findViewById(R.id.btnSave);
            final ProgressBar progressBar = (ProgressBar) inflate.findViewById(R.id.loading);
            progressBar.setVisibility(0);
            Picasso.get().load(this.images.get(i).getUrl()).into(imageView, new Callback() {
                /* class com.thedaw.uiuians.providers.tumblr.ui.TumblrPagerActivity.ImagePagerAdapter.AnonymousClass1 */

                @Override // com.squareup.picasso.Callback
                public void onSuccess() {
                    progressBar.setVisibility(8);
                    new PhotoViewAttacher(imageView);
                    button3.setOnClickListener(new View.OnClickListener() {
                        /* class com.thedaw.uiuians.providers.tumblr.ui.TumblrPagerActivity.ImagePagerAdapter.AnonymousClass1.AnonymousClass1 */

                        public void onClick(View view) {
                            String file = Environment.getExternalStorageDirectory().toString();
                            File file2 = new File(file, "tumblr_" + ((TumblrItem) ImagePagerAdapter.this.images.get(i)).getId() + ".jpg");
                            try {
                                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                                ((BitmapDrawable) imageView.getDrawable()).getBitmap().compress(Bitmap.CompressFormat.JPEG, 99, fileOutputStream);
                                fileOutputStream.flush();
                                fileOutputStream.close();
                                MediaStore.Images.Media.insertImage(TumblrPagerActivity.this.getContentResolver(), file2.getAbsolutePath(), file2.getName(), file2.getName());
                                String string = TumblrPagerActivity.this.getResources().getString(R.string.saved);
                                Context baseContext = TumblrPagerActivity.this.getBaseContext();
                                Toast.makeText(baseContext, string + " " + file2.toString(), 1).show();
                            } catch (FileNotFoundException e) {
                                Log.printStackTrace(e);
                            } catch (IOException e2) {
                                Log.printStackTrace(e2);
                            }
                        }
                    });
                    button.setOnClickListener(new View.OnClickListener() {
                        /* class com.thedaw.uiuians.providers.tumblr.ui.TumblrPagerActivity.ImagePagerAdapter.AnonymousClass1.AnonymousClass2 */

                        public void onClick(View view) {
                            String string = TumblrPagerActivity.this.getResources().getString(R.string.tumblr_share_begin);
                            String string2 = TumblrPagerActivity.this.getResources().getString(R.string.app_name);
                            Intent intent = new Intent();
                            intent.setType("text/plain");
                            intent.setAction("android.intent.action.SEND");
                            intent.putExtra("android.intent.extra.TEXT", string + " " + string2 + ": " + ((TumblrItem) ImagePagerAdapter.this.images.get(i)).getLink());
                            TumblrPagerActivity.this.startActivity(Intent.createChooser(intent, "Share"));
                        }
                    });
                }

                @Override // com.squareup.picasso.Callback
                public void onError(Exception exc) {
                    progressBar.setVisibility(8);
                }
            });
            button2.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.tumblr.ui.TumblrPagerActivity.ImagePagerAdapter.AnonymousClass2 */

                public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(TumblrPagerActivity.this);
                    builder.setMessage(TumblrPagerActivity.this.getResources().getString(R.string.set_confirm)).setCancelable(true).setPositiveButton(TumblrPagerActivity.this.getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {
                        /* class com.thedaw.uiuians.providers.tumblr.ui.TumblrPagerActivity.ImagePagerAdapter.AnonymousClass2.AnonymousClass1 */

                        public void onClick(DialogInterface dialogInterface, int i) {
                            try {
                                WallpaperManager.getInstance(TumblrPagerActivity.this).setBitmap(((BitmapDrawable) imageView.getDrawable()).getBitmap());
                                Toast.makeText(TumblrPagerActivity.this, TumblrPagerActivity.this.getResources().getString(R.string.set_success), 0).show();
                            } catch (IOException e) {
                                Log.printStackTrace(e);
                                Log.v("ERROR", "Wallpaper not set");
                            }
                        }
                    });
                    builder.create().show();
                }
            });
            viewGroup.addView(inflate, 0);
            return inflate;
        }

        @Override // android.support.v4.view.PagerAdapter
        public boolean isViewFromObject(View view, Object obj) {
            return view.equals(obj);
        }
    }
}

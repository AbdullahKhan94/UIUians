package com.thedaw.uiuians.providers.tumblr.ui;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.google.android.exoplayer2.text.ttml.TtmlNode;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.inherit.PermissionsFragment;
import com.thedaw.uiuians.providers.tumblr.ImageAdapter;
import com.thedaw.uiuians.providers.tumblr.TumblrItem;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import com.thedaw.uiuians.util.Log;
import com.thedaw.uiuians.util.ThemeUtils;
import com.thedaw.uiuians.util.layout.StaggeredGridSpacingItemDecoration;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TumblrFragment extends Fragment implements PermissionsFragment, InfiniteRecyclerViewAdapter.LoadMoreListener {
    String baseurl;
    Integer curpage = 0;
    private ImageAdapter imageAdapter = null;
    Boolean isLoading = true;
    private RecyclerView listView;
    private RelativeLayout ll;
    private Activity mAct;
    String perpage = "25";
    Integer total_posts;
    ArrayList<TumblrItem> tumblrItems;

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list, viewGroup, false);
        return this.ll;
    }

    @Override // android.support.v4.app.Fragment
    public void onViewCreated(View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        setHasOptionsMenu(true);
        String str = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        this.baseurl = "https://api.tumblr.com/v2/blog/" + str + ".tumblr.com/posts?api_key=" + getString(R.string.tumblr_key) + "&type=photo&limit=" + this.perpage + "&offset=";
        this.listView = (RecyclerView) this.ll.findViewById(R.id.list);
        this.tumblrItems = new ArrayList<>();
        this.imageAdapter = new ImageAdapter(getContext(), this.tumblrItems, this);
        this.imageAdapter.setModeAndNotify(3);
        this.listView.setAdapter(this.imageAdapter);
        this.listView.setLayoutManager(new StaggeredGridLayoutManager(3, 1));
        this.listView.setItemAnimator(new DefaultItemAnimator());
        this.listView.addItemDecoration(new StaggeredGridSpacingItemDecoration((int) getResources().getDimension(R.dimen.woocommerce_padding), true));
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        refreshItems();
    }

    public void updateList(ArrayList<TumblrItem> arrayList) {
        if (arrayList.size() > 0) {
            this.tumblrItems.addAll(arrayList);
        }
        if (this.curpage.intValue() * Integer.parseInt(this.perpage) > this.total_posts.intValue() || arrayList.size() == 0) {
            this.imageAdapter.setHasMore(false);
        }
        this.imageAdapter.setModeAndNotify(1);
    }

    @Override // com.thedaw.uiuians.inherit.PermissionsFragment
    public String[] requiredPermissions() {
        return new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"};
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter.LoadMoreListener
    public void onMoreRequested() {
        if (!this.isLoading.booleanValue() && this.curpage.intValue() * Integer.parseInt(this.perpage) <= this.total_posts.intValue()) {
            this.isLoading = true;
            new InitialLoadGridView().execute(this.baseurl);
        }
    }

    /* access modifiers changed from: package-private */
    public void refreshItems() {
        this.isLoading = true;
        this.curpage = 0;
        this.tumblrItems.clear();
        this.imageAdapter.setHasMore(true);
        this.imageAdapter.setModeAndNotify(3);
        new InitialLoadGridView().execute(this.baseurl);
    }

    /* access modifiers changed from: private */
    public class InitialLoadGridView extends AsyncTask<String, Void, ArrayList<TumblrItem>> {
        private InitialLoadGridView() {
        }

        /* access modifiers changed from: protected */
        public ArrayList<TumblrItem> doInBackground(String... strArr) {
            JSONObject jSONObject;
            JSONException e;
            NullPointerException e2;
            TumblrFragment.this.curpage = Integer.valueOf(TumblrFragment.this.curpage.intValue() + 1);
            String dataFromUrl = Helper.getDataFromUrl(strArr[0] + Integer.toString(TumblrFragment.this.curpage.intValue() * Integer.parseInt(TumblrFragment.this.perpage)));
            Log.v("INFO", "Tumblr JSON: " + dataFromUrl);
            ArrayList<TumblrItem> arrayList = null;
            try {
                jSONObject = new JSONObject(dataFromUrl).getJSONObject("response");
            } catch (JSONException e3) {
                Log.printStackTrace(e3);
                jSONObject = null;
            }
            try {
                TumblrFragment.this.total_posts = Integer.valueOf(jSONObject.getInt("total_posts"));
                if (TumblrFragment.this.total_posts.intValue() > 0) {
                    JSONArray jSONArray = jSONObject.getJSONArray("posts");
                    ArrayList<TumblrItem> arrayList2 = new ArrayList<>();
                    for (int i = 0; i < jSONArray.length(); i++) {
                        try {
                            JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                            String string = jSONObject2.getString(TtmlNode.ATTR_ID);
                            String string2 = jSONObject2.getString("post_url");
                            JSONArray jSONArray2 = jSONObject2.getJSONArray("photos");
                            String string3 = jSONArray2.length() > 0 ? ((JSONObject) jSONArray2.get(0)).getJSONObject("original_size").getString("url") : null;
                            if (string3 != null) {
                                arrayList2.add(new TumblrItem(string, string2, string3));
                            }
                        } catch (JSONException e4) {
                            e = e4;
                            arrayList = arrayList2;
                            Log.printStackTrace(e);
                            return arrayList;
                        } catch (NullPointerException e5) {
                            e2 = e5;
                            arrayList = arrayList2;
                            Log.printStackTrace(e2);
                            return arrayList;
                        }
                    }
                    return arrayList2;
                }
                Log.v("INFO", "No items found");
                return null;
            } catch (JSONException e6) {
                e = e6;
                Log.printStackTrace(e);
                return arrayList;
            } catch (NullPointerException e7) {
                e2 = e7;
                Log.printStackTrace(e2);
                return arrayList;
            }
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(ArrayList<TumblrItem> arrayList) {
            if (arrayList != null) {
                TumblrFragment.this.updateList(arrayList);
            } else {
                Helper.noConnection(TumblrFragment.this.mAct);
                TumblrFragment.this.imageAdapter.setModeAndNotify(2);
            }
            TumblrFragment.this.isLoading = false;
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.refresh_menu, menu);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.refresh) {
            if (!this.isLoading.booleanValue()) {
                refreshItems();
            } else {
                Toast.makeText(this.mAct, getString(R.string.already_loading), 1).show();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }
}

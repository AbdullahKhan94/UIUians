package com.thedaw.uiuians.providers.tumblr;

public final class Constants {

    public static class Extra {
        public static final String IMAGES = "com.nostra13.example.universalimageloader.IMAGES";
        public static final String IMAGE_POSITION = "com.nostra13.example.universalimageloader.IMAGE_POSITION";
    }

    private Constants() {
    }
}

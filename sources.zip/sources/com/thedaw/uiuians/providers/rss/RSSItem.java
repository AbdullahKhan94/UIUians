package com.thedaw.uiuians.providers.rss;

import android.text.Html;
import java.io.Serializable;

public class RSSItem implements Serializable {
    private String audiourl = null;
    private String description = null;
    private String link = null;
    private String pubdate = null;
    private String rowdescription = null;
    private String thumburl = null;
    private String title = null;
    private String videourl = null;

    /* access modifiers changed from: package-private */
    public void setTitle(String str) {
        this.title = str;
    }

    /* access modifiers changed from: package-private */
    public void setDescription(String str) {
        this.description = str;
        this.rowdescription = stripHtml(str).toString();
    }

    /* access modifiers changed from: package-private */
    public void setLink(String str) {
        this.link = str;
    }

    /* access modifiers changed from: package-private */
    public void setPubdate(String str) {
        this.pubdate = str;
    }

    /* access modifiers changed from: package-private */
    public void setThumburl(String str) {
        this.thumburl = str;
    }

    /* access modifiers changed from: package-private */
    public void setVideourl(String str) {
        this.videourl = str;
    }

    /* access modifiers changed from: package-private */
    public void setAudiourl(String str) {
        this.audiourl = str;
    }

    public String getTitle() {
        return this.title;
    }

    public String getDescription() {
        return this.description;
    }

    public String getRowDescription() {
        return this.rowdescription;
    }

    public String getLink() {
        return this.link;
    }

    public String getPubdate() {
        return this.pubdate;
    }

    public String getAudiourl() {
        return this.audiourl;
    }

    public String getVideourl() {
        return this.videourl;
    }

    public String getThumburl() {
        return this.thumburl;
    }

    public CharSequence stripHtml(String str) {
        return Html.fromHtml(str).toString().replace('\n', ' ').replace((char) 160, ' ').replace((char) 65532, ' ').trim();
    }
}

package com.thedaw.uiuians.providers.rss;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.rss.ui.RssDetailActivity;
import com.thedaw.uiuians.providers.rss.ui.RssFragment;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import com.thedaw.uiuians.util.ViewModeUtils;
import java.io.Serializable;
import java.util.List;

public class RssAdapter extends InfiniteRecyclerViewAdapter {
    private static int COMPACT = 0;
    private static int NORMAL = 1;
    private Context context;
    private List<RSSItem> objects;
    private ViewModeUtils viewModeUtils;

    public RssAdapter(Context context2, List<RSSItem> list) {
        super(context2, null);
        this.context = context2;
        this.objects = list;
        this.viewModeUtils = new ViewModeUtils(context2, RssFragment.class);
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getViewType(int i) {
        if (this.viewModeUtils.getViewMode() == 1) {
            return NORMAL;
        }
        return COMPACT;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public RecyclerView.ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        if (COMPACT == i) {
            return new RssViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_rss_row, viewGroup, false));
        }
        if (i == NORMAL) {
            return new RssLargeViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listview_row, viewGroup, false));
        }
        return null;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public void doBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof RssViewHolder) {
            RssViewHolder rssViewHolder = (RssViewHolder) viewHolder;
            String rowDescription = this.objects.get(i).getRowDescription();
            rssViewHolder.listTitle.setText(this.objects.get(i).getTitle());
            rssViewHolder.listPubdate.setText(this.objects.get(i).getPubdate());
            rssViewHolder.listDescription.setText(rowDescription);
            rssViewHolder.listThumb.setImageDrawable(null);
            loadImageIntoView(this.objects.get(i).getThumburl(), rssViewHolder.listThumb);
            setOnClickListener(rssViewHolder.itemView, i);
            return;
        }
        RssLargeViewHolder rssLargeViewHolder = (RssLargeViewHolder) viewHolder;
        rssLargeViewHolder.headlineView.setText(this.objects.get(i).getTitle());
        rssLargeViewHolder.reportedDateView.setText(this.objects.get(i).getPubdate());
        rssLargeViewHolder.imageView.setImageBitmap(null);
        loadImageIntoView(this.objects.get(i).getThumburl(), rssLargeViewHolder.imageView);
        setOnClickListener(rssLargeViewHolder.itemView, i);
    }

    private void setOnClickListener(View view, final int i) {
        view.setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.rss.RssAdapter.AnonymousClass1 */

            public void onClick(View view) {
                Intent intent = new Intent(RssAdapter.this.context, RssDetailActivity.class);
                Bundle bundle = new Bundle();
                intent.putExtra("postitem", (Serializable) RssAdapter.this.objects.get(i));
                intent.putExtras(bundle);
                RssAdapter.this.context.startActivity(intent);
            }
        });
    }

    private void loadImageIntoView(String str, final ImageView imageView) {
        if (str == null || str.equals("")) {
            imageView.setVisibility(8);
            return;
        }
        AnonymousClass2 r0 = new Target() {
            /* class com.thedaw.uiuians.providers.rss.RssAdapter.AnonymousClass2 */

            @Override // com.squareup.picasso.Target
            public void onBitmapFailed(Exception exc, Drawable drawable) {
            }

            @Override // com.squareup.picasso.Target
            public void onPrepareLoad(Drawable drawable) {
            }

            @Override // com.squareup.picasso.Target
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom loadedFrom) {
                if (10 > bitmap.getWidth() || 10 > bitmap.getHeight()) {
                    imageView.setVisibility(8);
                    return;
                }
                imageView.setVisibility(0);
                imageView.setImageBitmap(bitmap);
            }
        };
        imageView.setTag(r0);
        Picasso.get().load(str).into(r0);
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getCount() {
        return this.objects.size();
    }

    private class RssViewHolder extends RecyclerView.ViewHolder {
        TextView listDescription;
        TextView listPubdate;
        ImageView listThumb;
        TextView listTitle;

        RssViewHolder(View view) {
            super(view);
            this.listTitle = (TextView) view.findViewById(R.id.listtitle);
            this.listPubdate = (TextView) view.findViewById(R.id.listpubdate);
            this.listDescription = (TextView) view.findViewById(R.id.shortdescription);
            this.listThumb = (ImageView) view.findViewById(R.id.listthumb);
        }
    }

    private static class RssLargeViewHolder extends RecyclerView.ViewHolder {
        TextView headlineView;
        ImageView imageView;
        TextView reportedDateView;

        RssLargeViewHolder(View view) {
            super(view);
            this.headlineView = (TextView) view.findViewById(R.id.title);
            this.reportedDateView = (TextView) view.findViewById(R.id.date);
            this.imageView = (ImageView) view.findViewById(R.id.thumbImage);
        }
    }
}

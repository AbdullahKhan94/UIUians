package com.thedaw.uiuians.providers.rss;

import java.util.List;
import java.util.Vector;

public class RSSFeed {
    private String description = null;
    private List<RSSItem> itemList = new Vector(0);
    private String link = null;
    private String pubdate = null;
    private String title = null;

    RSSFeed() {
    }

    /* access modifiers changed from: package-private */
    public void addItem(RSSItem rSSItem) {
        this.itemList.add(rSSItem);
    }

    public RSSItem getItem(int i) {
        return this.itemList.get(i);
    }

    public List<RSSItem> getList() {
        return this.itemList;
    }

    /* access modifiers changed from: package-private */
    public void setTitle(String str) {
        this.title = str;
    }

    /* access modifiers changed from: package-private */
    public void setDescription(String str) {
        this.description = str;
    }

    /* access modifiers changed from: package-private */
    public void setLink(String str) {
        this.link = str;
    }

    /* access modifiers changed from: package-private */
    public void setPubdate(String str) {
        this.pubdate = str;
    }

    public String getTitle() {
        return this.title;
    }

    public String getDescription() {
        return this.description;
    }

    public String getLink() {
        return this.link;
    }

    /* access modifiers changed from: package-private */
    public String getPubdate() {
        return this.pubdate;
    }
}

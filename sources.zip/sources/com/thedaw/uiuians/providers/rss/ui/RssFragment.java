package com.thedaw.uiuians.providers.rss.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.rss.RSSFeed;
import com.thedaw.uiuians.providers.rss.RSSHandler;
import com.thedaw.uiuians.providers.rss.RSSItem;
import com.thedaw.uiuians.providers.rss.RssAdapter;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import com.thedaw.uiuians.util.ThemeUtils;
import com.thedaw.uiuians.util.ViewModeUtils;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

public class RssFragment extends Fragment {
    private RssAdapter listAdapter;
    private RelativeLayout ll;
    private Activity mAct;
    private ArrayList<RSSItem> postsList;
    private RSSFeed rssFeed = null;
    private SwipeRefreshLayout swipeRefreshLayout;
    private String url;
    private ViewModeUtils viewModeUtils;

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list_refresh, viewGroup, false);
        return this.ll;
    }

    @Override // android.support.v4.app.Fragment
    public void onViewCreated(View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        setHasOptionsMenu(true);
        RecyclerView recyclerView = (RecyclerView) this.ll.findViewById(R.id.list);
        this.postsList = new ArrayList<>();
        this.listAdapter = new RssAdapter(getContext(), this.postsList);
        this.listAdapter.setModeAndNotify(3);
        recyclerView.setAdapter(this.listAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), 1, false));
        this.swipeRefreshLayout = (SwipeRefreshLayout) this.ll.findViewById(R.id.swipeRefreshLayout);
        this.swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            /* class com.thedaw.uiuians.providers.rss.ui.RssFragment.AnonymousClass1 */

            @Override // android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener
            public void onRefresh() {
                RssFragment.this.refreshItems();
            }
        });
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        this.url = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        refreshItems();
    }

    /* access modifiers changed from: private */
    public class RssTask extends AsyncTask<Void, Void, Void> {
        private RssTask() {
        }

        /* access modifiers changed from: protected */
        public Void doInBackground(Void... voidArr) {
            try {
                URL url = new URL(RssFragment.this.url);
                XMLReader xMLReader = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
                RSSHandler rSSHandler = new RSSHandler();
                xMLReader.setContentHandler(rSSHandler);
                xMLReader.parse(new InputSource(url.openStream()));
                RssFragment.this.rssFeed = rSSHandler.getFeed();
                return null;
            } catch (IOException | ParserConfigurationException | SAXException e) {
                Log.printStackTrace(e);
                return null;
            }
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Void r5) {
            if (RssFragment.this.rssFeed != null) {
                if (RssFragment.this.rssFeed.getList().size() > 0) {
                    RssFragment.this.postsList.addAll(RssFragment.this.rssFeed.getList());
                }
                RssFragment.this.listAdapter.setHasMore(false);
                RssFragment.this.listAdapter.setModeAndNotify(1);
                RssFragment.this.swipeRefreshLayout.setRefreshing(false);
            } else {
                String str = null;
                if (!RssFragment.this.url.startsWith("http")) {
                    str = "Debug info: '" + RssFragment.this.url + "' is most likely not a valid RSS url. Make sure the url entered in your configuration starts with 'http' and verify if it's valid XML using https://validator.w3.org/feed/";
                }
                Helper.noConnection(RssFragment.this.mAct, str);
                RssFragment.this.listAdapter.setModeAndNotify(2);
                RssFragment.this.swipeRefreshLayout.setRefreshing(false);
            }
            super.onPostExecute((Object) r5);
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.rss_menu, menu);
        this.viewModeUtils = new ViewModeUtils(getContext(), getClass());
        this.viewModeUtils.inflateOptionsMenu(menu, menuInflater);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void refreshItems() {
        this.postsList.clear();
        this.listAdapter.setModeAndNotify(3);
        new RssTask().execute(new Void[0]);
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        this.viewModeUtils.handleSelection(menuItem, new ViewModeUtils.ChangeListener() {
            /* class com.thedaw.uiuians.providers.rss.ui.RssFragment.AnonymousClass2 */

            @Override // com.thedaw.uiuians.util.ViewModeUtils.ChangeListener
            public void modeChanged() {
                RssFragment.this.listAdapter.notifyDataSetChanged();
            }
        });
        if (menuItem.getItemId() != R.id.info) {
            return super.onOptionsItemSelected(menuItem);
        }
        if (this.rssFeed != null) {
            String title = this.rssFeed.getTitle();
            String description = this.rssFeed.getDescription();
            String link = this.rssFeed.getLink();
            AlertDialog.Builder builder = new AlertDialog.Builder(this.mAct);
            String string = getResources().getString(R.string.feed_title_value);
            String string2 = getResources().getString(R.string.feed_description_value);
            String string3 = getResources().getString(R.string.feed_link_value);
            if (link.equals("")) {
                builder.setMessage(string + ": \n" + title + "\n\n" + string2 + ": \n" + description);
            } else {
                builder.setMessage(string + ": \n" + title + "\n\n" + string2 + ": \n" + description + "\n\n" + string3 + ": \n" + link);
            }
            builder.setNegativeButton(getResources().getString(R.string.ok), (DialogInterface.OnClickListener) null).setCancelable(true);
            builder.create();
            builder.show();
        }
        return true;
    }
}

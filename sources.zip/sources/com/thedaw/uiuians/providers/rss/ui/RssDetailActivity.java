package com.thedaw.uiuians.providers.rss.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewStub;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.attachmentviewer.model.MediaAttachment;
import com.thedaw.uiuians.attachmentviewer.ui.AttachmentActivity;
import com.thedaw.uiuians.attachmentviewer.ui.AudioPlayerActivity;
import com.thedaw.uiuians.attachmentviewer.ui.VideoPlayerActivity;
import com.thedaw.uiuians.providers.fav.FavDbAdapter;
import com.thedaw.uiuians.providers.rss.RSSItem;
import com.thedaw.uiuians.util.DetailActivity;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.WebHelper;
import org.jsoup.Jsoup;

public class RssDetailActivity extends DetailActivity {
    public static final String EXTRA_RSSITEM = "postitem";
    private RSSItem item;
    private FavDbAdapter mDbHelper;
    private WebView wb;

    @Override // android.support.v4.app.SupportActivity, com.thedaw.uiuians.util.DetailActivity, android.support.v7.app.AppCompatActivity, android.support.v4.app.FragmentActivity
    @SuppressLint({"SetJavaScriptEnabled"})
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_details);
        ViewStub viewStub = (ViewStub) findViewById(R.id.layout_stub);
        viewStub.setLayoutResource(R.layout.activity_rss_details);
        viewStub.inflate();
        this.mToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(this.mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.thumb = (ImageView) findViewById(R.id.image);
        this.coolblue = (RelativeLayout) findViewById(R.id.coolblue);
        getIntent().getExtras();
        this.item = (RSSItem) getIntent().getSerializableExtra("postitem");
        ((TextView) findViewById(R.id.detailstitle)).setText(this.item.getTitle());
        ((TextView) findViewById(R.id.detailspubdate)).setText(this.item.getPubdate());
        setUpHeader(null);
        this.wb = (WebView) findViewById(R.id.descriptionwebview);
        String docToBetterHTML = WebHelper.docToBetterHTML(Jsoup.parse(this.item.getDescription()), this);
        this.wb.getSettings().setJavaScriptEnabled(true);
        this.wb.loadDataWithBaseURL(this.item.getLink(), docToBetterHTML, "text/html", "UTF-8", "");
        this.wb.setBackgroundColor(Color.argb(1, 0, 0, 0));
        this.wb.getSettings().setCacheMode(2);
        this.wb.getSettings().setDefaultFontSize(WebHelper.getWebViewFontSize(this));
        this.wb.setWebViewClient(new WebViewClient() {
            /* class com.thedaw.uiuians.providers.rss.ui.RssDetailActivity.AnonymousClass1 */

            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                if (str == null || (!str.endsWith(".png") && !str.endsWith(".jpg") && !str.endsWith(".jpeg"))) {
                    boolean z = false;
                    if (str == null || (!str.startsWith("http://") && !str.startsWith("https://"))) {
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
                        if (RssDetailActivity.this.getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
                            z = true;
                        }
                        if (z) {
                            RssDetailActivity.this.startActivity(intent);
                        }
                        return true;
                    }
                    HolderActivity.startWebViewActivity(RssDetailActivity.this, str, false, false, null);
                    return true;
                }
                AttachmentActivity.startActivity(RssDetailActivity.this, MediaAttachment.withImage(str));
                return true;
            }
        });
        Helper.admobLoader(this, findViewById(R.id.adView));
        Button button = (Button) findViewById(R.id.mediabutton);
        final String videourl = this.item.getVideourl();
        final String audiourl = this.item.getAudiourl();
        if (videourl != null) {
            button.setText(getResources().getString(R.string.btn_video));
        } else if (audiourl != null) {
            button.setText(getResources().getString(R.string.btn_audio));
        } else {
            button.setVisibility(8);
        }
        button.setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.rss.ui.RssDetailActivity.AnonymousClass2 */

            public void onClick(View view) {
                if (videourl != null) {
                    VideoPlayerActivity.startActivity(RssDetailActivity.this, videourl);
                } else if (audiourl != null) {
                    AudioPlayerActivity.startActivity(RssDetailActivity.this, audiourl, RssDetailActivity.this.item.getTitle());
                }
            }
        });
        ((Button) findViewById(R.id.openbutton)).setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.rss.ui.RssDetailActivity.AnonymousClass3 */

            public void onClick(View view) {
                HolderActivity.startWebViewActivity(RssDetailActivity.this, RssDetailActivity.this.item.getLink(), false, false, null);
            }
        });
        ((Button) findViewById(R.id.favoritebutton)).setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.rss.ui.RssDetailActivity.AnonymousClass4 */

            public void onClick(View view) {
                RssDetailActivity.this.mDbHelper = new FavDbAdapter(RssDetailActivity.this);
                RssDetailActivity.this.mDbHelper.open();
                if (RssDetailActivity.this.mDbHelper.checkEvent(RssDetailActivity.this.item.getTitle(), RssDetailActivity.this.item, 2)) {
                    RssDetailActivity.this.mDbHelper.addFavorite(RssDetailActivity.this.item.getTitle(), RssDetailActivity.this.item, 2);
                    Toast.makeText(RssDetailActivity.this, RssDetailActivity.this.getResources().getString(R.string.favorite_success), 1).show();
                    return;
                }
                Toast.makeText(RssDetailActivity.this, RssDetailActivity.this.getResources().getString(R.string.favorite_duplicate), 1).show();
            }
        });
    }

    @Override // com.thedaw.uiuians.util.DetailActivity, android.support.v4.app.FragmentActivity
    public void onPause() {
        super.onPause();
        this.wb.onPause();
    }

    @Override // com.thedaw.uiuians.util.DetailActivity, android.support.v4.app.FragmentActivity
    public void onResume() {
        super.onResume();
        this.wb.onResume();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            finish();
            return true;
        } else if (itemId != R.id.menu_item_share) {
            return super.onOptionsItemSelected(menuItem);
        } else {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.SEND");
            intent.putExtra("android.intent.extra.TEXT", this.item.getTitle() + "\n" + this.item.getLink());
            intent.setType("text/plain");
            startActivity(Intent.createChooser(intent, getResources().getString(R.string.share_header)));
            return true;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_share, menu);
        onMenuItemsSet(menu);
        return true;
    }
}

package com.thedaw.uiuians.providers.rss;

import android.text.Html;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.thedaw.uiuians.billing.Constants;
import org.jsoup.Jsoup;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class RSSHandler extends DefaultHandler {
    private State currentState = State.unknown;
    private RSSFeed feed;
    private RSSItem item;
    private boolean itemFound = false;
    private StringBuilder tagContent;

    public enum State {
        unknown,
        title,
        description,
        link,
        pubdate,
        media
    }

    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
    public void startDocument() throws SAXException {
        this.feed = new RSSFeed();
        this.item = new RSSItem();
    }

    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
    public void startElement(String str, String str2, String str3, Attributes attributes) throws SAXException {
        this.currentState = State.unknown;
        this.tagContent = new StringBuilder();
        if (str2.equalsIgnoreCase("item") || str2.equalsIgnoreCase("entry")) {
            this.itemFound = true;
            this.item = new RSSItem();
            this.currentState = State.unknown;
        } else if (str3.equalsIgnoreCase("title")) {
            this.currentState = State.title;
        } else if (str3.equalsIgnoreCase(Constants.RESPONSE_DESCRIPTION) || str3.equalsIgnoreCase("content:encoded") || str3.equalsIgnoreCase(FirebaseAnalytics.Param.CONTENT)) {
            this.currentState = State.description;
        } else if (str3.equalsIgnoreCase("link") || str3.equalsIgnoreCase("origLink")) {
            this.currentState = State.link;
        } else if (str3.equalsIgnoreCase("pubdate") || str3.equalsIgnoreCase("published")) {
            this.currentState = State.pubdate;
        } else if (str3.equalsIgnoreCase("media:thumbnail")) {
            this.currentState = State.media;
            this.item.setThumburl(attributes.getValue("url"));
        } else if (str3.equalsIgnoreCase("media:content")) {
            this.currentState = State.media;
            String value = attributes.getValue("url");
            if (attributes.getValue("type") != null && attributes != null) {
                if (attributes.getValue("type").startsWith("image")) {
                    this.item.setThumburl(value);
                } else if (attributes.getValue("type").startsWith(MimeTypes.BASE_TYPE_VIDEO)) {
                    this.item.setVideourl(value);
                } else if (attributes.getValue("type").startsWith(MimeTypes.BASE_TYPE_AUDIO)) {
                    this.item.setAudiourl(value);
                }
            }
        } else if (str3.equalsIgnoreCase("enclosure")) {
            this.currentState = State.media;
            String value2 = attributes.getValue("url");
            if (attributes.getValue("type").startsWith("image")) {
                this.item.setThumburl(value2);
            } else if (attributes.getValue("type").startsWith(MimeTypes.BASE_TYPE_VIDEO)) {
                this.item.setVideourl(value2);
            } else if (attributes.getValue("type").startsWith(MimeTypes.BASE_TYPE_AUDIO)) {
                this.item.setAudiourl(value2);
            }
        }
    }

    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
    public void endElement(String str, String str2, String str3) throws SAXException {
        if (str2.equalsIgnoreCase("item") || str2.equalsIgnoreCase("entry")) {
            this.feed.addItem(this.item);
        }
        if (this.itemFound) {
            switch (this.currentState) {
                case title:
                    this.item.setTitle(Html.fromHtml(this.tagContent.toString().trim()).toString());
                    return;
                case description:
                    this.item.setDescription(this.tagContent.toString());
                    if (this.item.getThumburl() == null || this.item.getThumburl().equals("")) {
                        this.item.setThumburl(Jsoup.parse(this.tagContent.toString()).select("img").attr("src"));
                        return;
                    }
                    return;
                case link:
                    this.item.setLink(this.tagContent.toString());
                    return;
                case pubdate:
                    this.item.setPubdate(this.tagContent.toString());
                    return;
                case media:
                default:
                    return;
            }
        } else {
            switch (this.currentState) {
                case title:
                    this.feed.setTitle(this.tagContent.toString());
                    return;
                case description:
                    this.feed.setDescription(this.tagContent.toString());
                    return;
                case link:
                    this.feed.setLink(this.tagContent.toString());
                    return;
                case pubdate:
                    this.feed.setPubdate(this.tagContent.toString());
                    return;
                default:
                    return;
            }
        }
    }

    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
    public void characters(char[] cArr, int i, int i2) throws SAXException {
        this.tagContent.append(cArr, i, i2);
    }

    public RSSFeed getFeed() {
        return this.feed;
    }
}

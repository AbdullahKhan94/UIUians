package com.thedaw.uiuians.providers.radio.metadata;

import android.net.Uri;
import com.google.android.exoplayer2.upstream.DataSourceException;
import com.google.android.exoplayer2.upstream.DataSpec;
import com.google.android.exoplayer2.upstream.HttpDataSource;
import com.google.android.exoplayer2.upstream.TransferListener;
import com.google.android.exoplayer2.util.Assertions;
import com.google.android.exoplayer2.util.Predicate;
import io.fabric.sdk.android.services.network.HttpRequest;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import okhttp3.CacheControl;
import okhttp3.Call;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

final class ShoutcastDataSource implements HttpDataSource, MetadataListener {
    private static final String AAC = "audio/aac";
    private static final String AACP = "audio/aacp";
    private static final String ICY_METADATA = "Icy-Metadata";
    private static final String ICY_METAINT = "icy-metaint";
    private static final String MP3 = "audio/mpeg";
    private static final String OGG = "application/ogg";
    private static final AtomicReference<byte[]> skipBufferReference = new AtomicReference<>();
    private long bytesRead;
    private long bytesSkipped;
    private long bytesToRead;
    private long bytesToSkip;
    private final CacheControl cacheControl;
    private final Call.Factory callFactory;
    private final Predicate<String> contentTypePredicate;
    private DataSpec dataSpec;
    private IcyHeader icyHeader;
    private boolean opened;
    private final HashMap<String, String> requestProperties;
    private Response response;
    private InputStream responseByteStream;
    private final ShoutcastMetadataListener shoutcastMetadataListener;
    private final TransferListener<? super ShoutcastDataSource> transferListener;
    private final String userAgent;

    /* access modifiers changed from: private */
    public class IcyHeader {
        public String bitrate;
        public String channels;
        public String genre;
        public String station;
        public String url;

        private IcyHeader() {
        }
    }

    public ShoutcastDataSource(Call.Factory factory, String str, Predicate<String> predicate) {
        this(factory, str, predicate, null, null);
    }

    private ShoutcastDataSource(Call.Factory factory, String str, Predicate<String> predicate, TransferListener<? super ShoutcastDataSource> transferListener2, ShoutcastMetadataListener shoutcastMetadataListener2) {
        this(factory, str, predicate, transferListener2, shoutcastMetadataListener2, null);
    }

    public ShoutcastDataSource(Call.Factory factory, String str, Predicate<String> predicate, TransferListener<? super ShoutcastDataSource> transferListener2, ShoutcastMetadataListener shoutcastMetadataListener2, CacheControl cacheControl2) {
        this.callFactory = (Call.Factory) Assertions.checkNotNull(factory);
        this.userAgent = Assertions.checkNotEmpty(str);
        this.contentTypePredicate = predicate;
        this.transferListener = transferListener2;
        this.shoutcastMetadataListener = shoutcastMetadataListener2;
        this.cacheControl = cacheControl2;
        this.requestProperties = new HashMap<>();
    }

    @Override // com.google.android.exoplayer2.upstream.DataSource
    public Uri getUri() {
        if (this.response == null) {
            return null;
        }
        return Uri.parse(this.response.request().url().toString());
    }

    @Override // com.google.android.exoplayer2.upstream.HttpDataSource
    public Map<String, List<String>> getResponseHeaders() {
        if (this.response == null) {
            return null;
        }
        return this.response.headers().toMultimap();
    }

    @Override // com.google.android.exoplayer2.upstream.HttpDataSource
    public void setRequestProperty(String str, String str2) {
        Assertions.checkNotNull(str);
        Assertions.checkNotNull(str2);
        synchronized (this.requestProperties) {
            this.requestProperties.put(str, str2);
        }
    }

    @Override // com.google.android.exoplayer2.upstream.HttpDataSource
    public void clearRequestProperty(String str) {
        Assertions.checkNotNull(str);
        synchronized (this.requestProperties) {
            this.requestProperties.remove(str);
        }
    }

    @Override // com.google.android.exoplayer2.upstream.HttpDataSource
    public void clearAllRequestProperties() {
        synchronized (this.requestProperties) {
            this.requestProperties.clear();
        }
    }

    @Override // com.google.android.exoplayer2.upstream.HttpDataSource, com.google.android.exoplayer2.upstream.DataSource
    public long open(DataSpec dataSpec2) throws HttpDataSource.HttpDataSourceException {
        this.dataSpec = dataSpec2;
        long j = 0;
        this.bytesRead = 0;
        this.bytesSkipped = 0;
        setRequestProperty(ICY_METADATA, "1");
        Request makeRequest = makeRequest(dataSpec2);
        try {
            this.response = this.callFactory.newCall(makeRequest).execute();
            this.responseByteStream = getInputStream(this.response);
            int code = this.response.code();
            if (!this.response.isSuccessful()) {
                Map<String, List<String>> multimap = makeRequest.headers().toMultimap();
                closeConnectionQuietly();
                HttpDataSource.InvalidResponseCodeException invalidResponseCodeException = new HttpDataSource.InvalidResponseCodeException(code, multimap, dataSpec2);
                if (code == 416) {
                    invalidResponseCodeException.initCause(new DataSourceException(0));
                }
                throw invalidResponseCodeException;
            }
            MediaType contentType = this.response.body().contentType();
            String mediaType = contentType != null ? contentType.toString() : null;
            if (this.contentTypePredicate == null || this.contentTypePredicate.evaluate(mediaType)) {
                if (code == 200 && dataSpec2.position != 0) {
                    j = dataSpec2.position;
                }
                this.bytesToSkip = j;
                long j2 = -1;
                if (dataSpec2.length != -1) {
                    this.bytesToRead = dataSpec2.length;
                } else {
                    long contentLength = this.response.body().contentLength();
                    if (contentLength != -1) {
                        j2 = contentLength - this.bytesToSkip;
                    }
                    this.bytesToRead = j2;
                }
                this.opened = true;
                if (this.transferListener != null) {
                    this.transferListener.onTransferStart(this, dataSpec2);
                }
                return this.bytesToRead;
            }
            closeConnectionQuietly();
            throw new HttpDataSource.InvalidContentTypeException(mediaType, dataSpec2);
        } catch (IOException e) {
            throw new HttpDataSource.HttpDataSourceException("Unable to connect to " + dataSpec2.uri.toString(), e, dataSpec2, 1);
        }
    }

    @Override // com.google.android.exoplayer2.upstream.HttpDataSource, com.google.android.exoplayer2.upstream.DataSource
    public int read(byte[] bArr, int i, int i2) throws HttpDataSource.HttpDataSourceException {
        try {
            skipInternal();
            return readInternal(bArr, i, i2);
        } catch (IOException e) {
            throw new HttpDataSource.HttpDataSourceException(e, this.dataSpec, 2);
        }
    }

    @Override // com.google.android.exoplayer2.upstream.HttpDataSource, com.google.android.exoplayer2.upstream.DataSource
    public void close() throws HttpDataSource.HttpDataSourceException {
        if (this.opened) {
            this.opened = false;
            if (this.transferListener != null) {
                this.transferListener.onTransferEnd(this);
            }
            closeConnectionQuietly();
        }
    }

    private Request makeRequest(DataSpec dataSpec2) {
        boolean z = true;
        if ((dataSpec2.flags & 1) == 0) {
            z = false;
        }
        Request.Builder url = new Request.Builder().url(HttpUrl.parse(dataSpec2.uri.toString()));
        if (this.cacheControl != null) {
            url.cacheControl(this.cacheControl);
        }
        synchronized (this.requestProperties) {
            for (Map.Entry<String, String> entry : this.requestProperties.entrySet()) {
                url.addHeader(entry.getKey(), entry.getValue());
            }
        }
        url.addHeader("User-Agent", this.userAgent);
        if (!z) {
            url.addHeader(HttpRequest.HEADER_ACCEPT_ENCODING, "identity");
        }
        if (dataSpec2.postBody != null) {
            url.post(RequestBody.create((MediaType) null, dataSpec2.postBody));
        }
        return url.build();
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x005c  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0062  */
    private InputStream getInputStream(Response response2) throws IOException {
        char c;
        String header = response2.header(HttpRequest.HEADER_CONTENT_TYPE);
        setIcyHeader(response2.headers());
        InputStream byteStream = response2.body().byteStream();
        int hashCode = header.hashCode();
        if (hashCode != -1248335792) {
            if (hashCode != 187078282) {
                if (hashCode != 1504459558) {
                    if (hashCode == 1504831518 && header.equals("audio/mpeg")) {
                        c = 0;
                        switch (c) {
                            case 0:
                            case 1:
                            case 2:
                                return new IcyInputStream(byteStream, response2.header(ICY_METAINT) == null ? 8192 : Integer.parseInt(response2.header(ICY_METAINT)), null, this);
                            case 3:
                                return new OggInputStream(byteStream, this);
                            default:
                                return byteStream;
                        }
                    }
                } else if (header.equals(AACP)) {
                    c = 2;
                    switch (c) {
                    }
                }
            } else if (header.equals(AAC)) {
                c = 1;
                switch (c) {
                }
            }
        } else if (header.equals(OGG)) {
            c = 3;
            switch (c) {
            }
        }
        c = 65535;
        switch (c) {
        }
    }

    private void skipInternal() throws IOException {
        if (this.bytesSkipped != this.bytesToSkip) {
            byte[] andSet = skipBufferReference.getAndSet(null);
            if (andSet == null) {
                andSet = new byte[4096];
            }
            while (this.bytesSkipped != this.bytesToSkip) {
                int read = this.responseByteStream.read(andSet, 0, (int) Math.min(this.bytesToSkip - this.bytesSkipped, (long) andSet.length));
                if (Thread.interrupted()) {
                    throw new InterruptedIOException();
                } else if (read == -1) {
                    throw new EOFException();
                } else {
                    this.bytesSkipped += (long) read;
                    if (this.transferListener != null) {
                        this.transferListener.onBytesTransferred(this, read);
                    }
                }
            }
            skipBufferReference.set(andSet);
        }
    }

    private int readInternal(byte[] bArr, int i, int i2) throws IOException {
        if (i2 == 0) {
            return 0;
        }
        if (this.bytesToRead != -1) {
            long j = this.bytesToRead - this.bytesRead;
            if (j == 0) {
                return -1;
            }
            i2 = (int) Math.min((long) i2, j);
        }
        int read = this.responseByteStream.read(bArr, i, i2);
        if (read != -1) {
            this.bytesRead += (long) read;
            if (this.transferListener != null) {
                this.transferListener.onBytesTransferred(this, read);
            }
            return read;
        } else if (this.bytesToRead == -1) {
            return -1;
        } else {
            throw new EOFException();
        }
    }

    private void closeConnectionQuietly() {
        this.response.body().close();
        this.response = null;
        this.responseByteStream = null;
    }

    private void setIcyHeader(Headers headers) {
        if (this.icyHeader == null) {
            this.icyHeader = new IcyHeader();
        }
        this.icyHeader.station = headers.get("icy-name");
        this.icyHeader.url = headers.get("icy-url");
        this.icyHeader.genre = headers.get("icy-genre");
        this.icyHeader.channels = headers.get("icy-channels");
        this.icyHeader.bitrate = headers.get("icy-br");
    }

    @Override // com.thedaw.uiuians.providers.radio.metadata.MetadataListener
    public void onMetadataReceived(String str, String str2, String str3) {
        if (this.shoutcastMetadataListener != null) {
            this.shoutcastMetadataListener.onMetadataReceived(new Metadata(str, str2, str3, this.icyHeader.channels, this.icyHeader.bitrate, this.icyHeader.station, this.icyHeader.genre, this.icyHeader.url));
        }
    }
}

package com.thedaw.uiuians.providers.radio.metadata;

public interface ShoutcastMetadataListener {
    void onMetadataReceived(Metadata metadata);
}

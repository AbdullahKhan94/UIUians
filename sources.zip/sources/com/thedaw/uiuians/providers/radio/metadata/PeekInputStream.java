package com.thedaw.uiuians.providers.radio.metadata;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

class PeekInputStream extends InputStream {
    private static final byte[] SCRATCH_SPACE = new byte[4096];
    private byte[] peekBuffer;
    private int peekBufferLength;
    private int peekBufferPosition;
    private long position;
    private final InputStream stream;
    private final long streamLength;

    PeekInputStream(InputStream inputStream) {
        this(inputStream, 0, -1);
    }

    private PeekInputStream(InputStream inputStream, long j, long j2) {
        this.peekBuffer = new byte[8192];
        this.stream = inputStream;
        this.position = j;
        this.streamLength = j2;
    }

    @Override // java.io.InputStream
    public int read() throws IOException {
        int readFromPeekBuffer = readFromPeekBuffer();
        if (readFromPeekBuffer == 0) {
            try {
                readFromPeekBuffer = readFromStream();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        commitBytesRead(readFromPeekBuffer);
        return readFromPeekBuffer;
    }

    @Override // java.io.InputStream
    public int read(byte[] bArr, int i, int i2) throws IOException {
        int i3;
        int readFromPeekBuffer = readFromPeekBuffer(bArr, i, i2);
        if (readFromPeekBuffer == 0) {
            try {
                i3 = readFromStream(bArr, i, i2, 0, true);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            commitBytesRead(i3);
            return i3;
        }
        i3 = readFromPeekBuffer;
        commitBytesRead(i3);
        return i3;
    }

    private boolean readFully(byte[] bArr, int i, int i2, boolean z) throws IOException, InterruptedException {
        int readFromPeekBuffer = readFromPeekBuffer(bArr, i, i2);
        while (readFromPeekBuffer < i2 && readFromPeekBuffer != -1) {
            readFromPeekBuffer = readFromStream(bArr, i, i2, readFromPeekBuffer, z);
        }
        commitBytesRead(readFromPeekBuffer);
        return readFromPeekBuffer != -1;
    }

    public void readFully(byte[] bArr, int i, int i2) throws IOException, InterruptedException {
        readFully(bArr, i, i2, false);
    }

    public int skip(int i) throws IOException, InterruptedException {
        int skipFromPeekBuffer = skipFromPeekBuffer(i);
        if (skipFromPeekBuffer == 0) {
            skipFromPeekBuffer = readFromStream(SCRATCH_SPACE, 0, Math.min(i, SCRATCH_SPACE.length), 0, true);
        }
        commitBytesRead(skipFromPeekBuffer);
        return skipFromPeekBuffer;
    }

    private boolean skipFully(int i, boolean z) throws IOException, InterruptedException {
        int skipFromPeekBuffer = skipFromPeekBuffer(i);
        while (skipFromPeekBuffer < i && skipFromPeekBuffer != -1) {
            skipFromPeekBuffer = readFromStream(SCRATCH_SPACE, -skipFromPeekBuffer, Math.min(i, SCRATCH_SPACE.length + skipFromPeekBuffer), skipFromPeekBuffer, z);
        }
        commitBytesRead(skipFromPeekBuffer);
        return skipFromPeekBuffer != -1;
    }

    public void skipFully(int i) throws IOException, InterruptedException {
        skipFully(i, false);
    }

    /* access modifiers changed from: package-private */
    public boolean peekFully(byte[] bArr, int i, int i2, boolean z) throws IOException, InterruptedException {
        if (!advancePeekPosition(i2, z)) {
            return false;
        }
        System.arraycopy(this.peekBuffer, this.peekBufferPosition - i2, bArr, i, i2);
        return true;
    }

    /* access modifiers changed from: package-private */
    public void peekFully(byte[] bArr, int i, int i2) throws IOException, InterruptedException {
        peekFully(bArr, i, i2, false);
    }

    private boolean advancePeekPosition(int i, boolean z) throws IOException, InterruptedException {
        ensureSpaceForPeek(i);
        int min = Math.min(this.peekBufferLength - this.peekBufferPosition, i);
        this.peekBufferLength += i - min;
        int i2 = min;
        while (i2 < i) {
            i2 = readFromStream(this.peekBuffer, this.peekBufferPosition, i, i2, z);
            if (i2 == -1) {
                return false;
            }
        }
        this.peekBufferPosition += i;
        return true;
    }

    public void advancePeekPosition(int i) throws IOException, InterruptedException {
        advancePeekPosition(i, false);
    }

    public void resetPeekPosition() {
        this.peekBufferPosition = 0;
    }

    public long getPeekPosition() {
        return this.position + ((long) this.peekBufferPosition);
    }

    public long getPosition() {
        return this.position;
    }

    public long getLength() {
        return this.streamLength;
    }

    private void ensureSpaceForPeek(int i) {
        int i2 = this.peekBufferPosition + i;
        if (i2 > this.peekBuffer.length) {
            this.peekBuffer = Arrays.copyOf(this.peekBuffer, Math.max(this.peekBuffer.length * 2, i2));
        }
    }

    private int skipFromPeekBuffer(int i) {
        int min = Math.min(this.peekBufferLength, i);
        updatePeekBuffer(min);
        return min;
    }

    private int readFromPeekBuffer() {
        if (this.peekBufferLength == 0) {
            return 0;
        }
        byte b = this.peekBuffer[0];
        updatePeekBuffer(1);
        return b;
    }

    private int readFromPeekBuffer(byte[] bArr, int i, int i2) {
        if (this.peekBufferLength == 0) {
            return 0;
        }
        int min = Math.min(this.peekBufferLength, i2);
        System.arraycopy(this.peekBuffer, 0, bArr, i, min);
        updatePeekBuffer(min);
        return min;
    }

    private void updatePeekBuffer(int i) {
        this.peekBufferLength -= i;
        this.peekBufferPosition = 0;
        System.arraycopy(this.peekBuffer, i, this.peekBuffer, 0, this.peekBufferLength);
    }

    private int readFromStream() throws InterruptedException, IOException {
        if (!Thread.interrupted()) {
            return this.stream.read();
        }
        throw new InterruptedException();
    }

    private int readFromStream(byte[] bArr, int i, int i2, int i3, boolean z) throws InterruptedException, IOException {
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        int read = this.stream.read(bArr, i + i3, i2 - i3);
        if (read != -1) {
            return i3 + read;
        }
        if (i3 == 0 && z) {
            return -1;
        }
        throw new EOFException();
    }

    private void commitBytesRead(int i) {
        if (i != -1) {
            this.position += (long) i;
        }
    }
}

package com.thedaw.uiuians.providers.radio.metadata;

public class Metadata {
    private final String artist;
    private final String bitrate;
    private final String channels;
    private final String genre;
    private final String show;
    private final String song;
    private final String station;
    private final String url;

    public Metadata(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8) {
        this.artist = str;
        this.song = str2;
        this.show = str3;
        this.channels = str4;
        this.bitrate = str5;
        this.station = str6;
        this.genre = str7;
        this.url = str8;
    }

    public String getArtist() {
        return this.artist;
    }

    public String getSong() {
        return this.song;
    }

    public String getShow() {
        return this.show;
    }

    public String getChannels() {
        return this.channels;
    }

    public String getBitrate() {
        return this.bitrate;
    }

    public String getStation() {
        return this.station;
    }

    public String getGenre() {
        return this.genre;
    }

    public String getUrl() {
        return this.url;
    }
}

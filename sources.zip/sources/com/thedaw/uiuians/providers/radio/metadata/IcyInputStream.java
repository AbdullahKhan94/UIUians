package com.thedaw.uiuians.providers.radio.metadata;

import android.support.annotation.NonNull;
import android.util.Log;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class IcyInputStream extends FilterInputStream {
    private static final String TAG = "com.thedaw.uiuians.providers.radio.metadata.IcyInputStream";
    private final String characterEncoding;
    private final int interval;
    private final MetadataListener metadataListener;
    private int remaining;

    private IcyInputStream(InputStream inputStream, int i, MetadataListener metadataListener2) {
        this(inputStream, i, null, metadataListener2);
    }

    public IcyInputStream(InputStream inputStream, int i, String str, MetadataListener metadataListener2) {
        super(inputStream);
        this.interval = i;
        this.characterEncoding = str == null ? "UTF-8" : str;
        this.metadataListener = metadataListener2;
        this.remaining = i;
    }

    @Override // java.io.FilterInputStream, java.io.InputStream
    public int read() throws IOException {
        int read = super.read();
        int i = this.remaining - 1;
        this.remaining = i;
        if (i == 0) {
            getMetadata();
        }
        return read;
    }

    @Override // java.io.FilterInputStream, java.io.InputStream
    public int read(@NonNull byte[] bArr, int i, int i2) throws IOException {
        InputStream inputStream = ((FilterInputStream) this).in;
        if (this.remaining < i2) {
            i2 = this.remaining;
        }
        int read = inputStream.read(bArr, i, i2);
        if (this.remaining == read) {
            getMetadata();
        } else {
            this.remaining -= read;
        }
        return read;
    }

    private int readFully(byte[] bArr, int i, int i2) throws IOException {
        int i3 = i;
        while (i2 > 0) {
            int read = this.in.read(bArr, i3, i2);
            if (read == -1) {
                break;
            }
            i3 += read;
            i2 -= read;
        }
        return i3 - i;
    }

    private void getMetadata() throws IOException {
        this.remaining = this.interval;
        int read = ((FilterInputStream) this).in.read();
        if (read >= 1) {
            int i = read * 16;
            byte[] bArr = new byte[i];
            int readFully = readFully(bArr, 0, i);
            int i2 = 0;
            while (true) {
                if (i2 < readFully) {
                    if (bArr[i2] == 0) {
                        readFully = i2;
                        break;
                    }
                    i2++;
                }
            }
            try {
                String str = new String(bArr, 0, readFully, this.characterEncoding);
                String str2 = TAG;
                Log.d(str2, "Metadata string: " + str);
                parseMetadata(str);
            } catch (Exception unused) {
                Log.e(TAG, "Cannot convert bytes to String");
            }
        }
    }

    private void parseMetadata(String str) {
        Matcher matcher = Pattern.compile("StreamTitle='([^;]*)'").matcher(str.trim());
        if (matcher.find()) {
            String[] split = matcher.group(1).split(" - ");
            switch (split.length) {
                case 1:
                    metadataReceived(null, null, split[0]);
                    return;
                case 2:
                    metadataReceived(split[0], split[1], null);
                    return;
                case 3:
                    metadataReceived(split[1], split[2], split[0]);
                    return;
                default:
                    return;
            }
        }
    }

    private void metadataReceived(String str, String str2, String str3) {
        Log.i(TAG, "Metadata received: ");
        String str4 = TAG;
        Log.i(str4, "Show: " + str3);
        String str5 = TAG;
        Log.i(str5, "Artist: " + str);
        String str6 = TAG;
        Log.i(str6, "Song: " + str2);
        if (this.metadataListener != null) {
            this.metadataListener.onMetadataReceived(str, str2, str3);
        }
    }
}

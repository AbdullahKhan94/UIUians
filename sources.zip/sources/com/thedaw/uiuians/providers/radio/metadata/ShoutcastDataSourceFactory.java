package com.thedaw.uiuians.providers.radio.metadata;

import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.HttpDataSource;
import com.google.android.exoplayer2.upstream.TransferListener;
import okhttp3.CacheControl;
import okhttp3.Call;

public final class ShoutcastDataSourceFactory extends HttpDataSource.BaseFactory {
    private final CacheControl cacheControl;
    private final Call.Factory callFactory;
    private final ShoutcastMetadataListener shoutcastMetadataListener;
    private final TransferListener<? super DataSource> transferListener;
    private final String userAgent;

    public ShoutcastDataSourceFactory(Call.Factory factory, String str, TransferListener<? super DataSource> transferListener2, ShoutcastMetadataListener shoutcastMetadataListener2) {
        this(factory, str, transferListener2, shoutcastMetadataListener2, null);
    }

    private ShoutcastDataSourceFactory(Call.Factory factory, String str, TransferListener<? super DataSource> transferListener2, ShoutcastMetadataListener shoutcastMetadataListener2, CacheControl cacheControl2) {
        this.callFactory = factory;
        this.userAgent = str;
        this.transferListener = transferListener2;
        this.shoutcastMetadataListener = shoutcastMetadataListener2;
        this.cacheControl = cacheControl2;
    }

    /* access modifiers changed from: protected */
    @Override // com.google.android.exoplayer2.upstream.HttpDataSource.BaseFactory
    public HttpDataSource createDataSourceInternal(HttpDataSource.RequestProperties requestProperties) {
        return new ShoutcastDataSource(this.callFactory, this.userAgent, null, this.transferListener, this.shoutcastMetadataListener, this.cacheControl);
    }
}

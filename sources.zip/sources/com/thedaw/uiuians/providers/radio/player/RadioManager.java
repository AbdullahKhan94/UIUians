package com.thedaw.uiuians.providers.radio.player;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.thedaw.uiuians.providers.radio.StaticEventDistributor;
import com.thedaw.uiuians.providers.radio.player.RadioService;
import com.thedaw.uiuians.util.Log;

public class RadioManager {
    private static RadioManager instance;
    private static RadioService service;
    private boolean serviceBound = false;
    private ServiceConnection serviceConnection = new ServiceConnection() {
        /* class com.thedaw.uiuians.providers.radio.player.RadioManager.AnonymousClass1 */

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            RadioService unused = RadioManager.service = ((RadioService.LocalBinder) iBinder).getService();
            RadioManager.this.serviceBound = true;
        }

        public void onServiceDisconnected(ComponentName componentName) {
            RadioManager.this.serviceBound = false;
        }
    };

    private RadioManager() {
    }

    public static RadioManager with() {
        if (instance == null) {
            instance = new RadioManager();
        }
        return instance;
    }

    public static RadioService getService() {
        return service;
    }

    public void playOrPause(String str) {
        if (str == null) {
            service.stop();
        } else {
            service.playOrPause(str);
        }
    }

    public boolean isPlaying() {
        return service.isPlaying();
    }

    public void bind(Context context) {
        if (!this.serviceBound) {
            Intent intent = new Intent(context, RadioService.class);
            context.startService(intent);
            context.bindService(intent, this.serviceConnection, 1);
            if (service != null) {
                StaticEventDistributor.onEvent(service.getStatus());
            }
        }
    }

    public void unbind(Context context) {
        if (this.serviceBound) {
            try {
                service.stop();
                context.unbindService(this.serviceConnection);
                context.stopService(new Intent(context, RadioService.class));
                this.serviceBound = false;
            } catch (IllegalArgumentException e) {
                Log.printStackTrace(e);
            }
        }
    }
}

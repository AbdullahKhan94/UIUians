package com.thedaw.uiuians.providers.radio.player;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaButtonReceiver;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.audio.AudioRendererEventListener;
import com.google.android.exoplayer2.decoder.DecoderCounters;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.exoplayer2.util.Util;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.radio.StaticEventDistributor;
import com.thedaw.uiuians.providers.radio.metadata.Metadata;
import com.thedaw.uiuians.providers.radio.metadata.ShoutcastDataSourceFactory;
import com.thedaw.uiuians.providers.radio.metadata.ShoutcastMetadataListener;
import com.thedaw.uiuians.providers.radio.parser.AlbumArtGetter;
import okhttp3.OkHttpClient;

public class RadioService extends Service implements ExoPlayer.EventListener, AudioManager.OnAudioFocusChangeListener, ShoutcastMetadataListener {
    public static final String ACTION_PAUSE = "com.sherdle.universal.radio.ACTION_PAUSE";
    public static final String ACTION_PLAY = "com.sherdle.universal.radio.ACTION_PLAY";
    public static final String ACTION_STOP = "com.sherdle.universal.radio.ACTION_STOP";
    private AudioManager audioManager;
    private BroadcastReceiver becomingNoisyReceiver = new BroadcastReceiver() {
        /* class com.thedaw.uiuians.providers.radio.player.RadioService.AnonymousClass1 */

        public void onReceive(Context context, Intent intent) {
            RadioService.this.pause();
        }
    };
    private SimpleExoPlayer exoPlayer;
    private Handler handler;
    private final IBinder iBinder = new LocalBinder();
    private MediaSessionCompat mediaSession;
    private MediaSessionCompat.Callback mediasSessionCallback = new MediaSessionCompat.Callback() {
        /* class com.thedaw.uiuians.providers.radio.player.RadioService.AnonymousClass3 */

        @Override // android.support.v4.media.session.MediaSessionCompat.Callback
        public void onPause() {
            super.onPause();
            RadioService.this.pause();
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.Callback
        public void onStop() {
            super.onStop();
            RadioService.this.stop();
            RadioService.this.notificationManager.cancelNotify();
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.Callback
        public void onPlay() {
            super.onPlay();
            RadioService.this.resume();
        }
    };
    private MediaNotificationManager notificationManager;
    private boolean onGoingCall = false;
    private PhoneStateListener phoneStateListener = new PhoneStateListener() {
        /* class com.thedaw.uiuians.providers.radio.player.RadioService.AnonymousClass2 */

        public void onCallStateChanged(int i, String str) {
            if (i == 2 || i == 1) {
                if (RadioService.this.isPlaying()) {
                    RadioService.this.onGoingCall = true;
                    RadioService.this.stop();
                }
            } else if (i == 0 && RadioService.this.onGoingCall) {
                RadioService.this.onGoingCall = false;
                RadioService.this.resume();
            }
        }
    };
    private boolean serviceInUse = false;
    private String status;
    private String strAppName;
    private String strLiveBroadcast;
    private String streamUrl;
    private TelephonyManager telephonyManager;
    private MediaControllerCompat.TransportControls transportControls;
    private WifiManager.WifiLock wifiLock;

    @Override // com.google.android.exoplayer2.ExoPlayer.EventListener
    public void onLoadingChanged(boolean z) {
    }

    @Override // com.google.android.exoplayer2.ExoPlayer.EventListener
    public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {
    }

    @Override // com.google.android.exoplayer2.ExoPlayer.EventListener
    public void onPositionDiscontinuity() {
    }

    public void onRepeatModeChanged(int i) {
    }

    @Override // com.google.android.exoplayer2.ExoPlayer.EventListener
    public void onTimelineChanged(Timeline timeline, Object obj) {
    }

    @Override // com.google.android.exoplayer2.ExoPlayer.EventListener
    public void onTracksChanged(TrackGroupArray trackGroupArray, TrackSelectionArray trackSelectionArray) {
    }

    public class LocalBinder extends Binder {
        public LocalBinder() {
        }

        public RadioService getService() {
            return RadioService.this;
        }
    }

    @Nullable
    public IBinder onBind(Intent intent) {
        this.serviceInUse = true;
        return this.iBinder;
    }

    public void onCreate() {
        super.onCreate();
        this.strAppName = getResources().getString(R.string.app_name);
        this.strLiveBroadcast = getResources().getString(R.string.notification_playing);
        this.onGoingCall = false;
        this.audioManager = (AudioManager) getSystemService(MimeTypes.BASE_TYPE_AUDIO);
        this.notificationManager = new MediaNotificationManager(this);
        this.wifiLock = ((WifiManager) getApplicationContext().getSystemService("wifi")).createWifiLock(1, "mcScPAmpLock");
        this.mediaSession = new MediaSessionCompat(this, getClass().getSimpleName(), new ComponentName(getApplicationContext(), MediaButtonReceiver.class), null);
        this.transportControls = this.mediaSession.getController().getTransportControls();
        this.mediaSession.setActive(true);
        this.mediaSession.setFlags(3);
        this.mediaSession.setMetadata(new MediaMetadataCompat.Builder().putString(MediaMetadataCompat.METADATA_KEY_ARTIST, "...").putString(MediaMetadataCompat.METADATA_KEY_ALBUM, this.strAppName).putString(MediaMetadataCompat.METADATA_KEY_TITLE, this.strLiveBroadcast).build());
        this.mediaSession.setCallback(this.mediasSessionCallback);
        this.telephonyManager = (TelephonyManager) getSystemService("phone");
        this.telephonyManager.listen(this.phoneStateListener, 32);
        this.handler = new Handler();
        this.exoPlayer = ExoPlayerFactory.newSimpleInstance(getApplicationContext(), new DefaultTrackSelector(new AdaptiveTrackSelection.Factory(new DefaultBandwidthMeter())));
        this.exoPlayer.addListener(this);
        this.exoPlayer.setAudioDebugListener(new AudioRendererEventListener() {
            /* class com.thedaw.uiuians.providers.radio.player.RadioService.AnonymousClass4 */

            @Override // com.google.android.exoplayer2.audio.AudioRendererEventListener
            public void onAudioDecoderInitialized(String str, long j, long j2) {
            }

            @Override // com.google.android.exoplayer2.audio.AudioRendererEventListener
            public void onAudioDisabled(DecoderCounters decoderCounters) {
            }

            @Override // com.google.android.exoplayer2.audio.AudioRendererEventListener
            public void onAudioEnabled(DecoderCounters decoderCounters) {
            }

            @Override // com.google.android.exoplayer2.audio.AudioRendererEventListener
            public void onAudioInputFormatChanged(Format format) {
            }

            @Override // com.google.android.exoplayer2.audio.AudioRendererEventListener
            public void onAudioTrackUnderrun(int i, long j, long j2) {
            }

            @Override // com.google.android.exoplayer2.audio.AudioRendererEventListener
            public void onAudioSessionId(int i) {
                StaticEventDistributor.onAudioSessionId(Integer.valueOf(RadioService.this.getAudioSessionId()));
            }
        });
        this.exoPlayer.setPlayWhenReady(true);
        registerReceiver(this.becomingNoisyReceiver, new IntentFilter("android.media.AUDIO_BECOMING_NOISY"));
        this.status = PlaybackStatus.IDLE;
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        String action = intent.getAction();
        if (TextUtils.isEmpty(action)) {
            return 2;
        }
        if (this.audioManager.requestAudioFocus(this, 3, 1) != 1) {
            stop();
            return 2;
        }
        if (action.equalsIgnoreCase(ACTION_PLAY)) {
            this.transportControls.play();
        } else if (action.equalsIgnoreCase(ACTION_PAUSE)) {
            this.transportControls.pause();
        } else if (action.equalsIgnoreCase(ACTION_STOP)) {
            this.transportControls.stop();
        }
        return 2;
    }

    public boolean onUnbind(Intent intent) {
        this.serviceInUse = false;
        if (this.status.equals(PlaybackStatus.IDLE)) {
            stopSelf();
        }
        return super.onUnbind(intent);
    }

    public void onRebind(Intent intent) {
        this.serviceInUse = true;
    }

    public void onDestroy() {
        pause();
        this.exoPlayer.release();
        this.exoPlayer.removeListener(this);
        if (this.telephonyManager != null) {
            this.telephonyManager.listen(this.phoneStateListener, 0);
        }
        this.notificationManager.cancelNotify();
        this.mediaSession.release();
        unregisterReceiver(this.becomingNoisyReceiver);
        super.onDestroy();
    }

    public void onAudioFocusChange(int i) {
        if (i != 1) {
            switch (i) {
                case -3:
                    if (isPlaying()) {
                        this.exoPlayer.setVolume(0.1f);
                        return;
                    }
                    return;
                case -2:
                    if (isPlaying()) {
                        pause();
                        return;
                    }
                    return;
                case -1:
                    stop();
                    return;
                default:
                    return;
            }
        } else {
            this.exoPlayer.setVolume(0.8f);
            resume();
        }
    }

    @Override // com.google.android.exoplayer2.ExoPlayer.EventListener
    public void onPlayerStateChanged(boolean z, int i) {
        switch (i) {
            case 1:
                this.status = PlaybackStatus.IDLE;
                break;
            case 2:
                this.status = PlaybackStatus.LOADING;
                break;
            case 3:
                this.status = z ? PlaybackStatus.PLAYING : PlaybackStatus.PAUSED;
                break;
            case 4:
                this.status = PlaybackStatus.STOPPED;
                break;
            default:
                this.status = PlaybackStatus.IDLE;
                break;
        }
        if (!this.status.equals(PlaybackStatus.IDLE)) {
            this.notificationManager.startNotify(this.status);
        }
        StaticEventDistributor.onEvent(this.status);
    }

    @Override // com.google.android.exoplayer2.ExoPlayer.EventListener
    public void onPlayerError(ExoPlaybackException exoPlaybackException) {
        StaticEventDistributor.onEvent(PlaybackStatus.ERROR);
    }

    public String getStreamUrl() {
        return this.streamUrl;
    }

    public void play(String str) {
        this.streamUrl = str;
        if (this.wifiLock != null && !this.wifiLock.isHeld()) {
            this.wifiLock.acquire();
        }
        this.exoPlayer.prepare(new ExtractorMediaSource(Uri.parse(str), new ShoutcastDataSourceFactory(new OkHttpClient.Builder().build(), Util.getUserAgent(this, getClass().getSimpleName()), new DefaultBandwidthMeter(), this), new DefaultExtractorsFactory(), this.handler, null));
        this.exoPlayer.setPlayWhenReady(true);
    }

    public int getAudioSessionId() {
        return this.exoPlayer.getAudioSessionId();
    }

    public void resume() {
        if (this.streamUrl != null) {
            play(this.streamUrl);
        }
    }

    public void pause() {
        this.exoPlayer.setPlayWhenReady(false);
        this.audioManager.abandonAudioFocus(this);
        wifiLockRelease();
    }

    public void stop() {
        this.exoPlayer.stop();
        this.audioManager.abandonAudioFocus(this);
        wifiLockRelease();
    }

    public void playOrPause(String str) {
        if (this.streamUrl == null || !this.streamUrl.equals(str)) {
            if (isPlaying()) {
                pause();
            }
            play(str);
        } else if (!isPlaying()) {
            play(this.streamUrl);
        } else {
            pause();
        }
    }

    public String getStatus() {
        return this.status;
    }

    @Override // com.thedaw.uiuians.providers.radio.metadata.ShoutcastMetadataListener
    public void onMetadataReceived(final Metadata metadata) {
        AlbumArtGetter.getImageForQuery(metadata.getArtist() + " " + metadata.getSong(), new AlbumArtGetter.AlbumCallback() {
            /* class com.thedaw.uiuians.providers.radio.player.RadioService.AnonymousClass5 */

            @Override // com.thedaw.uiuians.providers.radio.parser.AlbumArtGetter.AlbumCallback
            public void finished(Bitmap bitmap) {
                RadioService.this.notificationManager.startNotify(bitmap, metadata);
                StaticEventDistributor.onMetaDataReceived(metadata, bitmap);
            }
        }, this);
    }

    public Metadata getMetaData() {
        return this.notificationManager.getMetaData();
    }

    public MediaSessionCompat getMediaSession() {
        return this.mediaSession;
    }

    public boolean isPlaying() {
        return this.status.equals(PlaybackStatus.PLAYING);
    }

    private void wifiLockRelease() {
        if (this.wifiLock != null && this.wifiLock.isHeld()) {
            this.wifiLock.release();
        }
    }
}

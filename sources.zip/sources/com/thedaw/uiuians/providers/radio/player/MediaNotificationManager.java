package com.thedaw.uiuians.providers.radio.player;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.media.app.NotificationCompat;
import com.google.android.gms.common.util.CrashUtils;
import com.onesignal.OneSignalDbContract;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.radio.metadata.Metadata;
import com.thedaw.uiuians.providers.radio.ui.RadioFragment;

public class MediaNotificationManager {
    public static final String NOTIFICATION_CHANNEL_ID = "radio_channel";
    public static final int NOTIFICATION_ID = 555;
    private Metadata meta;
    private Bitmap notifyIcon;
    private String playbackStatus;
    private Resources resources;
    private RadioService service;

    public MediaNotificationManager(RadioService radioService) {
        this.service = radioService;
        this.resources = radioService.getResources();
    }

    public void startNotify(String str) {
        this.playbackStatus = str;
        this.notifyIcon = BitmapFactory.decodeResource(this.resources, R.drawable.ic_launcher);
        startNotify();
    }

    public void startNotify(Bitmap bitmap, Metadata metadata) {
        this.notifyIcon = bitmap;
        this.meta = metadata;
        startNotify();
    }

    private void startNotify() {
        if (this.playbackStatus != null) {
            if (this.notifyIcon == null) {
                this.notifyIcon = BitmapFactory.decodeResource(this.resources, R.drawable.ic_launcher);
            }
            NotificationManager notificationManager = (NotificationManager) this.service.getSystemService(OneSignalDbContract.NotificationTable.TABLE_NAME);
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, this.service.getString(R.string.audio_notification), 2);
                notificationChannel.enableVibration(false);
                notificationManager.createNotificationChannel(notificationChannel);
            }
            int i = R.drawable.ic_pause_white;
            Intent intent = new Intent(this.service, RadioService.class);
            intent.setAction(RadioService.ACTION_PAUSE);
            PendingIntent service2 = PendingIntent.getService(this.service, 1, intent, 0);
            if (this.playbackStatus.equals(PlaybackStatus.PAUSED)) {
                i = R.drawable.ic_play_white;
                intent.setAction(RadioService.ACTION_PLAY);
                service2 = PendingIntent.getService(this.service, 2, intent, 0);
            }
            Intent intent2 = new Intent(this.service, RadioService.class);
            intent2.setAction(RadioService.ACTION_STOP);
            PendingIntent service3 = PendingIntent.getService(this.service, 3, intent2, 0);
            Intent intent3 = new Intent(this.service, HolderActivity.class);
            Bundle bundle = new Bundle();
            bundle.putStringArray(MainActivity.FRAGMENT_DATA, new String[]{this.service.getStreamUrl()});
            bundle.putSerializable(MainActivity.FRAGMENT_CLASS, RadioFragment.class);
            intent3.putExtras(bundle);
            intent3.addFlags(CrashUtils.ErrorDialogData.BINDER_CRASH);
            PendingIntent activity = PendingIntent.getActivity(this.service, 0, intent3, CrashUtils.ErrorDialogData.BINDER_CRASH);
            NotificationManagerCompat.from(this.service).cancel(NOTIFICATION_ID);
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this.service, NOTIFICATION_CHANNEL_ID);
            builder.setContentTitle((this.meta == null || this.meta.getArtist() == null) ? this.resources.getString(R.string.notification_playing) : this.meta.getArtist()).setContentText((this.meta == null || this.meta.getSong() == null) ? this.resources.getString(R.string.app_name) : this.meta.getSong()).setLargeIcon(this.notifyIcon).setContentIntent(activity).setVisibility(1).setSmallIcon(R.drawable.ic_radio_playing).addAction(i, "pause", service2).addAction(R.drawable.ic_stop, "stop", service3).setPriority(1).setWhen(System.currentTimeMillis()).setStyle(new NotificationCompat.MediaStyle().setMediaSession(this.service.getMediaSession().getSessionToken()).setShowActionsInCompactView(0, 1).setShowCancelButton(true).setCancelButtonIntent(service3));
            this.service.startForeground(NOTIFICATION_ID, builder.build());
        }
    }

    public Metadata getMetaData() {
        return this.meta;
    }

    public void cancelNotify() {
        this.service.stopForeground(true);
    }
}

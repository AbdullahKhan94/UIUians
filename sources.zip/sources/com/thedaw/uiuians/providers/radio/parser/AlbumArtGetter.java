package com.thedaw.uiuians.providers.radio.parser;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import java.net.URLEncoder;
import org.json.JSONException;
import org.json.JSONObject;

public class AlbumArtGetter {

    public interface AlbumCallback {
        void finished(Bitmap bitmap);
    }

    public static void getImageForQuery(final String str, final AlbumCallback albumCallback, Context context) {
        new AsyncTask<Void, Void, String>() {
            /* class com.thedaw.uiuians.providers.radio.parser.AlbumArtGetter.AnonymousClass1 */

            /* access modifiers changed from: protected */
            public String doInBackground(Void... voidArr) {
                if (str.equals("null+null") || URLEncoder.encode(str).equals("null+null")) {
                    return null;
                }
                JSONObject jSONObjectFromUrl = Helper.getJSONObjectFromUrl("https://itunes.apple.com/search?term=" + URLEncoder.encode(str) + "&media=music&limit=1");
                if (jSONObjectFromUrl != null) {
                    try {
                        if (jSONObjectFromUrl.has("results") && jSONObjectFromUrl.getJSONArray("results").length() > 0) {
                            return jSONObjectFromUrl.getJSONArray("results").getJSONObject(0).getString("artworkUrl100").replace("100x100bb.jpg", "500x500bb.jpg");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        return null;
                    }
                }
                Log.v("INFO", "No items in Album Art Request");
                return null;
            }

            /* access modifiers changed from: protected */
            public void onPostExecute(String str) {
                if (str != null) {
                    Picasso.get().load(str).into(new Target() {
                        /* class com.thedaw.uiuians.providers.radio.parser.AlbumArtGetter.AnonymousClass1.AnonymousClass1 */

                        @Override // com.squareup.picasso.Target
                        public void onPrepareLoad(Drawable drawable) {
                        }

                        @Override // com.squareup.picasso.Target
                        public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom loadedFrom) {
                            albumCallback.finished(bitmap);
                        }

                        @Override // com.squareup.picasso.Target
                        public void onBitmapFailed(Exception exc, Drawable drawable) {
                            albumCallback.finished(null);
                        }
                    });
                } else {
                    albumCallback.finished(null);
                }
            }
        }.execute(new Void[0]);
    }
}

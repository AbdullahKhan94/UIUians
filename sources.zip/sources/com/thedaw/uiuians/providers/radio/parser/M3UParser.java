package com.thedaw.uiuians.providers.radio.parser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.LinkedList;

public class M3UParser {
    public LinkedList<String> getRawUrl(String str) {
        LinkedList<String> linkedList = new LinkedList<>();
        try {
            return getRawUrl(getConnection(str));
        } catch (IOException | MalformedURLException unused) {
            linkedList.add(str);
            return linkedList;
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:3|4|(1:16)(3:7|(2:11|19)|15)) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0013 */
    /* JADX WARNING: Removed duplicated region for block: B:3:0x0013 A[LOOP:0: B:3:0x0013->B:15:0x0013, LOOP_START, SYNTHETIC, Splitter:B:3:0x0013] */
    public LinkedList<String> getRawUrl(URLConnection uRLConnection) {
        LinkedList<String> linkedList = new LinkedList<>();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(uRLConnection.getInputStream()));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                String parseLine = parseLine(readLine);
                if (parseLine != null && !parseLine.equals("")) {
                    linkedList.add(parseLine);
                }
            }
        } catch (IOException | MalformedURLException unused) {
        }
        linkedList.add(uRLConnection.getURL().toString());
        return linkedList;
    }

    private String parseLine(String str) {
        if (str == null) {
            return null;
        }
        String trim = str.trim();
        return trim.indexOf("http") >= 0 ? trim.substring(trim.indexOf("http")) : "";
    }

    private URLConnection getConnection(String str) throws IOException {
        return new URL(str).openConnection();
    }
}

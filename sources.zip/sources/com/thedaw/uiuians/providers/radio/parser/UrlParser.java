package com.thedaw.uiuians.providers.radio.parser;

import android.annotation.SuppressLint;
import com.thedaw.uiuians.util.Log;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.LinkedList;

public class UrlParser {
    @SuppressLint({"DefaultLocale"})
    public static String getUrl(String str) {
        String upperCase = str.toUpperCase();
        if (upperCase.endsWith(".FLAC") || upperCase.endsWith(".MP3") || upperCase.endsWith(".WAV") || upperCase.endsWith(".M4A") || upperCase.endsWith(".PLS")) {
            return str;
        }
        if (upperCase.endsWith(".M3U")) {
            LinkedList<String> rawUrl = new M3UParser().getRawUrl(str);
            if (rawUrl.size() > 0) {
                return rawUrl.get(0);
            }
        } else if (upperCase.endsWith(".ASX")) {
            LinkedList<String> rawUrl2 = new ASXParser().getRawUrl(str);
            if (rawUrl2.size() > 0) {
                return rawUrl2.get(0);
            }
        } else {
            URLConnection connection = getConnection(str);
            if (connection != null) {
                String headerField = connection.getHeaderField("Content-Disposition");
                Log.v("INFO", "Requesting: " + str + " Headers: " + connection.getHeaderFields());
                String contentType = connection.getContentType();
                if (contentType != null) {
                    contentType = contentType.toUpperCase();
                }
                if (headerField != null && headerField.toUpperCase().endsWith("M3U")) {
                    LinkedList<String> rawUrl3 = new M3UParser().getRawUrl(connection);
                    if (rawUrl3.size() > 0) {
                        return rawUrl3.getFirst();
                    }
                } else if (contentType != null && contentType.contains("AUDIO/X-SCPLS")) {
                    return str;
                } else {
                    if (contentType != null && contentType.contains("VIDEO/X-MS-ASF")) {
                        LinkedList<String> rawUrl4 = new ASXParser().getRawUrl(str);
                        if (rawUrl4.size() > 0) {
                            return rawUrl4.get(0);
                        }
                        LinkedList<String> rawUrl5 = new PLSParser().getRawUrl(str);
                        if (rawUrl5.size() > 0) {
                            return rawUrl5.get(0);
                        }
                    } else if ((contentType == null || !contentType.contains("AUDIO/MPEG")) && contentType != null && contentType.contains("AUDIO/X-MPEGURL")) {
                        LinkedList<String> rawUrl6 = new M3UParser().getRawUrl(str);
                        if (rawUrl6.size() > 0) {
                            return rawUrl6.get(0);
                        }
                    }
                }
            }
        }
        return str;
    }

    private static URLConnection getConnection(String str) {
        try {
            return new URL(str).openConnection();
        } catch (IOException | MalformedURLException unused) {
            return null;
        }
    }
}

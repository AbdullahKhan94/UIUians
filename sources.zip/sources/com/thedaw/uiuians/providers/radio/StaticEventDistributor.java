package com.thedaw.uiuians.providers.radio;

import android.graphics.Bitmap;
import com.thedaw.uiuians.providers.radio.metadata.Metadata;
import java.util.ArrayList;
import java.util.Iterator;

public class StaticEventDistributor {
    private static ArrayList<EventListener> listeners;

    public interface EventListener {
        void onAudioSessionId(Integer num);

        void onEvent(String str);

        void onMetaDataReceived(Metadata metadata, Bitmap bitmap);
    }

    public static void registerAsListener(EventListener eventListener) {
        if (listeners == null) {
            listeners = new ArrayList<>();
        }
        listeners.add(eventListener);
    }

    public static void unregisterAsListener(EventListener eventListener) {
        listeners.remove(eventListener);
    }

    public static void onEvent(String str) {
        if (listeners != null) {
            Iterator<EventListener> it = listeners.iterator();
            while (it.hasNext()) {
                it.next().onEvent(str);
            }
        }
    }

    public static void onAudioSessionId(Integer num) {
        if (listeners != null) {
            Iterator<EventListener> it = listeners.iterator();
            while (it.hasNext()) {
                it.next().onAudioSessionId(num);
            }
        }
    }

    public static void onMetaDataReceived(Metadata metadata, Bitmap bitmap) {
        if (listeners != null) {
            Iterator<EventListener> it = listeners.iterator();
            while (it.hasNext()) {
                it.next().onMetaDataReceived(metadata, bitmap);
            }
        }
    }
}

package com.thedaw.uiuians.providers.radio.ui;

import android.app.Activity;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.cleveroad.audiovisualization.AudioVisualization;
import com.cleveroad.audiovisualization.DbmHandler;
import com.google.android.exoplayer2.util.MimeTypes;
import com.thedaw.uiuians.Config;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.inherit.CollapseControllingFragment;
import com.thedaw.uiuians.inherit.PermissionsFragment;
import com.thedaw.uiuians.providers.radio.StaticEventDistributor;
import com.thedaw.uiuians.providers.radio.metadata.Metadata;
import com.thedaw.uiuians.providers.radio.parser.UrlParser;
import com.thedaw.uiuians.providers.radio.player.PlaybackStatus;
import com.thedaw.uiuians.providers.radio.player.RadioManager;
import com.thedaw.uiuians.util.Helper;

public class RadioFragment extends Fragment implements View.OnClickListener, PermissionsFragment, CollapseControllingFragment, StaticEventDistributor.EventListener {
    private ImageView albumArtView;
    private String[] arguments;
    private AudioVisualization audioVisualization;
    private FloatingActionButton buttonPlayPause;
    private RelativeLayout layout;
    private ProgressBar loadingIndicator;
    private Activity mAct;
    private RadioManager radioManager;
    private String urlToPlay;

    @Override // com.thedaw.uiuians.inherit.CollapseControllingFragment
    public boolean dynamicToolbarElevation() {
        return false;
    }

    @Override // com.thedaw.uiuians.inherit.CollapseControllingFragment
    public boolean supportsCollapse() {
        return false;
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.layout = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_radio, viewGroup, false);
        initializeUIElements();
        this.arguments = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        if (!Config.VISUALIZER_ENABLED) {
            this.albumArtView.setVisibility(0);
            this.albumArtView.setImageResource(Config.BACKGROUND_IMAGE_ID);
        }
        return this.layout;
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        Helper.isOnlineShowDialog(this.mAct);
        this.radioManager = RadioManager.with();
        this.loadingIndicator.setVisibility(0);
        AsyncTask.execute(new Runnable() {
            /* class com.thedaw.uiuians.providers.radio.ui.RadioFragment.AnonymousClass1 */

            public void run() {
                RadioFragment.this.urlToPlay = UrlParser.getUrl(RadioFragment.this.arguments[0]);
                RadioFragment.this.mAct.runOnUiThread(new Runnable() {
                    /* class com.thedaw.uiuians.providers.radio.ui.RadioFragment.AnonymousClass1.AnonymousClass1 */

                    public void run() {
                        RadioFragment.this.loadingIndicator.setVisibility(4);
                        RadioFragment.this.updateButtons();
                    }
                });
            }
        });
        if (isPlaying()) {
            onAudioSessionId(Integer.valueOf(RadioManager.getService().getAudioSessionId()));
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0029  */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x0030  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x003d  */
    @Override // com.thedaw.uiuians.providers.radio.StaticEventDistributor.EventListener
    public void onEvent(String str) {
        char c;
        int hashCode = str.hashCode();
        if (hashCode != -1435314966) {
            if (hashCode == -906175178 && str.equals(PlaybackStatus.ERROR)) {
                c = 1;
                switch (c) {
                    case 0:
                        this.loadingIndicator.setVisibility(0);
                        break;
                    case 1:
                        makeSnackbar(R.string.error_retry);
                        break;
                }
                if (!str.equals(PlaybackStatus.LOADING)) {
                    this.loadingIndicator.setVisibility(4);
                }
                updateButtons();
            }
        } else if (str.equals(PlaybackStatus.LOADING)) {
            c = 0;
            switch (c) {
            }
            if (!str.equals(PlaybackStatus.LOADING)) {
            }
            updateButtons();
        }
        c = 65535;
        switch (c) {
        }
        if (!str.equals(PlaybackStatus.LOADING)) {
        }
        updateButtons();
    }

    @Override // com.thedaw.uiuians.providers.radio.StaticEventDistributor.EventListener
    public void onAudioSessionId(Integer num) {
        if (Config.VISUALIZER_ENABLED) {
            this.audioVisualization.linkTo(DbmHandler.Factory.newVisualizerHandler(getContext(), num.intValue()));
            this.audioVisualization.onResume();
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onStart() {
        super.onStart();
        StaticEventDistributor.registerAsListener(this);
    }

    @Override // android.support.v4.app.Fragment
    public void onStop() {
        StaticEventDistributor.unregisterAsListener(this);
        super.onStop();
    }

    @Override // android.support.v4.app.Fragment
    public void onDestroy() {
        if (!this.radioManager.isPlaying()) {
            this.radioManager.unbind(getContext());
        }
        this.audioVisualization.release();
        super.onDestroy();
    }

    @Override // android.support.v4.app.Fragment
    public void onPause() {
        super.onPause();
        this.audioVisualization.onPause();
    }

    @Override // android.support.v4.app.Fragment
    public void onResume() {
        super.onResume();
        updateButtons();
        this.radioManager.bind(getContext());
        if (this.audioVisualization != null) {
            this.audioVisualization.onResume();
        }
    }

    private void initializeUIElements() {
        this.loadingIndicator = (ProgressBar) this.layout.findViewById(R.id.progressBar);
        this.loadingIndicator.setMax(100);
        this.loadingIndicator.setVisibility(0);
        this.albumArtView = (ImageView) this.layout.findViewById(R.id.albumArt);
        this.audioVisualization = (AudioVisualization) this.layout.findViewById(R.id.visualizer_view);
        this.buttonPlayPause = (FloatingActionButton) this.layout.findViewById(R.id.btn_play_pause);
        this.buttonPlayPause.setOnClickListener(this);
        updateButtons();
    }

    public void updateButtons() {
        if (!isPlaying() && this.loadingIndicator.getVisibility() != 0) {
            this.buttonPlayPause.setImageResource(R.drawable.exomedia_ic_play_arrow_white);
            this.layout.findViewById(R.id.already_playing_tooltip).setVisibility(8);
            updateMediaInfoFromBackground(null, null);
        } else if (RadioManager.getService() == null || this.urlToPlay == null || this.urlToPlay.equals(RadioManager.getService().getStreamUrl())) {
            if (!(RadioManager.getService() == null || RadioManager.getService().getMetaData() == null)) {
                onMetaDataReceived(RadioManager.getService().getMetaData(), null);
            }
            this.buttonPlayPause.setImageResource(R.drawable.exomedia_ic_pause_white);
            this.layout.findViewById(R.id.already_playing_tooltip).setVisibility(8);
        } else {
            this.buttonPlayPause.setImageResource(R.drawable.exomedia_ic_play_arrow_white);
            this.layout.findViewById(R.id.already_playing_tooltip).setVisibility(0);
        }
    }

    public void onClick(View view) {
        if (isPlaying()) {
            startStopPlaying();
        } else if (this.urlToPlay != null) {
            startStopPlaying();
            if (((AudioManager) this.mAct.getSystemService(MimeTypes.BASE_TYPE_AUDIO)).getStreamVolume(3) < 2) {
                makeSnackbar(R.string.volume_low);
            }
        } else {
            makeSnackbar(R.string.error_retry_later);
        }
    }

    private void startStopPlaying() {
        this.radioManager.playOrPause(this.urlToPlay);
        updateButtons();
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }

    public void updateMediaInfoFromBackground(String str, Bitmap bitmap) {
        TextView textView = (TextView) this.layout.findViewById(R.id.now_playing_title);
        TextView textView2 = (TextView) this.layout.findViewById(R.id.now_playing);
        if (str != null) {
            textView2.setText(str);
        }
        if (str != null && textView.getVisibility() == 8) {
            textView.setVisibility(0);
            textView2.setVisibility(0);
        } else if (str == null) {
            textView.setVisibility(8);
            textView2.setVisibility(8);
        }
        if (Config.VISUALIZER_ENABLED) {
            return;
        }
        if (bitmap != null) {
            this.albumArtView.setImageBitmap(bitmap);
        } else {
            this.albumArtView.setImageResource(Config.BACKGROUND_IMAGE_ID);
        }
    }

    @Override // com.thedaw.uiuians.inherit.PermissionsFragment
    public String[] requiredPermissions() {
        if (Config.VISUALIZER_ENABLED) {
            return new String[]{"android.permission.RECORD_AUDIO", "android.permission.READ_PHONE_STATE"};
        }
        return new String[]{"android.permission.READ_PHONE_STATE"};
    }

    @Override // com.thedaw.uiuians.providers.radio.StaticEventDistributor.EventListener
    public void onMetaDataReceived(Metadata metadata, Bitmap bitmap) {
        String str;
        if (metadata == null || metadata.getArtist() == null) {
            str = null;
        } else {
            str = metadata.getArtist() + " - " + metadata.getSong();
        }
        updateMediaInfoFromBackground(str, bitmap);
    }

    private boolean isPlaying() {
        return (this.radioManager == null || RadioManager.getService() == null || !RadioManager.getService().isPlaying()) ? false : true;
    }

    private void makeSnackbar(int i) {
        Snackbar make = Snackbar.make(this.buttonPlayPause, i, -1);
        make.show();
        ((TextView) make.getView().findViewById(R.id.snackbar_text)).setTextColor(getResources().getColor(R.color.white));
    }
}

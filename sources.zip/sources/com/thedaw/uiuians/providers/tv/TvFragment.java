package com.thedaw.uiuians.providers.tv;

import android.app.Activity;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.devbrackets.android.exomedia.listener.OnPreparedListener;
import com.devbrackets.android.exomedia.listener.VideoControlsVisibilityListener;
import com.devbrackets.android.exomedia.ui.widget.VideoView;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.inherit.BackPressFragment;
import com.thedaw.uiuians.inherit.CollapseControllingFragment;
import com.thedaw.uiuians.inherit.ConfigurationChangeFragment;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import com.thedaw.uiuians.util.ThemeUtils;
import com.thedaw.uiuians.util.layout.CustomAppBarLayout;

public class TvFragment extends Fragment implements CollapseControllingFragment, BackPressFragment, ConfigurationChangeFragment, OnPreparedListener {
    private Activity mAct;
    private RelativeLayout rl;
    private boolean systemUIHidden = false;
    private VideoView videoView;

    @Override // com.thedaw.uiuians.inherit.CollapseControllingFragment
    public boolean dynamicToolbarElevation() {
        return false;
    }

    @Override // com.thedaw.uiuians.inherit.CollapseControllingFragment
    public boolean supportsCollapse() {
        return false;
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.rl = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_tv, viewGroup, false);
        this.videoView = (VideoView) this.rl.findViewById(R.id.video_view);
        return this.rl;
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        setRetainInstance(true);
        Helper.isOnlineShowDialog(this.mAct);
        String str = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        initCustomControls();
        this.videoView.setOnPreparedListener(this);
        this.videoView.setVideoURI(Uri.parse(str));
    }

    public void initCustomControls() {
        VideoControlsCustom videoControlsCustom = new VideoControlsCustom(this.mAct);
        videoControlsCustom.hideSeekBar();
        FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(this.mAct).inflate(R.layout.listview_slider_chip, (ViewGroup) null);
        frameLayout.setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.tv.TvFragment.AnonymousClass1 */

            public void onClick(View view) {
                if (TvFragment.this.systemUIHidden) {
                    TvFragment.this.showSystemUI();
                } else {
                    TvFragment.this.hideSystemUI();
                }
            }
        });
        ((TextView) frameLayout.findViewById(R.id.category_chip)).setText(getString(R.string.toggle_fullscreen));
        ((TextView) frameLayout.findViewById(R.id.category_chip_number)).setVisibility(8);
        videoControlsCustom.addExtraView(frameLayout);
        videoControlsCustom.setVisibilityListener(new ControlsVisibilityListener());
        this.videoView.setControls(videoControlsCustom);
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }

    @Override // android.support.v4.app.Fragment
    public void onPause() {
        super.onPause();
        this.videoView.pause();
    }

    @Override // android.support.v4.app.Fragment
    public void onDestroy() {
        super.onDestroy();
        this.videoView.stopPlayback();
        showSystemUI();
    }

    @Override // com.thedaw.uiuians.inherit.BackPressFragment
    public boolean handleBackPress() {
        if (!this.systemUIHidden) {
            return false;
        }
        showSystemUI();
        return true;
    }

    @Override // com.devbrackets.android.exomedia.listener.OnPreparedListener
    public void onPrepared() {
        this.videoView.start();
    }

    /* access modifiers changed from: private */
    public class ControlsVisibilityListener implements VideoControlsVisibilityListener {
        @Override // com.devbrackets.android.exomedia.listener.VideoControlsVisibilityListener
        public void onControlsHidden() {
        }

        @Override // com.devbrackets.android.exomedia.listener.VideoControlsVisibilityListener
        public void onControlsShown() {
        }

        private ControlsVisibilityListener() {
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void hideSystemUI() {
        if (this.mAct instanceof MainActivity) {
            if (!((MainActivity) this.mAct).useTabletMenu()) {
                ((MainActivity) this.mAct).drawer.setFitsSystemWindows(false);
                RelativeLayout relativeLayout = (RelativeLayout) this.mAct.findViewById(R.id.drawer_child);
                DrawerLayout.LayoutParams layoutParams = (DrawerLayout.LayoutParams) relativeLayout.getLayoutParams();
                layoutParams.setMargins(0, 0, 0, 0);
                relativeLayout.setLayoutParams(layoutParams);
            } else {
                this.mAct.findViewById(R.id.nav_view).setVisibility(8);
            }
        }
        getActivity().getWindow().addFlags(1152);
        View decorView = this.mAct.getWindow().getDecorView();
        if (Build.VERSION.SDK_INT >= 19) {
            decorView.setSystemUiVisibility(3846);
        } else if (Build.VERSION.SDK_INT >= 16) {
            decorView.setSystemUiVisibility(1798);
        }
        ((AppCompatActivity) getActivity()).getSupportActionBar().hide();
        this.mAct.findViewById(R.id.adView).setVisibility(8);
        this.systemUIHidden = true;
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void showSystemUI() {
        try {
            if (this.mAct instanceof MainActivity) {
                if (!((MainActivity) this.mAct).useTabletMenu()) {
                    ((MainActivity) this.mAct).drawer.setFitsSystemWindows(true);
                } else {
                    this.mAct.findViewById(R.id.nav_view).setVisibility(0);
                    this.mAct.getWindow().addFlags(67108864);
                    ((CustomAppBarLayout) ((MainActivity) this.mAct).mToolbar.getParent()).setPadding(0, (int) Math.ceil((double) (getResources().getDisplayMetrics().density * 25.0f)), 0, 0);
                }
            }
            getActivity().getWindow().clearFlags(1152);
            if (Build.VERSION.SDK_INT >= 16) {
                View decorView = this.mAct.getWindow().getDecorView();
                decorView.setSystemUiVisibility(256);
                if (Build.VERSION.SDK_INT >= 23 && ThemeUtils.lightToolbarThemeActive(this.mAct)) {
                    decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() | 8192);
                }
            }
            ((AppCompatActivity) getActivity()).getSupportActionBar().show();
            Helper.admobLoader(this.mAct, this.mAct.findViewById(R.id.adView));
            this.systemUIHidden = false;
        } catch (NullPointerException e) {
            Log.e("INFO", e.toString());
        }
    }
}

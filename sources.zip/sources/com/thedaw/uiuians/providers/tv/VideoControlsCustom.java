package com.thedaw.uiuians.providers.tv;

import android.annotation.TargetApi;
import android.content.Context;
import android.util.AttributeSet;
import com.devbrackets.android.exomedia.ui.widget.VideoControlsMobile;
import com.thedaw.uiuians.R;

public class VideoControlsCustom extends VideoControlsMobile {
    /* access modifiers changed from: protected */
    @Override // com.devbrackets.android.exomedia.ui.widget.VideoControls, com.devbrackets.android.exomedia.ui.widget.VideoControlsMobile
    public int getLayoutResource() {
        return R.layout.fragment_tv_controls;
    }

    public VideoControlsCustom(Context context) {
        super(context);
    }

    public VideoControlsCustom(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public VideoControlsCustom(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    @TargetApi(21)
    public VideoControlsCustom(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }

    public void hideSeekBar() {
        this.seekBar.setVisibility(8);
        this.currentTimeTextView.setVisibility(8);
        this.endTimeTextView.setVisibility(8);
    }
}

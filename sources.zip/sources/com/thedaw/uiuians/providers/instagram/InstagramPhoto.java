package com.thedaw.uiuians.providers.instagram;

import java.util.Date;

public class InstagramPhoto {
    public String caption;
    public int commentsCount;
    public String commentsJson;
    public Date createdTime;
    public String id;
    public String imageUrl;
    public int likesCount;
    public String link;
    public String profilePhotoUrl;
    public String type;
    public String username;
    public String videoUrl;
}

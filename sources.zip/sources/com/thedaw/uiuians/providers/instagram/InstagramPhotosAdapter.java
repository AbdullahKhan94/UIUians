package com.thedaw.uiuians.providers.instagram;

import android.content.Context;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.exoplayer2.util.MimeTypes;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.attachmentviewer.model.MediaAttachment;
import com.thedaw.uiuians.attachmentviewer.ui.AttachmentActivity;
import com.thedaw.uiuians.attachmentviewer.ui.VideoPlayerActivity;
import com.thedaw.uiuians.comments.CommentsActivity;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import com.thedaw.uiuians.util.WebHelper;
import java.util.List;
import java.util.Locale;

public class InstagramPhotosAdapter extends InfiniteRecyclerViewAdapter {
    private Context context;
    private List<InstagramPhoto> objects;

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getViewType(int i) {
        return 0;
    }

    public InstagramPhotosAdapter(Context context2, List<InstagramPhoto> list, InfiniteRecyclerViewAdapter.LoadMoreListener loadMoreListener) {
        super(context2, loadMoreListener);
        this.context = context2;
        this.objects = list;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public RecyclerView.ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        return new InstagramPhotoViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_fb_insta_row, viewGroup, false));
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public void doBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof InstagramPhotoViewHolder) {
            final InstagramPhoto instagramPhoto = this.objects.get(i);
            InstagramPhotoViewHolder instagramPhotoViewHolder = (InstagramPhotoViewHolder) viewHolder;
            instagramPhotoViewHolder.profileImg.setImageDrawable(null);
            Picasso.get().load(instagramPhoto.profilePhotoUrl).into(instagramPhotoViewHolder.profileImg);
            instagramPhotoViewHolder.userNameView.setText(instagramPhoto.username.substring(0, 1).toUpperCase(Locale.getDefault()) + instagramPhoto.username.substring(1).toLowerCase(Locale.getDefault()));
            instagramPhotoViewHolder.dateView.setText(DateUtils.getRelativeDateTimeString(this.context, instagramPhoto.createdTime.getTime(), 1000, 604800000, 524288));
            instagramPhotoViewHolder.inlineImg.setImageDrawable(null);
            Picasso.get().load(instagramPhoto.imageUrl).placeholder(R.drawable.placeholder).into(instagramPhotoViewHolder.inlineImg);
            if (instagramPhoto.type.equalsIgnoreCase(MimeTypes.BASE_TYPE_VIDEO)) {
                instagramPhotoViewHolder.inlineImgBtn.setVisibility(0);
            } else {
                instagramPhotoViewHolder.inlineImgBtn.setVisibility(8);
            }
            if (instagramPhoto.type.equalsIgnoreCase("image")) {
                instagramPhotoViewHolder.inlineImg.setOnClickListener(new View.OnClickListener() {
                    /* class com.thedaw.uiuians.providers.instagram.InstagramPhotosAdapter.AnonymousClass1 */

                    public void onClick(View view) {
                        AttachmentActivity.startActivity(InstagramPhotosAdapter.this.context, MediaAttachment.withImage(instagramPhoto.imageUrl));
                    }
                });
            } else if (instagramPhoto.type.equalsIgnoreCase(MimeTypes.BASE_TYPE_VIDEO)) {
                AnonymousClass2 r0 = new View.OnClickListener() {
                    /* class com.thedaw.uiuians.providers.instagram.InstagramPhotosAdapter.AnonymousClass2 */

                    public void onClick(View view) {
                        VideoPlayerActivity.startActivity(InstagramPhotosAdapter.this.context, instagramPhoto.videoUrl);
                    }
                };
                instagramPhotoViewHolder.inlineImgBtn.setOnClickListener(r0);
                instagramPhotoViewHolder.inlineImg.setOnClickListener(r0);
            }
            instagramPhotoViewHolder.likesCountView.setText(Helper.formatValue((double) instagramPhoto.likesCount));
            if (instagramPhoto.caption != null) {
                instagramPhotoViewHolder.descriptionView.setText(Html.fromHtml(instagramPhoto.caption));
                instagramPhotoViewHolder.descriptionView.setTextSize(2, (float) WebHelper.getTextViewFontSize(this.context));
                instagramPhotoViewHolder.descriptionView.setVisibility(0);
            } else {
                instagramPhotoViewHolder.descriptionView.setVisibility(8);
            }
            instagramPhotoViewHolder.shareBtn.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.instagram.InstagramPhotosAdapter.AnonymousClass3 */

                public void onClick(View view) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", instagramPhoto.link);
                    intent.setType("text/plain");
                    InstagramPhotosAdapter.this.context.startActivity(Intent.createChooser(intent, InstagramPhotosAdapter.this.context.getResources().getString(R.string.share_header)));
                }
            });
            instagramPhotoViewHolder.openBtn.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.instagram.InstagramPhotosAdapter.AnonymousClass4 */

                public void onClick(View view) {
                    HolderActivity.startWebViewActivity(InstagramPhotosAdapter.this.context, instagramPhoto.link, false, false, null);
                }
            });
            instagramPhotoViewHolder.commentsCountView.setText(Helper.formatValue((double) instagramPhoto.commentsCount));
            instagramPhotoViewHolder.commentsBtn.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.instagram.InstagramPhotosAdapter.AnonymousClass5 */

                public void onClick(View view) {
                    Intent intent = new Intent(InstagramPhotosAdapter.this.context, CommentsActivity.class);
                    intent.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.INSTAGRAM);
                    intent.putExtra(CommentsActivity.DATA_PARSEABLE, instagramPhoto.commentsJson);
                    intent.putExtra(CommentsActivity.DATA_ID, instagramPhoto.id);
                    InstagramPhotosAdapter.this.context.startActivity(intent);
                }
            });
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getCount() {
        return this.objects.size();
    }

    private class InstagramPhotoViewHolder extends RecyclerView.ViewHolder {
        ImageView commentsBtn;
        TextView commentsCountView;
        TextView dateView;
        TextView descriptionView;
        ImageView inlineImg;
        FloatingActionButton inlineImgBtn;
        TextView likesCountView;
        ImageView openBtn;
        ImageView profileImg;
        ImageView shareBtn;
        TextView userNameView;

        InstagramPhotoViewHolder(View view) {
            super(view);
            this.profileImg = (ImageView) view.findViewById(R.id.profile_image);
            this.userNameView = (TextView) view.findViewById(R.id.name);
            this.dateView = (TextView) view.findViewById(R.id.date);
            this.inlineImg = (ImageView) view.findViewById(R.id.photo);
            this.inlineImgBtn = (FloatingActionButton) view.findViewById(R.id.playbutton);
            this.likesCountView = (TextView) view.findViewById(R.id.like_count);
            this.descriptionView = (TextView) view.findViewById(R.id.message);
            this.descriptionView = (TextView) view.findViewById(R.id.message);
            this.shareBtn = (ImageView) view.findViewById(R.id.share);
            this.openBtn = (ImageView) view.findViewById(R.id.open);
            this.commentsBtn = (ImageView) view.findViewById(R.id.comments);
            this.commentsCountView = (TextView) view.findViewById(R.id.comments_count);
        }
    }
}

package com.thedaw.uiuians.providers.pinterest;

import java.util.Date;

/* access modifiers changed from: package-private */
public class Pin {
    public String caption;
    public int commentsCount;
    public Date createdTime;
    public String creatorImageUrl;
    public String creatorName;
    public String id;
    public String imageUrl;
    public String link;
    public int repinCount;
    public String type;
    public String videoUrl;

    Pin() {
    }
}

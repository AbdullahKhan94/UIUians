package com.thedaw.uiuians.providers.pinterest;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.attachmentviewer.model.MediaAttachment;
import com.thedaw.uiuians.attachmentviewer.ui.AttachmentActivity;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import com.thedaw.uiuians.util.WebHelper;
import java.util.List;

/* access modifiers changed from: package-private */
public class PinterestAdapter extends InfiniteRecyclerViewAdapter {
    private Context context;
    private List<Pin> objects;

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getViewType(int i) {
        return 0;
    }

    PinterestAdapter(Context context2, List<Pin> list, InfiniteRecyclerViewAdapter.LoadMoreListener loadMoreListener) {
        super(context2, loadMoreListener);
        this.objects = list;
        this.context = context2;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public RecyclerView.ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        return new PinterestViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_pinterest_row, viewGroup, false));
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public void doBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof PinterestViewHolder) {
            final Pin pin = this.objects.get(i);
            PinterestViewHolder pinterestViewHolder = (PinterestViewHolder) viewHolder;
            pinterestViewHolder.profileImg.setImageDrawable(null);
            Picasso.get().load(pin.creatorImageUrl).into(pinterestViewHolder.profileImg);
            pinterestViewHolder.userNameView.setText(pin.creatorName);
            pinterestViewHolder.dateView.setText(DateUtils.getRelativeDateTimeString(this.context, pin.createdTime.getTime(), 1000, 604800000, 524288));
            pinterestViewHolder.inlineImg.setImageDrawable(null);
            Picasso.get().load(pin.imageUrl).placeholder(R.drawable.placeholder).into(pinterestViewHolder.inlineImg);
            if (pin.type.equals("image")) {
                pinterestViewHolder.inlineImg.setOnClickListener(new View.OnClickListener() {
                    /* class com.thedaw.uiuians.providers.pinterest.PinterestAdapter.AnonymousClass1 */

                    public void onClick(View view) {
                        AttachmentActivity.startActivity(PinterestAdapter.this.context, MediaAttachment.withImage(pin.imageUrl));
                    }
                });
            } else {
                pinterestViewHolder.inlineImg.setOnClickListener(new View.OnClickListener() {
                    /* class com.thedaw.uiuians.providers.pinterest.PinterestAdapter.AnonymousClass2 */

                    public void onClick(View view) {
                        HolderActivity.startWebViewActivity(PinterestAdapter.this.context, pin.link, false, false, null);
                    }
                });
            }
            pinterestViewHolder.repinCountView.setText(Helper.formatValue((double) pin.repinCount));
            if (pin.caption != null) {
                pinterestViewHolder.descriptionView.setText(Html.fromHtml(pin.caption));
                pinterestViewHolder.descriptionView.setTextSize(2, (float) WebHelper.getTextViewFontSize(this.context));
            }
            pinterestViewHolder.shareBtn.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.pinterest.PinterestAdapter.AnonymousClass3 */

                public void onClick(View view) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", pin.link);
                    intent.setType("text/plain");
                    PinterestAdapter.this.context.startActivity(Intent.createChooser(intent, PinterestAdapter.this.context.getResources().getString(R.string.share_header)));
                }
            });
            pinterestViewHolder.openBtn.setOnClickListener(new View.OnClickListener() {
                /* class com.thedaw.uiuians.providers.pinterest.PinterestAdapter.AnonymousClass4 */

                public void onClick(View view) {
                    HolderActivity.startWebViewActivity(PinterestAdapter.this.context, pin.link, false, false, null);
                }
            });
            if (pin.commentsCount == 0) {
                pinterestViewHolder.commentsView.setVisibility(8);
                return;
            }
            pinterestViewHolder.commentsView.setVisibility(0);
            pinterestViewHolder.commentsCountView.setText(Helper.formatValue((double) pin.commentsCount));
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getCount() {
        return this.objects.size();
    }

    private class PinterestViewHolder extends RecyclerView.ViewHolder {
        TextView commentsCountView;
        ImageView commentsView;
        TextView dateView;
        TextView descriptionView;
        ImageView inlineImg;
        ImageView openBtn;
        ImageView profileImg;
        TextView repinCountView;
        ImageView shareBtn;
        TextView userNameView;

        private PinterestViewHolder(View view) {
            super(view);
            this.profileImg = (ImageView) view.findViewById(R.id.profile_image);
            this.userNameView = (TextView) view.findViewById(R.id.name);
            this.dateView = (TextView) view.findViewById(R.id.date);
            this.inlineImg = (ImageView) view.findViewById(R.id.photo);
            this.repinCountView = (TextView) view.findViewById(R.id.like_count);
            this.descriptionView = (TextView) view.findViewById(R.id.message);
            this.commentsView = (ImageView) view.findViewById(R.id.comments);
            this.commentsCountView = (TextView) view.findViewById(R.id.comments_count);
            this.shareBtn = (ImageView) view.findViewById(R.id.share);
            this.openBtn = (ImageView) view.findViewById(R.id.open);
        }
    }
}

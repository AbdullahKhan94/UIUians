package com.thedaw.uiuians.providers.maps;

import com.thedaw.uiuians.util.Log;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PlacesService {
    private String API_KEY;

    public PlacesService(String str) {
        this.API_KEY = str;
    }

    public void setApiKey(String str) {
        this.API_KEY = str;
    }

    public ArrayList<Place> findPlaces(double d, double d2, String str) {
        try {
            JSONArray jSONArray = new JSONObject(getJSON(makeUrl(d, d2, str))).getJSONArray("results");
            ArrayList<Place> arrayList = new ArrayList<>();
            for (int i = 0; i < jSONArray.length(); i++) {
                try {
                    Place jsonToPontoReferencia = Place.jsonToPontoReferencia((JSONObject) jSONArray.get(i));
                    Log.v("Places Services ", "" + jsonToPontoReferencia);
                    arrayList.add(jsonToPontoReferencia);
                } catch (Exception unused) {
                }
            }
            return arrayList;
        } catch (JSONException e) {
            Logger.getLogger(PlacesService.class.getName()).log(Level.SEVERE, (String) null, (Throwable) e);
            return null;
        }
    }

    private String makeUrl(double d, double d2, String str) {
        String str2;
        StringBuilder sb = new StringBuilder("https://maps.googleapis.com/maps/api/place/search/json?");
        try {
            str2 = URLEncoder.encode(str, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            Log.printStackTrace(e);
            str2 = "";
        }
        if (str2.equals("")) {
            sb.append("&location=");
            sb.append(Double.toString(d));
            sb.append(",");
            sb.append(Double.toString(d2));
            sb.append("&radius=1000");
            sb.append("&sensor=false&key=" + this.API_KEY);
        } else {
            sb.append("&location=");
            sb.append(Double.toString(d));
            sb.append(",");
            sb.append(Double.toString(d2));
            sb.append("&radius=1000");
            sb.append("&keyword=" + str2);
            sb.append("&sensor=false&key=" + this.API_KEY);
        }
        return sb.toString();
    }

    /* access modifiers changed from: protected */
    public String getJSON(String str) {
        return getUrlContents(str);
    }

    private String getUrlContents(String str) {
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new URL(str).openConnection().getInputStream()), 8);
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                sb.append(readLine + "\n");
            }
            bufferedReader.close();
        } catch (Exception e) {
            Log.printStackTrace(e);
        }
        return sb.toString();
    }
}

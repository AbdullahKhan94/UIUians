package com.thedaw.uiuians.providers.maps;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.maps.android.data.Geometry;
import com.google.maps.android.data.geojson.GeoJsonFeature;
import com.google.maps.android.data.geojson.GeoJsonGeometryCollection;
import com.google.maps.android.data.geojson.GeoJsonLayer;
import com.google.maps.android.data.geojson.GeoJsonLineString;
import com.google.maps.android.data.geojson.GeoJsonMultiLineString;
import com.google.maps.android.data.geojson.GeoJsonMultiPoint;
import com.google.maps.android.data.geojson.GeoJsonMultiPolygon;
import com.google.maps.android.data.geojson.GeoJsonPoint;
import com.google.maps.android.data.geojson.GeoJsonPointStyle;
import com.google.maps.android.data.geojson.GeoJsonPolygon;
import com.google.maps.android.data.kml.KmlPolygon;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.billing.Constants;
import com.thedaw.uiuians.inherit.CollapseControllingFragment;
import com.thedaw.uiuians.inherit.PermissionsFragment;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class MapsFragment extends Fragment implements PermissionsFragment, CollapseControllingFragment {
    private String[] data;
    private GoogleMap googleMap;
    private LinearLayout ll;
    private Activity mAct;
    private MapView mMapView;

    @Override // com.thedaw.uiuians.inherit.CollapseControllingFragment
    public boolean dynamicToolbarElevation() {
        return false;
    }

    @Override // android.support.v4.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
    }

    @Override // com.thedaw.uiuians.inherit.CollapseControllingFragment
    public boolean supportsCollapse() {
        return false;
    }

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreateView(layoutInflater, viewGroup, bundle);
        this.ll = (LinearLayout) layoutInflater.inflate(R.layout.fragment_maps, viewGroup, false);
        setHasOptionsMenu(true);
        this.mMapView = (MapView) this.ll.findViewById(R.id.map);
        this.mMapView.onCreate(bundle);
        this.mMapView.onResume();
        return this.ll;
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        Helper.isOnlineShowDialog(this.mAct);
        this.data = getArguments().getStringArray(MainActivity.FRAGMENT_DATA);
        MapsInitializer.initialize(this.mAct);
        this.mMapView.getMapAsync(new OnMapReadyCallback() {
            /* class com.thedaw.uiuians.providers.maps.MapsFragment.AnonymousClass1 */

            @Override // com.google.android.gms.maps.OnMapReadyCallback
            public void onMapReady(GoogleMap googleMap) {
                MapsFragment.this.googleMap = googleMap;
                if (ContextCompat.checkSelfPermission(MapsFragment.this.mAct, "android.permission.ACCESS_FINE_LOCATION") == 0) {
                    MapsFragment.this.googleMap.setMyLocationEnabled(true);
                }
                new LoadGeoData(MapsFragment.this.mAct).execute(MapsFragment.this.data);
            }
        });
    }

    @Override // android.support.v4.app.Fragment
    public void onResume() {
        super.onResume();
        this.mMapView.onResume();
    }

    @Override // android.support.v4.app.Fragment
    public void onPause() {
        super.onPause();
        this.mMapView.onPause();
    }

    @Override // android.support.v4.app.Fragment
    public void onDestroy() {
        super.onDestroy();
        this.mMapView.onDestroy();
    }

    @Override // android.support.v4.app.Fragment
    public void onLowMemory() {
        super.onLowMemory();
        this.mMapView.onLowMemory();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void focusMapOnLayer(GeoJsonLayer geoJsonLayer) {
        ArrayList<LatLng> arrayList = new ArrayList();
        for (GeoJsonFeature geoJsonFeature : geoJsonLayer.getFeatures()) {
            if (geoJsonFeature.hasGeometry()) {
                Geometry geometry = geoJsonFeature.getGeometry();
                if (geometry.getGeometryType().equals("GeometryCollection")) {
                    for (Geometry geometry2 : ((GeoJsonGeometryCollection) geometry).getGeometries()) {
                        arrayList.addAll(getCoordinatesFromGeometry(geometry2));
                    }
                } else {
                    arrayList.addAll(getCoordinatesFromGeometry(geometry));
                }
            }
        }
        LatLngBounds.Builder builder = LatLngBounds.builder();
        for (LatLng latLng : arrayList) {
            builder.include(latLng);
        }
        final LatLngBounds build = builder.build();
        this.mAct.runOnUiThread(new Runnable() {
            /* class com.thedaw.uiuians.providers.maps.MapsFragment.AnonymousClass2 */

            public void run() {
                MapsFragment.this.googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(build, 100), 500, null);
            }
        });
    }

    /* JADX INFO: Can't fix incorrect switch cases order, some code will duplicate */
    private List<LatLng> getCoordinatesFromGeometry(Geometry geometry) {
        char c;
        ArrayList arrayList = new ArrayList();
        String geometryType = geometry.getGeometryType();
        switch (geometryType.hashCode()) {
            case -2116761119:
                if (geometryType.equals("MultiPolygon")) {
                    c = 5;
                    break;
                }
                c = 65535;
                break;
            case -1065891849:
                if (geometryType.equals("MultiPoint")) {
                    c = 1;
                    break;
                }
                c = 65535;
                break;
            case -627102946:
                if (geometryType.equals("MultiLineString")) {
                    c = 3;
                    break;
                }
                c = 65535;
                break;
            case 77292912:
                if (geometryType.equals("Point")) {
                    c = 0;
                    break;
                }
                c = 65535;
                break;
            case 1267133722:
                if (geometryType.equals(KmlPolygon.GEOMETRY_TYPE)) {
                    c = 4;
                    break;
                }
                c = 65535;
                break;
            case 1806700869:
                if (geometryType.equals("LineString")) {
                    c = 2;
                    break;
                }
                c = 65535;
                break;
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                arrayList.add(((GeoJsonPoint) geometry).getCoordinates());
                break;
            case 1:
                for (GeoJsonPoint geoJsonPoint : ((GeoJsonMultiPoint) geometry).getPoints()) {
                    arrayList.add(geoJsonPoint.getCoordinates());
                }
                break;
            case 2:
                arrayList.addAll(((GeoJsonLineString) geometry).getCoordinates());
                break;
            case 3:
                for (GeoJsonLineString geoJsonLineString : ((GeoJsonMultiLineString) geometry).getLineStrings()) {
                    arrayList.addAll(geoJsonLineString.getCoordinates());
                }
                break;
            case 4:
                Iterator<? extends List<LatLng>> it = ((GeoJsonPolygon) geometry).getCoordinates().iterator();
                while (it.hasNext()) {
                    arrayList.addAll((List) it.next());
                }
                break;
            case 5:
                for (GeoJsonPolygon geoJsonPolygon : ((GeoJsonMultiPolygon) geometry).getPolygons()) {
                    Iterator<? extends List<LatLng>> it2 = geoJsonPolygon.getCoordinates().iterator();
                    while (it2.hasNext()) {
                        arrayList.addAll((List) it2.next());
                    }
                }
                break;
        }
        return arrayList;
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }

    @Override // com.thedaw.uiuians.inherit.PermissionsFragment
    public String[] requiredPermissions() {
        return new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.WRITE_EXTERNAL_STORAGE"};
    }

    private class LoadGeoData extends AsyncTask<String, String, GeoJsonLayer> {
        private Context context;
        private ProgressDialog dialog;

        public LoadGeoData(Context context2) {
            this.context = context2;
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(final GeoJsonLayer geoJsonLayer) {
            super.onPostExecute((Object) geoJsonLayer);
            if (this.dialog.isShowing()) {
                this.dialog.dismiss();
            }
            if (geoJsonLayer == null) {
                Helper.noConnection(MapsFragment.this.mAct);
            } else {
                MapsFragment.this.googleMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                    /* class com.thedaw.uiuians.providers.maps.MapsFragment.LoadGeoData.AnonymousClass1 */

                    @Override // com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener
                    public void onInfoWindowClick(Marker marker) {
                        for (GeoJsonFeature geoJsonFeature : geoJsonLayer.getFeatures()) {
                            if (geoJsonFeature.getGeometry().getGeometryType().equals("Point") && ((GeoJsonPoint) geoJsonFeature.getGeometry()).getCoordinates().equals(marker.getPosition()) && geoJsonFeature.hasProperty("url")) {
                                HolderActivity.startWebViewActivity(MapsFragment.this.mAct, geoJsonFeature.getProperty("url"), false, false, null);
                            }
                        }
                    }
                });
            }
        }

        /* access modifiers changed from: protected */
        public GeoJsonLayer doInBackground(String... strArr) {
            JSONObject jSONObject;
            if (strArr[0].startsWith("http")) {
                jSONObject = Helper.getJSONObjectFromUrl(strArr[0]);
            } else {
                try {
                    jSONObject = new JSONObject(Helper.loadJSONFromAsset(MapsFragment.this.mAct, strArr[0]));
                } catch (JSONException e) {
                    Log.e("INFO", "Error parsing JSON. Printing stacktrace now");
                    Log.printStackTrace(e);
                    jSONObject = null;
                }
            }
            if (jSONObject == null) {
                return null;
            }
            final GeoJsonLayer geoJsonLayer = new GeoJsonLayer(MapsFragment.this.googleMap, jSONObject);
            MapsFragment.this.mAct.runOnUiThread(new Runnable() {
                /* class com.thedaw.uiuians.providers.maps.MapsFragment.LoadGeoData.AnonymousClass2 */

                public void run() {
                    geoJsonLayer.addLayerToMap();
                    for (GeoJsonFeature geoJsonFeature : geoJsonLayer.getFeatures()) {
                        if (geoJsonFeature.getPointStyle() != null) {
                            GeoJsonPointStyle geoJsonPointStyle = new GeoJsonPointStyle();
                            geoJsonPointStyle.setTitle(geoJsonFeature.getProperty("name"));
                            if (geoJsonFeature.hasProperty("snippet")) {
                                geoJsonPointStyle.setSnippet(geoJsonFeature.getProperty("snippet"));
                            } else if (geoJsonFeature.hasProperty(Constants.RESPONSE_DESCRIPTION)) {
                                geoJsonPointStyle.setSnippet(geoJsonFeature.getProperty(Constants.RESPONSE_DESCRIPTION));
                            } else if (geoJsonFeature.hasProperty("popupContent")) {
                                geoJsonPointStyle.setSnippet(geoJsonFeature.getProperty("popupContent"));
                            }
                            geoJsonFeature.setPointStyle(geoJsonPointStyle);
                        }
                    }
                }
            });
            MapsFragment.this.focusMapOnLayer(geoJsonLayer);
            return geoJsonLayer;
        }

        /* access modifiers changed from: protected */
        public void onPreExecute() {
            super.onPreExecute();
            if (MapsFragment.this.data[0].startsWith("http")) {
                this.dialog = new ProgressDialog(this.context);
                this.dialog.setCancelable(true);
                this.dialog.setMessage(MapsFragment.this.getResources().getString(R.string.loading));
                this.dialog.isIndeterminate();
                this.dialog.show();
            }
        }
    }
}

package com.thedaw.uiuians.providers.maps;

import com.google.android.exoplayer2.text.ttml.TtmlNode;
import com.google.firebase.analytics.FirebaseAnalytics;
import io.fabric.sdk.android.services.settings.SettingsJsonConstants;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONException;
import org.json.JSONObject;

public class Place {
    private String icon;
    private String id;
    private Double latitude;
    private Double longitude;
    private String name;
    private String vicinity;

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getIcon() {
        return this.icon;
    }

    public void setIcon(String str) {
        this.icon = str;
    }

    public Double getLatitude() {
        return this.latitude;
    }

    public void setLatitude(Double d) {
        this.latitude = d;
    }

    public Double getLongitude() {
        return this.longitude;
    }

    public void setLongitude(Double d) {
        this.longitude = d;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getVicinity() {
        return this.vicinity;
    }

    public void setVicinity(String str) {
        this.vicinity = str;
    }

    static Place jsonToPontoReferencia(JSONObject jSONObject) {
        try {
            Place place = new Place();
            JSONObject jSONObject2 = (JSONObject) ((JSONObject) jSONObject.get("geometry")).get(FirebaseAnalytics.Param.LOCATION);
            place.setLatitude((Double) jSONObject2.get("lat"));
            place.setLongitude((Double) jSONObject2.get("lng"));
            place.setIcon(jSONObject.getString(SettingsJsonConstants.APP_ICON_KEY));
            place.setName(jSONObject.getString("name"));
            place.setVicinity(jSONObject.getString("vicinity"));
            place.setId(jSONObject.getString(TtmlNode.ATTR_ID));
            return place;
        } catch (JSONException e) {
            Logger.getLogger(Place.class.getName()).log(Level.SEVERE, (String) null, (Throwable) e);
            return null;
        }
    }

    public String toString() {
        return "Place{id=" + this.id + ", icon=" + this.icon + ", name=" + this.name + ", latitude=" + this.latitude + ", longitude=" + this.longitude + '}';
    }
}

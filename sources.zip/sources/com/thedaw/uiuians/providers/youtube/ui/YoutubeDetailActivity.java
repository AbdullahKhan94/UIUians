package com.thedaw.uiuians.providers.youtube.ui;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewStub;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.comments.CommentsActivity;
import com.thedaw.uiuians.providers.fav.FavDbAdapter;
import com.thedaw.uiuians.providers.youtube.api.object.Video;
import com.thedaw.uiuians.providers.youtube.player.YouTubePlayerActivity;
import com.thedaw.uiuians.util.DetailActivity;
import com.thedaw.uiuians.util.WebHelper;

public class YoutubeDetailActivity extends DetailActivity {
    public static final String EXTRA_VIDEO = "videoitem";
    private FavDbAdapter mDbHelper;
    private TextView mPresentation;
    private Video video;

    @Override // android.support.v4.app.SupportActivity, com.thedaw.uiuians.util.DetailActivity, android.support.v7.app.AppCompatActivity, android.support.v4.app.FragmentActivity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_details);
        ViewStub viewStub = (ViewStub) findViewById(R.id.layout_stub);
        viewStub.setLayoutResource(R.layout.activity_youtube_detail);
        viewStub.inflate();
        this.mToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(this.mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        this.mPresentation = (TextView) findViewById(R.id.youtubetitle);
        TextView textView = (TextView) findViewById(R.id.youtubedescription);
        this.video = (Video) getIntent().getSerializableExtra(EXTRA_VIDEO);
        textView.setTextSize(2, (float) WebHelper.getTextViewFontSize(this));
        this.mPresentation.setText(this.video.getTitle());
        textView.setText(this.video.getDescription());
        ((TextView) findViewById(R.id.youtubesubtitle)).setText(getResources().getString(R.string.video_subtitle_start) + this.video.getUpdated() + getResources().getString(R.string.video_subtitle_end) + this.video.getChannel());
        findViewById(R.id.adView).setVisibility(8);
        this.thumb = (ImageView) findViewById(R.id.image);
        this.coolblue = (RelativeLayout) findViewById(R.id.coolblue);
        Picasso.get().load(this.video.getImage()).into(this.thumb);
        setUpHeader(this.video.getImage());
        FloatingActionButton floatingActionButton = (FloatingActionButton) findViewById(R.id.playbutton);
        floatingActionButton.bringToFront();
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.youtube.ui.YoutubeDetailActivity.AnonymousClass1 */

            public void onClick(View view) {
                Intent intent = new Intent(YoutubeDetailActivity.this, YouTubePlayerActivity.class);
                intent.putExtra(YouTubePlayerActivity.EXTRA_VIDEO_ID, YoutubeDetailActivity.this.video.getId());
                intent.setFlags(1073741824);
                YoutubeDetailActivity.this.startActivity(intent);
            }
        });
        ((Button) findViewById(R.id.favorite)).setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.youtube.ui.YoutubeDetailActivity.AnonymousClass2 */

            public void onClick(View view) {
                YoutubeDetailActivity.this.mDbHelper = new FavDbAdapter(YoutubeDetailActivity.this);
                YoutubeDetailActivity.this.mDbHelper.open();
                if (YoutubeDetailActivity.this.mDbHelper.checkEvent(YoutubeDetailActivity.this.video.getTitle(), YoutubeDetailActivity.this.video, 4)) {
                    YoutubeDetailActivity.this.mDbHelper.addFavorite(YoutubeDetailActivity.this.video.getTitle(), YoutubeDetailActivity.this.video, 4);
                    Toast.makeText(YoutubeDetailActivity.this, YoutubeDetailActivity.this.getResources().getString(R.string.favorite_success), 1).show();
                    return;
                }
                Toast.makeText(YoutubeDetailActivity.this, YoutubeDetailActivity.this.getResources().getString(R.string.favorite_duplicate), 1).show();
            }
        });
        ((Button) findViewById(R.id.comments)).setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.youtube.ui.YoutubeDetailActivity.AnonymousClass3 */

            public void onClick(View view) {
                Intent intent = new Intent(YoutubeDetailActivity.this, CommentsActivity.class);
                intent.putExtra(CommentsActivity.DATA_TYPE, CommentsActivity.YOUTUBE);
                intent.putExtra(CommentsActivity.DATA_ID, YoutubeDetailActivity.this.video.getId());
                YoutubeDetailActivity.this.startActivity(intent);
            }
        });
    }

    @Override // com.thedaw.uiuians.util.DetailActivity, android.support.v4.app.FragmentActivity
    public void onPause() {
        super.onPause();
    }

    @Override // com.thedaw.uiuians.util.DetailActivity, android.support.v4.app.FragmentActivity
    public void onResume() {
        super.onResume();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId != 16908332) {
            switch (itemId) {
                case R.id.menu_share:
                    String string = getResources().getString(R.string.app_name);
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    String string2 = getResources().getString(R.string.video_share_begin);
                    String string3 = getResources().getString(R.string.video_share_middle);
                    String string4 = getResources().getString(R.string.video_share_end);
                    intent.putExtra("android.intent.extra.TEXT", string2 + "http://youtube.com/watch?v=" + this.video.getId() + string3 + string + string4);
                    intent.putExtra("android.intent.extra.SUBJECT", this.video.getTitle());
                    intent.setType("text/plain");
                    startActivity(Intent.createChooser(intent, getResources().getString(R.string.share_header)));
                    return true;
                case R.id.menu_view:
                    try {
                        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("vnd.youtube:" + this.video.getId())));
                    } catch (ActivityNotFoundException unused) {
                        HolderActivity.startWebViewActivity(this, "http://www.youtube.com/watch?v=" + this.video.getId(), false, false, null);
                    }
                    return true;
                default:
                    return super.onOptionsItemSelected(menuItem);
            }
        } else {
            finish();
            return true;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.youtube_detail_menu, menu);
        return true;
    }
}

package com.thedaw.uiuians.providers.youtube;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.youtube.api.object.Video;
import com.thedaw.uiuians.providers.youtube.ui.YoutubeFragment;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import com.thedaw.uiuians.util.ViewModeUtils;
import java.util.List;

public class VideosAdapter extends InfiniteRecyclerViewAdapter {
    private static final int HIGHLIGHT_VIDEO = 2;
    private static final int VIDEO_COMPACT = 0;
    private static final int VIDEO_NORMAL = 1;
    private AdapterView.OnItemClickListener clickListener;
    private Context mContext;
    private List<Video> videos;
    private ViewModeUtils viewModeUtils;

    public VideosAdapter(Context context, List<Video> list, InfiniteRecyclerViewAdapter.LoadMoreListener loadMoreListener, AdapterView.OnItemClickListener onItemClickListener) {
        super(context, loadMoreListener);
        this.mContext = context;
        this.videos = list;
        this.clickListener = onItemClickListener;
        this.viewModeUtils = new ViewModeUtils(context, YoutubeFragment.class);
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getCount() {
        return this.videos.size();
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public int getViewType(int i) {
        if (i == 0 || this.viewModeUtils.getViewMode() == 2) {
            return 2;
        }
        return this.viewModeUtils.getViewMode() == 0 ? 0 : 1;
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public RecyclerView.ViewHolder getViewHolder(ViewGroup viewGroup, int i) {
        if (i == 0) {
            return new VideoCompactViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_youtube_row, viewGroup, false));
        }
        if (i == 2) {
            HighlightViewHolder highlightViewHolder = new HighlightViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listview_highlight, viewGroup, false));
            requestFullSpan(highlightViewHolder);
            return highlightViewHolder;
        } else if (i == 1) {
            return new VideoNormalViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listview_row, viewGroup, false));
        } else {
            return null;
        }
    }

    /* access modifiers changed from: protected */
    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter
    public void doBindViewHolder(final RecyclerView.ViewHolder viewHolder, final int i) {
        Video video = this.videos.get(i);
        if (viewHolder instanceof VideoViewHolder) {
            VideoViewHolder videoViewHolder = (VideoViewHolder) viewHolder;
            videoViewHolder.thumb.setImageDrawable(null);
            Picasso.get().load(viewHolder instanceof VideoCompactViewHolder ? video.getThumbUrl() : video.getImage()).placeholder(R.color.gray).into(videoViewHolder.thumb);
            videoViewHolder.title.setText(video.getTitle());
            videoViewHolder.date.setText(video.getUpdated());
        }
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.youtube.VideosAdapter.AnonymousClass1 */

            public void onClick(View view) {
                VideosAdapter.this.clickListener.onItemClick(null, viewHolder.itemView, i, 0);
            }
        });
    }

    private static abstract class VideoViewHolder extends RecyclerView.ViewHolder {
        protected TextView date;
        protected ImageView thumb;
        protected TextView title;

        VideoViewHolder(View view) {
            super(view);
        }
    }

    class VideoCompactViewHolder extends VideoViewHolder {
        VideoCompactViewHolder(View view) {
            super(view);
            this.title = (TextView) view.findViewById(R.id.userVideoTitleTextView);
            this.date = (TextView) view.findViewById(R.id.userVideoDateTextView);
            this.thumb = (ImageView) view.findViewById(R.id.userVideoThumbImageView);
        }
    }

    private static class VideoNormalViewHolder extends VideoViewHolder {
        VideoNormalViewHolder(View view) {
            super(view);
            this.title = (TextView) view.findViewById(R.id.title);
            this.date = (TextView) view.findViewById(R.id.date);
            this.thumb = (ImageView) view.findViewById(R.id.thumbImage);
        }
    }

    private static class HighlightViewHolder extends VideoViewHolder {
        HighlightViewHolder(View view) {
            super(view);
            this.date = (TextView) view.findViewById(R.id.textViewDate);
            this.title = (TextView) view.findViewById(R.id.textViewHighlight);
            this.thumb = (ImageView) view.findViewById(R.id.imageViewHighlight);
        }
    }
}

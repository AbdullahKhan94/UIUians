package com.thedaw.uiuians.providers.youtube.api.object;

import java.util.ArrayList;

public class ReturnItem {
    private ArrayList<Video> list;
    private String pagetoken;

    public ReturnItem(ArrayList<Video> arrayList, String str) {
        this.list = arrayList;
        this.pagetoken = str;
    }

    public String getPageToken() {
        return this.pagetoken;
    }

    public ArrayList<Video> getList() {
        return this.list;
    }
}

package com.thedaw.uiuians.providers.youtube.api;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.format.DateUtils;
import com.google.android.exoplayer2.text.ttml.TtmlNode;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.thedaw.uiuians.billing.Constants;
import com.thedaw.uiuians.providers.youtube.api.object.ReturnItem;
import com.thedaw.uiuians.providers.youtube.api.object.Video;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RetrieveVideos {
    private static String API_BASE = "https://www.googleapis.com/youtube/v3";
    private static String API_TYPE_PLAYLIST = "/playlistItems";
    private static String API_TYPE_SEARCH = "/search";
    private static int PER_PAGE = 20;
    private Context mContext;
    private String serverKey;

    public RetrieveVideos(Context context, String str) {
        this.serverKey = str;
        this.mContext = context;
    }

    public ReturnItem getLiveVideos(String str, String str2) {
        String str3 = API_BASE + API_TYPE_SEARCH + "?part=snippet&type=video&channelId=" + str + "&eventType=live&maxResults=" + PER_PAGE + "&key=" + this.serverKey;
        if (str2 != null) {
            str3 = str3 + "&pageToken=" + str2;
        }
        return getVideos(str3, this.mContext);
    }

    public ReturnItem getUserVideos(String str) {
        return getUserVideos(str, null);
    }

    public ReturnItem getUserVideos(String str, String str2) {
        String str3 = API_BASE + API_TYPE_SEARCH + "?part=snippet&order=date&channelId=" + str + "&maxResults=" + PER_PAGE + "&key=" + this.serverKey;
        if (str2 != null) {
            str3 = str3 + "&pageToken=" + str2;
        }
        return getVideos(str3, this.mContext);
    }

    public ReturnItem getPlaylistVideos(String str) {
        return getPlaylistVideos(str, null);
    }

    public ReturnItem getPlaylistVideos(String str, String str2) {
        String str3 = API_BASE + API_TYPE_PLAYLIST + "?part=snippet&playlistId=" + str + "&maxResults=" + PER_PAGE + "&key=" + this.serverKey;
        if (str2 != null) {
            str3 = str3 + "&pageToken=" + str2;
        }
        return getVideos(str3, this.mContext);
    }

    public ReturnItem getSearchVideos(String str, String str2) {
        return getSearchVideos(str, str2, null);
    }

    public ReturnItem getSearchVideos(String str, String str2, String str3) {
        try {
            str = URLEncoder.encode(str, "UTF-8");
        } catch (UnsupportedEncodingException unused) {
        }
        String str4 = API_BASE + API_TYPE_SEARCH + "?part=snippet&type=video&channelId=" + str2 + "&q=" + str + "&maxResults=" + PER_PAGE + "&key=" + this.serverKey;
        if (str3 != null) {
            str4 = str4 + "&pageToken=" + str3;
        }
        return getVideos(str4, this.mContext);
    }

    public static ReturnItem getVideos(String str, Context context) {
        ArrayList arrayList;
        JSONException e;
        String str2;
        JSONObject jSONObjectFromUrl = Helper.getJSONObjectFromUrl(str);
        String str3 = null;
        if (jSONObjectFromUrl == null) {
            return new ReturnItem(null, null);
        }
        try {
            arrayList = jSONObjectFromUrl.getString("kind").contains("youtube") ? new ArrayList() : null;
            try {
                if (jSONObjectFromUrl.has("nextPageToken")) {
                    str3 = jSONObjectFromUrl.getString("nextPageToken");
                }
                JSONArray jSONArray = jSONObjectFromUrl.getJSONArray("items");
                for (int i = 0; i < jSONArray.length(); i++) {
                    try {
                        JSONObject jSONObject = jSONArray.getJSONObject(i);
                        JSONObject jSONObject2 = jSONArray.getJSONObject(i).getJSONObject("snippet");
                        String string = jSONObject2.getString("title");
                        String formatData = formatData(jSONObject2.getString("publishedAt"), context);
                        String string2 = jSONObject2.getString(Constants.RESPONSE_DESCRIPTION);
                        String string3 = jSONObject2.getString("channelTitle");
                        try {
                            str2 = jSONObject2.getJSONObject("resourceId").getString("videoId");
                        } catch (Exception unused) {
                            str2 = jSONObject.getJSONObject(TtmlNode.ATTR_ID).getString("videoId");
                        }
                        arrayList.add(new Video(string, str2, formatData, string2, jSONObject2.getJSONObject("thumbnails").getJSONObject(FirebaseAnalytics.Param.MEDIUM).getString("url"), jSONObject2.getJSONObject("thumbnails").getJSONObject("high").getString("url"), string3));
                    } catch (JSONException e2) {
                        Log.v("INFO", "JSONException: " + e2);
                    }
                }
            } catch (JSONException e3) {
                e = e3;
                Log.v("INFO", "JSONException: " + e);
                Log.v("INFO", "Token: " + str3);
                return new ReturnItem(arrayList, str3);
            }
        } catch (JSONException e4) {
            e = e4;
            arrayList = null;
            Log.v("INFO", "JSONException: " + e);
            Log.v("INFO", "Token: " + str3);
            return new ReturnItem(arrayList, str3);
        }
        Log.v("INFO", "Token: " + str3);
        return new ReturnItem(arrayList, str3);
    }

    @SuppressLint({"SimpleDateFormat"})
    private static String formatData(String str, Context context) {
        try {
            return DateUtils.getRelativeDateTimeString(context, new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).parse(str).getTime(), 1000, 604800000, 524288).toString();
        } catch (ParseException e) {
            Log.printStackTrace(e);
            return "";
        }
    }
}

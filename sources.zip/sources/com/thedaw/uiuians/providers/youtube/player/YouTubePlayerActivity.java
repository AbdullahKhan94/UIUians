package com.thedaw.uiuians.providers.youtube.player;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.KeyEvent;
import android.widget.FrameLayout;
import android.widget.Toast;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.thedaw.uiuians.R;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class YouTubePlayerActivity extends YouTubeBaseActivity implements YouTubePlayer.OnFullscreenListener, YouTubePlayer.OnInitializedListener, YouTubePlayer.PlayerStateChangeListener {
    public static final String EXTRA_VIDEO_ID = "video_id";
    @SuppressLint({"InlinedApi"})
    private static final int LANDSCAPE_ORIENTATION = (Build.VERSION.SDK_INT < 9 ? 0 : 6);
    @SuppressLint({"InlinedApi"})
    private static final int PORTRAIT_ORIENTATION = (Build.VERSION.SDK_INT < 9 ? 1 : 7);
    private static final int RECOVERY_DIALOG_REQUEST = 1;
    private static final boolean TOAST = false;
    public String GOOGLE_API_KEY;
    private boolean mAutoRotation = false;
    private YouTubePlayer mPlayer = null;
    private YouTubePlayerView mPlayerView;
    private String mVideoId = null;

    @Override // com.google.android.youtube.player.YouTubePlayer.PlayerStateChangeListener
    public void onAdStarted() {
    }

    @Override // com.google.android.youtube.player.YouTubePlayer.PlayerStateChangeListener
    public void onLoaded(String str) {
    }

    @Override // com.google.android.youtube.player.YouTubePlayer.PlayerStateChangeListener
    public void onLoading() {
    }

    @Override // com.google.android.youtube.player.YouTubePlayer.PlayerStateChangeListener
    public void onVideoEnded() {
    }

    @Override // com.google.android.youtube.player.YouTubePlayer.PlayerStateChangeListener
    public void onVideoStarted() {
    }

    /* access modifiers changed from: protected */
    @Override // com.google.android.youtube.player.YouTubeBaseActivity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.GOOGLE_API_KEY = getResources().getString(R.string.google_server_key);
        this.mPlayerView = new YouTubePlayerView(this);
        this.mPlayerView.initialize(this.GOOGLE_API_KEY, this);
        this.mVideoId = getIntent().getStringExtra(EXTRA_VIDEO_ID);
        boolean z = true;
        if (Settings.System.getInt(getContentResolver(), "accelerometer_rotation", 0) != 1) {
            z = false;
        }
        this.mAutoRotation = z;
        addContentView(this.mPlayerView, new FrameLayout.LayoutParams(-1, -1));
    }

    @Override // com.google.android.youtube.player.YouTubePlayer.OnInitializedListener
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean z) {
        this.mPlayer = youTubePlayer;
        youTubePlayer.setPlayerStateChangeListener(this);
        youTubePlayer.setOnFullscreenListener(this);
        if (this.mAutoRotation) {
            youTubePlayer.addFullscreenControlFlag(15);
        } else {
            youTubePlayer.addFullscreenControlFlag(11);
        }
        if (!z) {
            youTubePlayer.loadVideo(this.mVideoId);
        }
    }

    @Override // com.google.android.youtube.player.YouTubePlayer.OnInitializedListener
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
        if (youTubeInitializationResult.isUserRecoverableError()) {
            youTubeInitializationResult.getErrorDialog(this, 1).show();
            return;
        }
        Toast.makeText(this, String.format("There was an error initializing the YouTubePlayer (%1$s)", youTubeInitializationResult.toString()), 1).show();
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        if (i == 1) {
            getYouTubePlayerProvider().initialize(this.GOOGLE_API_KEY, this);
        }
    }

    public YouTubePlayer.Provider getYouTubePlayerProvider() {
        return this.mPlayerView;
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (configuration.orientation == 2) {
            if (this.mPlayer != null) {
                this.mPlayer.setFullscreen(true);
            }
        } else if (configuration.orientation == 1 && this.mPlayer != null) {
            this.mPlayer.setFullscreen(false);
        }
    }

    @Override // com.google.android.youtube.player.YouTubePlayer.OnFullscreenListener
    public void onFullscreen(boolean z) {
        if (z) {
            setRequestedOrientation(LANDSCAPE_ORIENTATION);
        } else {
            setRequestedOrientation(PORTRAIT_ORIENTATION);
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 24) {
            ((AudioManager) getBaseContext().getSystemService(MimeTypes.BASE_TYPE_AUDIO)).adjustStreamVolume(3, 1, 9);
            return true;
        } else if (i != 25) {
            return super.onKeyDown(i, keyEvent);
        } else {
            ((AudioManager) getBaseContext().getSystemService(MimeTypes.BASE_TYPE_AUDIO)).adjustStreamVolume(3, -1, 9);
            return true;
        }
    }

    public static String getYouTubeVideoId(String str) {
        if (str == null || str.length() <= 0) {
            return null;
        }
        String queryParameter = Uri.parse(str).getQueryParameter("v");
        return queryParameter == null ? parseYoutubeVideoId(str) : queryParameter;
    }

    public static String parseYoutubeVideoId(String str) {
        if (str != null && str.trim().length() > 0 && str.startsWith("http")) {
            Matcher matcher = Pattern.compile("^.*((youtu.be\\/)|(v\\/)|(\\/u\\/w\\/)|(embed\\/)|(watch\\?))\\??v?=?([^#\\&\\?]*).*", 2).matcher(str);
            if (matcher.matches()) {
                String group = matcher.group(7);
                if (group != null && group.length() == 11) {
                    return group;
                }
                if (group != null && group.length() == 10) {
                    return "v" + group;
                }
            }
        }
        return null;
    }

    @Override // com.google.android.youtube.player.YouTubePlayer.PlayerStateChangeListener
    public void onError(YouTubePlayer.ErrorReason errorReason) {
        if (YouTubePlayer.ErrorReason.NOT_PLAYABLE.equals(errorReason)) {
            startVideo(this, Uri.parse("http://www.youtube.com/watch?v=" + this.mVideoId));
        }
    }

    private void startVideo(Activity activity, Uri uri) {
        Intent intent;
        String queryParameter = uri.getQueryParameter("v");
        if (queryParameter != null) {
            intent = new Intent("android.intent.action.VIEW", Uri.parse("vnd.youtube:" + queryParameter));
            if (activity.getPackageManager().queryIntentActivities(intent, 65536).size() == 0) {
                intent = new Intent("android.intent.action.VIEW", uri);
            }
        } else {
            intent = new Intent("android.intent.action.VIEW", uri);
        }
        activity.startActivity(intent);
    }
}

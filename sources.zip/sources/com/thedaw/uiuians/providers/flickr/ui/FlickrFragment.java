package com.thedaw.uiuians.providers.flickr.ui;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.google.android.exoplayer2.text.ttml.TtmlNode;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.inherit.PermissionsFragment;
import com.thedaw.uiuians.providers.flickr.FlickrItem;
import com.thedaw.uiuians.providers.flickr.ImageAdapter;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter;
import com.thedaw.uiuians.util.Log;
import com.thedaw.uiuians.util.ThemeUtils;
import com.thedaw.uiuians.util.layout.StaggeredGridSpacingItemDecoration;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FlickrFragment extends Fragment implements PermissionsFragment, InfiniteRecyclerViewAdapter.LoadMoreListener {
    String baseurl;
    Integer curpage = 0;
    private ImageAdapter imageAdapter = null;
    Boolean isLoading = true;
    private RecyclerView listView;
    private RelativeLayout ll;
    private Activity mAct;
    String method;
    Integer total_pages;
    ArrayList<FlickrItem> tumblrItems;

    @Override // android.support.v4.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.ll = (RelativeLayout) layoutInflater.inflate(R.layout.fragment_list, viewGroup, false);
        return this.ll;
    }

    @Override // android.support.v4.app.Fragment
    public void onViewCreated(View view, @Nullable Bundle bundle) {
        super.onViewCreated(view, bundle);
        setHasOptionsMenu(true);
        String string = getString(R.string.flickr_key);
        String str = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        this.method = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[1];
        String str2 = !this.method.equals("gallery") ? "photosets" : "galleries";
        String str3 = !this.method.equals("gallery") ? "photoset_id" : "gallery_id";
        this.baseurl = "https://api.flickr.com/services/rest/?method=flickr." + str2 + ".getPhotos&api_key=" + string + "&" + str3 + "=" + str + "&format=json&extras=path_alias,url_o,url_c,url_b,url_z&page=";
        this.listView = (RecyclerView) this.ll.findViewById(R.id.list);
        this.tumblrItems = new ArrayList<>();
        this.imageAdapter = new ImageAdapter(getContext(), this.tumblrItems, this);
        this.imageAdapter.setModeAndNotify(3);
        this.listView.setAdapter(this.imageAdapter);
        this.listView.setLayoutManager(new StaggeredGridLayoutManager(3, 1));
        this.listView.setItemAnimator(new DefaultItemAnimator());
        this.listView.addItemDecoration(new StaggeredGridSpacingItemDecoration((int) getResources().getDimension(R.dimen.woocommerce_padding), true));
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        refreshItems();
    }

    public void updateList(ArrayList<FlickrItem> arrayList) {
        if (arrayList.size() > 0) {
            this.tumblrItems.addAll(arrayList);
        }
        if (this.curpage.intValue() >= this.total_pages.intValue() || arrayList.size() == 0) {
            this.imageAdapter.setHasMore(false);
        }
        this.imageAdapter.setModeAndNotify(1);
    }

    @Override // com.thedaw.uiuians.inherit.PermissionsFragment
    public String[] requiredPermissions() {
        return new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"};
    }

    @Override // com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter.LoadMoreListener
    public void onMoreRequested() {
        if (!this.isLoading.booleanValue() && this.curpage.intValue() < this.total_pages.intValue()) {
            this.isLoading = true;
            new InitialLoadGridView().execute(this.baseurl);
        }
    }

    /* access modifiers changed from: package-private */
    public void refreshItems() {
        this.isLoading = true;
        this.curpage = 1;
        this.tumblrItems.clear();
        this.imageAdapter.setHasMore(true);
        this.imageAdapter.setModeAndNotify(3);
        new InitialLoadGridView().execute(this.baseurl);
    }

    /* access modifiers changed from: private */
    public class InitialLoadGridView extends AsyncTask<String, Void, ArrayList<FlickrItem>> {
        private InitialLoadGridView() {
        }

        /* access modifiers changed from: protected */
        public ArrayList<FlickrItem> doInBackground(String... strArr) {
            JSONObject jSONObject;
            ArrayList<FlickrItem> arrayList;
            JSONException e;
            NullPointerException e2;
            String str;
            FlickrFragment.this.curpage = Integer.valueOf(FlickrFragment.this.curpage.intValue() + 1);
            String dataFromUrl = Helper.getDataFromUrl(strArr[0] + Integer.toString(FlickrFragment.this.curpage.intValue()));
            Log.v("INFO", "Tumblr JSON: " + dataFromUrl);
            if (dataFromUrl.isEmpty()) {
                return null;
            }
            try {
                String replace = dataFromUrl.replace("jsonFlickrApi(", "");
                jSONObject = new JSONObject(replace.substring(0, replace.length() - 1));
            } catch (JSONException e3) {
                Log.printStackTrace(e3);
                jSONObject = null;
            }
            try {
                String str2 = !FlickrFragment.this.method.equals("gallery") ? "photoset" : "photos";
                FlickrFragment.this.total_pages = Integer.valueOf(jSONObject.getJSONObject(str2).getInt("pages"));
                JSONArray jSONArray = jSONObject.getJSONObject(str2).getJSONArray("photo");
                arrayList = new ArrayList<>();
                for (int i = 0; i < jSONArray.length(); i++) {
                    try {
                        JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                        String string = jSONObject2.getString(TtmlNode.ATTR_ID);
                        jSONObject2.getString("title");
                        String str3 = "https://www.flickr.com/photos/" + jSONObject2.getString("pathalias") + "/" + string;
                        if (jSONObject2.has("url_o")) {
                            str = jSONObject2.getString("url_o");
                        } else if (jSONObject2.has("url_b")) {
                            str = jSONObject2.getString("url_b");
                        } else {
                            str = jSONObject2.has("url_c") ? jSONObject2.getString("url_c") : null;
                        }
                        String string2 = jSONObject2.has("url_z") ? jSONObject2.getString("url_z") : str;
                        if (str != null) {
                            arrayList.add(new FlickrItem(string, str3, str, string2));
                        }
                    } catch (JSONException e4) {
                        e = e4;
                        Log.printStackTrace(e);
                        return arrayList;
                    } catch (NullPointerException e5) {
                        e2 = e5;
                        Log.printStackTrace(e2);
                        return arrayList;
                    }
                }
            } catch (JSONException e6) {
                e = e6;
                arrayList = null;
                Log.printStackTrace(e);
                return arrayList;
            } catch (NullPointerException e7) {
                e2 = e7;
                arrayList = null;
                Log.printStackTrace(e2);
                return arrayList;
            }
            return arrayList;
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(ArrayList<FlickrItem> arrayList) {
            if (arrayList != null) {
                FlickrFragment.this.updateList(arrayList);
            } else {
                Helper.noConnection(FlickrFragment.this.mAct);
                FlickrFragment.this.imageAdapter.setModeAndNotify(2);
            }
            FlickrFragment.this.isLoading = false;
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.refresh_menu, menu);
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.refresh) {
            if (!this.isLoading.booleanValue()) {
                refreshItems();
            } else {
                Toast.makeText(this.mAct, getString(R.string.already_loading), 1).show();
            }
        }
        return super.onOptionsItemSelected(menuItem);
    }
}

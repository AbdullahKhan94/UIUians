package com.thedaw.uiuians.providers;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.widget.Toast;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.util.Log;

public class CustomIntent extends Fragment {
    public static String OPEN_ACTIVITY = "activity";
    public static String OPEN_APP = "app";
    public static String OPEN_FRAGMENT = "fragment";
    public static String OPEN_URL = "url";

    public static void performIntent(Activity activity, String[] strArr) {
        boolean z = false;
        if (strArr[1].equals(OPEN_URL)) {
            z = openUrl(activity, strArr[0]);
        } else if (strArr[1].equals(OPEN_APP)) {
            z = openApp(activity, strArr[0]);
        } else if (strArr[1].equals(OPEN_ACTIVITY)) {
            z = openActivity(activity, strArr[0]);
        } else if (strArr[1].equals(OPEN_FRAGMENT)) {
            z = openFragment(activity, strArr[0]);
        }
        if (!z) {
            Toast.makeText(activity, activity.getResources().getString(R.string.intent_failed), 1).show();
        }
    }

    public static boolean openApp(Activity activity, String str) {
        Intent launchIntentForPackage = activity.getPackageManager().getLaunchIntentForPackage(str);
        if (launchIntentForPackage == null) {
            return false;
        }
        launchIntentForPackage.addCategory("android.intent.category.LAUNCHER");
        activity.startActivity(launchIntentForPackage);
        return true;
    }

    public static boolean openUrl(Activity activity, String str) {
        try {
            activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
            return true;
        } catch (ActivityNotFoundException e) {
            Log.printStackTrace(e);
            return false;
        }
    }

    public static boolean openActivity(Activity activity, String str) {
        try {
            activity.startActivity(new Intent(activity, Class.forName(str)));
            return true;
        } catch (ClassNotFoundException e) {
            Log.printStackTrace(e);
            return false;
        }
    }

    public static boolean openFragment(Activity activity, String str) {
        try {
            HolderActivity.startActivity(activity, Class.forName(str), new String[0]);
            return true;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
}

package com.thedaw.uiuians.providers.web;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.FrameLayout;
import com.thedaw.uiuians.util.ThemeUtils;

public class FullscreenableChromeClient extends WebChromeClient {
    private static final FrameLayout.LayoutParams COVER_SCREEN_PARAMS = new FrameLayout.LayoutParams(-1, -1);
    private Activity mActivity = null;
    private View mCustomView;
    private WebChromeClient.CustomViewCallback mCustomViewCallback;
    private FrameLayout mFullscreenContainer;
    private int mOriginalOrientation;

    public FullscreenableChromeClient(Activity activity) {
        this.mActivity = activity;
    }

    public void onShowCustomView(View view, WebChromeClient.CustomViewCallback customViewCallback) {
        if (Build.VERSION.SDK_INT >= 14) {
            if (this.mCustomView != null) {
                customViewCallback.onCustomViewHidden();
                return;
            }
            this.mOriginalOrientation = this.mActivity.getRequestedOrientation();
            this.mFullscreenContainer = new FullscreenHolder(this.mActivity);
            this.mFullscreenContainer.addView(view, COVER_SCREEN_PARAMS);
            ((FrameLayout) this.mActivity.getWindow().getDecorView()).addView(this.mFullscreenContainer, COVER_SCREEN_PARAMS);
            this.mCustomView = view;
            setFullscreen(true);
            this.mCustomViewCallback = customViewCallback;
        }
        super.onShowCustomView(view, customViewCallback);
    }

    public void onShowCustomView(View view, int i, WebChromeClient.CustomViewCallback customViewCallback) {
        onShowCustomView(view, customViewCallback);
    }

    public void onHideCustomView() {
        if (this.mCustomView != null) {
            setFullscreen(false);
            FrameLayout frameLayout = (FrameLayout) this.mActivity.getWindow().getDecorView();
            frameLayout.removeView(this.mFullscreenContainer);
            this.mFullscreenContainer = null;
            this.mCustomView = null;
            this.mCustomViewCallback.onCustomViewHidden();
            this.mActivity.setRequestedOrientation(this.mOriginalOrientation);
            if (Build.VERSION.SDK_INT >= 23 && ThemeUtils.lightToolbarThemeActive(this.mActivity)) {
                frameLayout.setSystemUiVisibility(frameLayout.getSystemUiVisibility() | 8192);
            }
        }
    }

    public boolean onCreateWindow(WebView webView, boolean z, boolean z2, Message message) {
        ((WebView.WebViewTransport) message.obj).setWebView(new AdvancedWebView(this.mActivity));
        message.sendToTarget();
        return true;
    }

    private void setFullscreen(boolean z) {
        Window window = this.mActivity.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        if (z) {
            attributes.flags |= 1024;
            this.mActivity.getWindow().getDecorView().setSystemUiVisibility(3846);
        } else {
            attributes.flags &= -1025;
            if (this.mCustomView != null) {
                this.mCustomView.setSystemUiVisibility(0);
            }
            this.mActivity.getWindow().getDecorView().setSystemUiVisibility(256);
        }
        window.setAttributes(attributes);
    }

    /* access modifiers changed from: private */
    public static class FullscreenHolder extends FrameLayout {
        public boolean onTouchEvent(MotionEvent motionEvent) {
            return true;
        }

        public FullscreenHolder(Context context) {
            super(context);
            setBackgroundColor(ContextCompat.getColor(context, 17170444));
        }
    }
}

package com.thedaw.uiuians.providers.web;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.Toast;
import com.thedaw.uiuians.HolderActivity;
import com.thedaw.uiuians.MainActivity;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.inherit.BackPressFragment;
import com.thedaw.uiuians.inherit.CollapseControllingFragment;
import com.thedaw.uiuians.inherit.ConfigurationChangeFragment;
import com.thedaw.uiuians.inherit.PermissionsFragment;
import com.thedaw.uiuians.providers.fav.FavDbAdapter;
import com.thedaw.uiuians.providers.web.AdvancedWebView;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.ThemeUtils;

public class WebviewFragment extends Fragment implements BackPressFragment, CollapseControllingFragment, AdvancedWebView.Listener, ConfigurationChangeFragment, PermissionsFragment {
    public static final String HIDE_NAVIGATION = "hide_navigation";
    public static final String LOAD_DATA = "loadwithdata";
    private AdvancedWebView browser;
    private FrameLayout ll;
    private Activity mAct;
    private FavDbAdapter mDbHelper;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private ImageButton webBackButton;
    private ImageButton webForwButton;

    @Override // com.thedaw.uiuians.inherit.CollapseControllingFragment
    public boolean dynamicToolbarElevation() {
        return false;
    }

    public boolean navigationIsVisible() {
        return false;
    }

    @Override // com.thedaw.uiuians.providers.web.AdvancedWebView.Listener
    public void onExternalPageRequest(String str) {
    }

    @Override // com.thedaw.uiuians.inherit.CollapseControllingFragment
    public boolean supportsCollapse() {
        return false;
    }

    @Override // android.support.v4.app.Fragment
    @SuppressLint({"InflateParams"})
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreateView(layoutInflater, viewGroup, bundle);
        this.ll = (FrameLayout) layoutInflater.inflate(R.layout.fragment_webview, viewGroup, false);
        setHasOptionsMenu(true);
        this.browser = (AdvancedWebView) this.ll.findViewById(R.id.webView);
        this.mSwipeRefreshLayout = (SwipeRefreshLayout) this.ll.findViewById(R.id.refreshlayout);
        this.browser.setListener(getActivity(), this);
        this.browser.setGeolocationEnabled(false);
        this.browser.setWebViewClient(new WebViewClient() {
            /* class com.thedaw.uiuians.providers.web.WebviewFragment.AnonymousClass1 */

            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                return handleUri(str);
            }

            @Override // android.webkit.WebViewClient
            @TargetApi(24)
            public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
                return handleUri(webResourceRequest.getUrl().toString());
            }

            public void onReceivedSslError(WebView webView, final SslErrorHandler sslErrorHandler, SslError sslError) {
                AlertDialog.Builder builder = new AlertDialog.Builder(WebviewFragment.this.mAct);
                builder.setMessage(R.string.notification_error_ssl_cert_invalid);
                builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    /* class com.thedaw.uiuians.providers.web.WebviewFragment.AnonymousClass1.AnonymousClass1 */

                    public void onClick(DialogInterface dialogInterface, int i) {
                        sslErrorHandler.proceed();
                    }
                });
                builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    /* class com.thedaw.uiuians.providers.web.WebviewFragment.AnonymousClass1.AnonymousClass2 */

                    public void onClick(DialogInterface dialogInterface, int i) {
                        sslErrorHandler.cancel();
                    }
                });
                builder.create().show();
            }

            /* access modifiers changed from: package-private */
            public boolean handleUri(String str) {
                if (!str.contains("market://") && !str.contains("mailto:") && !str.contains("play.google") && !str.contains("tel:") && !str.contains("vid:")) {
                    return false;
                }
                WebviewFragment.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
                return true;
            }
        });
        this.mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            /* class com.thedaw.uiuians.providers.web.WebviewFragment.AnonymousClass2 */

            @Override // android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener
            public void onRefresh() {
                WebviewFragment.this.browser.reload();
            }
        });
        return this.ll;
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.mAct = getActivity();
        setRetainInstance(true);
        this.browser.setWebChromeClient(new FullscreenableChromeClient(this.mAct));
        String str = getArguments().getStringArray(MainActivity.FRAGMENT_DATA)[0];
        String string = getArguments().containsKey(LOAD_DATA) ? getArguments().getString(LOAD_DATA) : null;
        if (string != null) {
            this.browser.loadDataWithBaseURL(str, string, "text/html", "UTF-8", "");
        } else {
            this.browser.loadUrl(str);
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onPause() {
        super.onPause();
        if (this.browser != null) {
            this.browser.onPause();
        }
        if (isMenuVisible() || getUserVisibleHint()) {
            setMenuVisibility(false);
        }
    }

    @Override // android.support.v4.app.Fragment
    public void setMenuVisibility(boolean z) {
        ActionBar supportActionBar;
        super.setMenuVisibility(z);
        if (this.mAct != null) {
            if (z) {
                if (navigationIsVisible() && (supportActionBar = ((AppCompatActivity) this.mAct).getSupportActionBar()) != null) {
                    if (this.mAct instanceof HolderActivity) {
                        supportActionBar.setDisplayOptions(30);
                    } else {
                        supportActionBar.setDisplayOptions(26);
                    }
                    supportActionBar.setCustomView(this.mAct.getLayoutInflater().inflate(R.layout.fragment_webview_actionbar, (ViewGroup) null), new ActionBar.LayoutParams(-2, -2, 8388629));
                    this.webBackButton = (ImageButton) this.mAct.findViewById(R.id.goBack);
                    this.webForwButton = (ImageButton) this.mAct.findViewById(R.id.goForward);
                    this.webBackButton.setOnClickListener(new View.OnClickListener() {
                        /* class com.thedaw.uiuians.providers.web.WebviewFragment.AnonymousClass3 */

                        public void onClick(View view) {
                            if (WebviewFragment.this.browser.canGoBack()) {
                                WebviewFragment.this.browser.goBack();
                            }
                        }
                    });
                    this.webForwButton.setOnClickListener(new View.OnClickListener() {
                        /* class com.thedaw.uiuians.providers.web.WebviewFragment.AnonymousClass4 */

                        public void onClick(View view) {
                            if (WebviewFragment.this.browser.canGoForward()) {
                                WebviewFragment.this.browser.goForward();
                            }
                        }
                    });
                }
            } else if (navigationIsVisible() && getActivity() != null) {
                ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayOptions(10);
            }
        }
    }

    @Override // android.support.v4.app.Fragment
    @SuppressLint({"RestrictedApi"})
    public void onResume() {
        super.onResume();
        if (this.browser != null) {
            this.browser.onResume();
        } else {
            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
        }
        if (getArguments().containsKey(HIDE_NAVIGATION) && getArguments().getBoolean(HIDE_NAVIGATION)) {
            this.mSwipeRefreshLayout.setEnabled(false);
        }
        if (isMenuVisible() || getUserVisibleHint()) {
            setMenuVisibility(true);
        }
        adjustControls();
    }

    @Override // android.support.v4.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.browser.onDestroy();
    }

    @Override // android.support.v4.app.Fragment
    public void onHiddenChanged(boolean z) {
        super.onHiddenChanged(z);
        if (!z) {
            setMenuVisibility(true);
        }
    }

    @Override // android.support.v4.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.favorite) {
            this.mDbHelper = new FavDbAdapter(this.mAct);
            this.mDbHelper.open();
            String title = this.browser.getTitle();
            String url = this.browser.getUrl();
            if (this.mDbHelper.checkEvent(title, url, 3)) {
                this.mDbHelper.addFavorite(title, url, 3);
                Toast.makeText(this.mAct, getResources().getString(R.string.favorite_success), 1).show();
            } else {
                Toast.makeText(this.mAct, getResources().getString(R.string.favorite_duplicate), 1).show();
            }
            return true;
        } else if (itemId != R.id.share) {
            return super.onOptionsItemSelected(menuItem);
        } else {
            shareURL();
            return true;
        }
    }

    @Override // android.support.v4.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        if (!getArguments().containsKey(HIDE_NAVIGATION) || !getArguments().getBoolean(HIDE_NAVIGATION)) {
            menuInflater.inflate(R.menu.webview_menu, menu);
        }
        if (this.browser.getUrl() != null && this.browser.getUrl().startsWith("file:///android_asset/")) {
            menu.findItem(R.id.share).setVisible(false);
        }
        ThemeUtils.tintAllIcons(menu, this.mAct);
    }

    private boolean hasConnectivity() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) this.mAct.getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected() && activeNetworkInfo.isAvailable();
    }

    public void adjustControls() {
        this.webBackButton = (ImageButton) this.mAct.findViewById(R.id.goBack);
        this.webForwButton = (ImageButton) this.mAct.findViewById(R.id.goForward);
        if (this.webBackButton != null && this.webForwButton != null && this.browser != null) {
            if (ThemeUtils.lightToolbarThemeActive(this.mAct)) {
                this.webBackButton.setColorFilter(ViewCompat.MEASURED_STATE_MASK);
                this.webForwButton.setColorFilter(ViewCompat.MEASURED_STATE_MASK);
            }
            float f = 0.5f;
            this.webBackButton.setAlpha(this.browser.canGoBack() ? 1.0f : 0.5f);
            ImageButton imageButton = this.webForwButton;
            if (this.browser.canGoForward()) {
                f = 1.0f;
            }
            imageButton.setAlpha(f);
        }
    }

    private void shareURL() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        String string = getString(R.string.app_name);
        intent.putExtra("android.intent.extra.TEXT", getResources().getString(R.string.web_share_begin) + string + getResources().getString(R.string.web_share_end) + this.browser.getUrl());
        startActivity(Intent.createChooser(intent, getResources().getString(R.string.share)));
    }

    @Override // com.thedaw.uiuians.inherit.BackPressFragment
    public boolean handleBackPress() {
        return !this.browser.onBackPressed();
    }

    @Override // android.support.v4.app.Fragment
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        this.browser.onActivityResult(i, i2, intent);
    }

    @Override // com.thedaw.uiuians.providers.web.AdvancedWebView.Listener
    public void onPageStarted(String str, Bitmap bitmap) {
        if (navigationIsVisible()) {
            this.mSwipeRefreshLayout.setRefreshing(true);
        }
    }

    @Override // com.thedaw.uiuians.providers.web.AdvancedWebView.Listener
    public void onPageFinished(String str) {
        if (this.mSwipeRefreshLayout.isRefreshing()) {
            this.mSwipeRefreshLayout.setRefreshing(false);
        }
        adjustControls();
        hideErrorScreen();
    }

    @Override // com.thedaw.uiuians.providers.web.AdvancedWebView.Listener
    public void onPageError(int i, String str, String str2) {
        if (this.mSwipeRefreshLayout.isRefreshing()) {
            this.mSwipeRefreshLayout.setRefreshing(false);
        }
        if (!str2.startsWith("file:///android_asset/") && !hasConnectivity()) {
            showErrorScreen();
        }
    }

    @Override // com.thedaw.uiuians.providers.web.AdvancedWebView.Listener
    public void onDownloadRequested(String str, String str2, String str3, long j, String str4, String str5) {
        if (Helper.hasPermissionToDownload(getActivity()) && !AdvancedWebView.handleDownload(this.mAct, str, str2)) {
            Toast.makeText(this.mAct, (int) R.string.download_failed, 0).show();
        }
    }

    @Override // com.thedaw.uiuians.inherit.PermissionsFragment
    public String[] requiredPermissions() {
        return new String[0];
    }

    public void showErrorScreen() {
        View findViewById = this.ll.findViewById(R.id.empty_view);
        findViewById.setVisibility(0);
        findViewById.findViewById(R.id.retry_button).setOnClickListener(new View.OnClickListener() {
            /* class com.thedaw.uiuians.providers.web.WebviewFragment.AnonymousClass5 */

            public void onClick(View view) {
                WebviewFragment.this.browser.loadUrl("javascript:document.open();document.close();");
                WebviewFragment.this.browser.reload();
            }
        });
    }

    public void hideErrorScreen() {
        View findViewById = this.ll.findViewById(R.id.empty_view);
        if (findViewById.getVisibility() == 0) {
            findViewById.setVisibility(8);
        }
    }
}

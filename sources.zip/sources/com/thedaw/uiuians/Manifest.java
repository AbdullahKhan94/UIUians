package com.thedaw.uiuians;

public final class Manifest {

    public static final class permission {
        public static final String C2D_MESSAGE = "com.thedaw.uiuians.permission.C2D_MESSAGE";
    }
}

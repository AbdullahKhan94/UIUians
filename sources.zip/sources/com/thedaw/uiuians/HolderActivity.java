package com.thedaw.uiuians;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebViewFragment;
import android.widget.Toast;
import com.thedaw.uiuians.inherit.BackPressFragment;
import com.thedaw.uiuians.inherit.PermissionsFragment;
import com.thedaw.uiuians.providers.CustomIntent;
import com.thedaw.uiuians.providers.fav.ui.FavFragment;
import com.thedaw.uiuians.providers.web.WebviewFragment;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import com.thedaw.uiuians.util.ThemeUtils;
import java.util.ArrayList;
import java.util.Arrays;

public class HolderActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private Class<? extends Fragment> queueItem;
    private String[] queueItemData;

    public static void startActivity(Context context, Class<? extends Fragment> cls, String[] strArr) {
        Bundle bundle = new Bundle();
        bundle.putStringArray(MainActivity.FRAGMENT_DATA, strArr);
        bundle.putSerializable(MainActivity.FRAGMENT_CLASS, cls);
        Intent intent = new Intent(context, HolderActivity.class);
        intent.putExtras(bundle);
        context.startActivity(intent);
    }

    public static void startWebViewActivity(Context context, String str, boolean z, boolean z2, String str2, int i) {
        if (!z || str2 != null) {
            Bundle bundle = new Bundle();
            bundle.putStringArray(MainActivity.FRAGMENT_DATA, new String[]{str});
            bundle.putSerializable(MainActivity.FRAGMENT_CLASS, WebViewFragment.class);
            bundle.putBoolean(WebviewFragment.HIDE_NAVIGATION, z2);
            bundle.putString(WebviewFragment.LOAD_DATA, str2);
            Intent intent = new Intent(context, HolderActivity.class);
            intent.putExtras(bundle);
            intent.addFlags(i);
            context.startActivity(intent);
            return;
        }
        Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse(str));
        intent2.addFlags(i);
        if (intent2.resolveActivity(context.getPackageManager()) != null) {
            context.startActivity(intent2);
            return;
        }
        Log.v("INFO", "No activity to resolve url: " + str);
        Toast.makeText(context, (int) R.string.no_app, 0).show();
    }

    public static void startWebViewActivity(Context context, String str, boolean z, boolean z2, String str2) {
        startWebViewActivity(context, str, z, z2, str2, 0);
    }

    @Override // android.support.v7.app.AppCompatActivity, android.support.v4.app.SupportActivity, android.support.v4.app.FragmentActivity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ThemeUtils.setTheme(this);
        setContentView(R.layout.activity_holder);
        this.mToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar);
        setSupportActionBar(this.mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Class<? extends Fragment> cls = (Class) getIntent().getExtras().getSerializable(MainActivity.FRAGMENT_CLASS);
        String[] stringArray = getIntent().getExtras().getStringArray(MainActivity.FRAGMENT_DATA);
        if (CustomIntent.class.isAssignableFrom(cls)) {
            CustomIntent.performIntent(this, stringArray);
            finish();
        } else if (getIntent().hasExtra(WebviewFragment.HIDE_NAVIGATION) || getIntent().hasExtra(WebviewFragment.LOAD_DATA)) {
            openWebFragment(stringArray, getIntent().getExtras().getBoolean(WebviewFragment.HIDE_NAVIGATION), getIntent().getExtras().getString(WebviewFragment.LOAD_DATA));
        } else {
            openFragment(cls, stringArray);
        }
        Helper.admobLoader(this, findViewById(R.id.adView));
    }

    public void openFragment(Class<? extends Fragment> cls, String[] strArr) {
        if (checkPermissionsHandleIfNeeded(cls, strArr)) {
            try {
                Fragment fragment = (Fragment) cls.newInstance();
                Bundle bundle = new Bundle();
                bundle.putStringArray(MainActivity.FRAGMENT_DATA, strArr);
                fragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.container, fragment).commit();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e2) {
                e2.printStackTrace();
            }
        }
    }

    public void openWebFragment(String[] strArr, boolean z, String str) {
        WebviewFragment webviewFragment = new WebviewFragment();
        Bundle bundle = new Bundle();
        bundle.putStringArray(MainActivity.FRAGMENT_DATA, strArr);
        bundle.putBoolean(WebviewFragment.HIDE_NAVIGATION, z);
        if (str != null) {
            bundle.putString(WebviewFragment.LOAD_DATA, str);
        }
        webviewFragment.setArguments(bundle);
        getSupportFragmentManager().beginTransaction().replace(R.id.container, webviewFragment).commit();
        if (str == null) {
            setTitle(getResources().getString(R.string.webview_title));
        } else {
            setTitle("");
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.settings_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            finish();
            return true;
        } else if (itemId == R.id.favorites) {
            openFragment(FavFragment.class, new String[0]);
            return true;
        } else if (itemId != R.id.settings) {
            return super.onOptionsItemSelected(menuItem);
        } else {
            openFragment(SettingsFragment.class, new String[0]);
            return true;
        }
    }

    @Override // android.support.v4.app.FragmentActivity
    public void onBackPressed() {
        Fragment findFragmentById = getSupportFragmentManager().findFragmentById(R.id.container);
        if (!(findFragmentById instanceof BackPressFragment)) {
            super.onBackPressed();
        } else if (!((BackPressFragment) findFragmentById).handleBackPress()) {
            super.onBackPressed();
        }
    }

    private boolean checkPermissionsHandleIfNeeded(Class<? extends Fragment> cls, String[] strArr) {
        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        ArrayList<String> arrayList = new ArrayList();
        if (PermissionsFragment.class.isAssignableFrom(cls)) {
            try {
                arrayList.addAll(Arrays.asList(((PermissionsFragment) cls.newInstance()).requiredPermissions()));
            } catch (Exception unused) {
            }
        }
        if (arrayList.size() <= 1) {
            return true;
        }
        boolean z = true;
        for (String str : arrayList) {
            if (checkSelfPermission(str) != 0) {
                z = false;
            }
        }
        if (z) {
            return true;
        }
        requestPermissions((String[]) arrayList.toArray(new String[0]), 1);
        this.queueItem = cls;
        this.queueItemData = strArr;
        return false;
    }

    @Override // android.support.v4.app.ActivityCompat.OnRequestPermissionsResultCallback, android.support.v4.app.FragmentActivity
    @SuppressLint({"NewApi"})
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 1) {
            super.onRequestPermissionsResult(i, strArr, iArr);
            return;
        }
        boolean z = false;
        for (int i2 : iArr) {
            if (i2 != 0) {
                z = true;
            }
        }
        if (!z) {
            openFragment(this.queueItem, this.queueItemData);
        } else {
            Toast.makeText(this, getResources().getString(R.string.permissions_required), 0).show();
        }
    }

    @Override // android.support.v4.app.FragmentActivity
    public void onResume() {
        super.onResume();
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }
}

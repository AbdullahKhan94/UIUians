package com.thedaw.uiuians;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.dynamite.ProviderConstants;
import com.thedaw.uiuians.ConfigParser;
import com.thedaw.uiuians.drawer.MenuItemCallback;
import com.thedaw.uiuians.drawer.NavItem;
import com.thedaw.uiuians.drawer.SimpleMenu;
import com.thedaw.uiuians.drawer.TabAdapter;
import com.thedaw.uiuians.inherit.BackPressFragment;
import com.thedaw.uiuians.inherit.CollapseControllingFragment;
import com.thedaw.uiuians.inherit.ConfigurationChangeFragment;
import com.thedaw.uiuians.inherit.PermissionsFragment;
import com.thedaw.uiuians.providers.CustomIntent;
import com.thedaw.uiuians.providers.fav.ui.FavFragment;
import com.thedaw.uiuians.util.CustomScrollingViewBehavior;
import com.thedaw.uiuians.util.Helper;
import com.thedaw.uiuians.util.Log;
import com.thedaw.uiuians.util.ThemeUtils;
import com.thedaw.uiuians.util.layout.CustomAppBarLayout;
import com.thedaw.uiuians.util.layout.DisableableViewPager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements MenuItemCallback, ConfigParser.CallBack {
    public static String FRAGMENT_CLASS = "transation_target";
    public static String FRAGMENT_DATA = "transaction_data";
    private static final int PERMISSION_REQUESTCODE = 123;
    private static final String STATE_ACTIONS = "ACTIONS";
    private static final String STATE_MENU_INDEX = "MENUITEMINDEX";
    private static final String STATE_PAGER_INDEX = "VIEWPAGERPOSITION";
    private static SimpleMenu menu = null;
    private static String url = "http://ssbcledu.com/app-data/uiuians.json";
    String VersionUpdate;
    private TabAdapter adapter;
    private BottomNavigationView bottomNavigation;
    public DrawerLayout drawer;
    private int interstitialCount = -1;
    private InterstitialAd mInterstitialAd;
    public Toolbar mToolbar;
    private NavigationView navigationView;
    List<NavItem> queueItem;
    int queueMenuItemId;
    private Bundle savedInstanceState;
    private TabLayout tabLayout;
    private ActionBarDrawerToggle toggle;
    private DisableableViewPager viewPager;

    @Override // com.thedaw.uiuians.ConfigParser.CallBack
    public void configLoaded(boolean z) {
        if (z || menu.getFirstMenuItem() == null) {
            if (Helper.isOnlineShowDialog(this)) {
                Toast.makeText(this, (int) R.string.invalid_configuration, 1).show();
            }
        } else if (this.savedInstanceState == null) {
            menuItemClicked(menu.getFirstMenuItem(), 0, false);
        } else {
            int i = this.savedInstanceState.getInt(STATE_MENU_INDEX);
            int i2 = this.savedInstanceState.getInt(STATE_PAGER_INDEX);
            menuItemClicked((ArrayList) this.savedInstanceState.getSerializable(STATE_ACTIONS), i, false);
            this.viewPager.setCurrentItem(i2);
        }
    }

    @Override // android.support.v4.app.SupportActivity, android.support.v7.app.AppCompatActivity, android.support.v4.app.FragmentActivity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.savedInstanceState = bundle;
        ThemeUtils.setTheme(this);
        if (useTabletMenu()) {
            setContentView(R.layout.activity_main_tablet);
            Helper.setStatusBarColor(this, ThemeUtils.getPrimaryDarkColor(this));
        } else {
            setContentView(R.layout.activity_main);
        }
        new VersionCheck().execute(new Void[0]);
        this.mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(this.mToolbar);
        if (!useTabletMenu()) {
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        } else {
            getSupportActionBar().setDisplayShowHomeEnabled(false);
        }
        if (!useTabletMenu()) {
            this.drawer = (DrawerLayout) findViewById(R.id.drawer);
            this.toggle = new ActionBarDrawerToggle(this, this.drawer, this.mToolbar, R.string.drawer_open, R.string.drawer_close);
            this.drawer.setDrawerListener(this.toggle);
            this.toggle.syncState();
        }
        this.tabLayout = (TabLayout) findViewById(R.id.tabs);
        this.viewPager = (DisableableViewPager) findViewById(R.id.viewpager);
        this.bottomNavigation = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        this.navigationView = (NavigationView) findViewById(R.id.nav_view);
        menu = new SimpleMenu(this.navigationView.getMenu(), this);
        if (Config.USE_HARDCODED_CONFIG) {
            Config.configureMenu(menu, this);
        } else if ("".isEmpty() || !"".contains("http")) {
            new ConfigParser("config.json", menu, this, this).execute(new Void[0]);
        } else {
            new ConfigParser("", menu, this, this).execute(new Void[0]);
        }
        this.tabLayout.setupWithViewPager(this.viewPager);
        if (!useTabletMenu()) {
            this.drawer.setStatusBarBackgroundColor(ThemeUtils.getPrimaryDarkColor(this));
        }
        applyDrawerLocks();
        Helper.admobLoader(this, findViewById(R.id.adView));
        if (getResources().getString(R.string.admob_interstitial_id).length() > 0 && !SettingsFragment.getIsPurchased(this)) {
            this.mInterstitialAd = new InterstitialAd(this);
            this.mInterstitialAd.setAdUnitId(getResources().getString(R.string.admob_interstitial_id));
            this.mInterstitialAd.loadAd(new AdRequest.Builder().addTestDevice("B3EEABB8EE11C2BE770B684D95219ECB").build());
            this.mInterstitialAd.setAdListener(new AdListener() {
                /* class com.thedaw.uiuians.MainActivity.AnonymousClass1 */

                @Override // com.google.android.gms.ads.AdListener
                public void onAdClosed() {
                    MainActivity.this.mInterstitialAd.loadAd(new AdRequest.Builder().addTestDevice("B3EEABB8EE11C2BE770B684D95219ECB").build());
                }
            });
        }
        Helper.updateAndroidSecurityProvider(this);
        this.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            /* class com.thedaw.uiuians.MainActivity.AnonymousClass2 */

            @Override // android.support.v4.view.ViewPager.OnPageChangeListener
            public void onPageScrollStateChanged(int i) {
            }

            @Override // android.support.v4.view.ViewPager.OnPageChangeListener
            public void onPageScrolled(int i, float f, int i2) {
            }

            @Override // android.support.v4.view.ViewPager.OnPageChangeListener
            public void onPageSelected(int i) {
                if (MainActivity.this.bottomNavigation.getMenu().findItem(i) != null) {
                    MainActivity.this.bottomNavigation.getMenu().findItem(i).setChecked(true);
                }
                MainActivity.this.onTabBecomesActive(i);
            }
        });
    }

    private class VersionCheck extends AsyncTask<Void, Void, Void> {
        private VersionCheck() {
        }

        /* access modifiers changed from: protected */
        public void onPreExecute() {
            super.onPreExecute();
        }

        /* access modifiers changed from: protected */
        public Void doInBackground(Void... voidArr) {
            String makeServiceCall = new HttpHandler().makeServiceCall(MainActivity.url);
            if (makeServiceCall != null) {
                try {
                    JSONArray jSONArray = new JSONObject(makeServiceCall).getJSONArray("Version");
                    for (int i = 0; i < jSONArray.length(); i++) {
                        JSONObject jSONObject = jSONArray.getJSONObject(i);
                        MainActivity.this.VersionUpdate = jSONObject.getString(ProviderConstants.API_COLNAME_FEATURE_VERSION);
                    }
                    return null;
                } catch (JSONException e) {
                    MainActivity.this.runOnUiThread(new Runnable() {
                        /* class com.thedaw.uiuians.MainActivity.VersionCheck.AnonymousClass1 */

                        public void run() {
                            Context applicationContext = MainActivity.this.getApplicationContext();
                            Toast.makeText(applicationContext, "Json parsing error: " + e.getMessage(), 1).show();
                        }
                    });
                    return null;
                }
            } else {
                MainActivity.this.runOnUiThread(new Runnable() {
                    /* class com.thedaw.uiuians.MainActivity.VersionCheck.AnonymousClass2 */

                    public void run() {
                        Toast.makeText(MainActivity.this.getApplicationContext(), "Couldn't get json from server. Check LogCat for possible errors!", 1).show();
                    }
                });
                return null;
            }
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Void r4) {
            super.onPostExecute((Object) r4);
            if (!MainActivity.this.VersionUpdate.equals(BuildConfig.VERSION_NAME)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Our App got Update");
                builder.setIcon(R.drawable.ic_launcher);
                builder.setCancelable(false);
                builder.setMessage("New version available, select update to update our app").setPositiveButton("UPDATE", new DialogInterface.OnClickListener() {
                    /* class com.thedaw.uiuians.MainActivity.VersionCheck.AnonymousClass3 */

                    public void onClick(DialogInterface dialogInterface, int i) {
                        String packageName = MainActivity.this.getPackageName();
                        try {
                            MainActivity mainActivity = MainActivity.this;
                            mainActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + packageName)));
                        } catch (ActivityNotFoundException unused) {
                            MainActivity mainActivity2 = MainActivity.this;
                            mainActivity2.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + packageName)));
                        }
                        MainActivity.this.finish();
                    }
                });
                builder.create().show();
            }
        }
    }

    @Override // android.support.v4.app.ActivityCompat.OnRequestPermissionsResultCallback, android.support.v4.app.FragmentActivity
    @SuppressLint({"NewApi"})
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != PERMISSION_REQUESTCODE) {
            super.onRequestPermissionsResult(i, strArr, iArr);
            return;
        }
        boolean z = true;
        for (int i2 : iArr) {
            if (i2 != 0) {
                z = false;
            }
        }
        if (z) {
            menuItemClicked(this.queueItem, this.queueMenuItemId, false);
        } else {
            Toast.makeText(this, getResources().getString(R.string.permissions_required), 0).show();
        }
    }

    @Override // com.thedaw.uiuians.drawer.MenuItemCallback
    public void menuItemClicked(List<NavItem> list, int i, boolean z) {
        boolean z2 = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getBoolean("menuOpenOnStart", false);
        if (this.drawer != null) {
            boolean z3 = this.savedInstanceState == null && this.adapter == null;
            if (!z2 || useTabletMenu() || !z3) {
                this.drawer.closeDrawer(GravityCompat.START);
            } else {
                this.drawer.openDrawer(GravityCompat.START);
            }
        }
        if ((!z || isPurchased()) && checkPermissionsHandleIfNeeded(list, i) && !isCustomIntent(list)) {
            for (MenuItem menuItem : menu.getMenuItems()) {
                if (menuItem.getItemId() == i) {
                    menuItem.setChecked(true);
                } else {
                    menuItem.setChecked(false);
                }
            }
            this.adapter = new TabAdapter(getSupportFragmentManager(), list, this);
            this.viewPager.setAdapter(this.adapter);
            configureBottomNavigation(list);
            if (list.size() == 1) {
                this.bottomNavigation.setVisibility(8);
                this.tabLayout.setVisibility(8);
                this.viewPager.setPagingEnabled(false);
            } else {
                if (Config.BOTTOM_TABS) {
                    this.bottomNavigation.setVisibility(0);
                } else {
                    this.tabLayout.setVisibility(0);
                }
                this.viewPager.setPagingEnabled(true);
            }
            showInterstitial();
            onTabBecomesActive(0);
        }
    }

    private void configureBottomNavigation(List<NavItem> list) {
        if (Config.BOTTOM_TABS) {
            this.bottomNavigation.getMenu().clear();
            Iterator<NavItem> it = list.iterator();
            int i = 0;
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                NavItem next = it.next();
                if (i == 5) {
                    Toast.makeText(this, "With BottomTabs, you can not shown more than 5 entries. Remove some tabs to hide this message.", 1).show();
                    break;
                } else {
                    this.bottomNavigation.getMenu().add(0, i, 0, next.getText(this)).setIcon(next.getTabIcon());
                    i++;
                }
            }
            this.bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                /* class com.thedaw.uiuians.MainActivity.AnonymousClass3 */

                @Override // android.support.design.widget.BottomNavigationView.OnNavigationItemSelectedListener
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    MainActivity.this.viewPager.setCurrentItem(menuItem.getItemId());
                    return false;
                }
            });
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void onTabBecomesActive(int i) {
        Fragment item = this.adapter.getItem(i);
        boolean z = item instanceof CollapseControllingFragment;
        if ((!z || ((CollapseControllingFragment) item).supportsCollapse()) && Build.VERSION.SDK_INT > 19) {
            unlockAppBar();
        } else {
            lockAppBar();
        }
        if ((!z || ((CollapseControllingFragment) item).dynamicToolbarElevation()) && ThemeUtils.lightToolbarThemeActive(this)) {
            dynamicElevationAppBar(true);
        } else {
            dynamicElevationAppBar(false);
        }
        ((CustomAppBarLayout) this.mToolbar.getParent()).setExpanded(true, true);
        if (i != 0) {
            showInterstitial();
        }
    }

    public void showInterstitial() {
        if (this.interstitialCount == 1) {
            if (this.mInterstitialAd != null && this.mInterstitialAd.isLoaded()) {
                this.mInterstitialAd.show();
            }
            this.interstitialCount = 0;
            return;
        }
        this.interstitialCount++;
    }

    private boolean isCustomIntent(List<NavItem> list) {
        NavItem navItem = null;
        for (NavItem navItem2 : list) {
            if (CustomIntent.class.isAssignableFrom(navItem2.getFragment())) {
                navItem = navItem2;
            }
        }
        if (navItem == null) {
            return false;
        }
        if (list.size() > 1) {
            Log.e("INFO", "Custom Intent Item must be only child of menu item! Ignoring all other tabs");
        }
        CustomIntent.performIntent(this, navItem.getData());
        return true;
    }

    private boolean isPurchased() {
        String string = getResources().getString(R.string.google_play_license);
        if (SettingsFragment.getIsPurchased(this) || string.equals("")) {
            return true;
        }
        HolderActivity.startActivity(this, SettingsFragment.class, new String[]{SettingsFragment.SHOW_DIALOG});
        return false;
    }

    private boolean checkPermissionsHandleIfNeeded(List<NavItem> list, int i) {
        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        ArrayList<String> arrayList = new ArrayList();
        Iterator<NavItem> it = list.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            NavItem next = it.next();
            if (PermissionsFragment.class.isAssignableFrom(next.getFragment())) {
                try {
                    String[] requiredPermissions = ((PermissionsFragment) next.getFragment().newInstance()).requiredPermissions();
                    for (String str : requiredPermissions) {
                        if (!arrayList.contains(str)) {
                            arrayList.add(str);
                        }
                    }
                } catch (Exception unused) {
                }
            }
        }
        if (arrayList.size() <= 1) {
            return true;
        }
        boolean z = true;
        for (String str2 : arrayList) {
            if (checkSelfPermission(str2) != 0) {
                z = false;
            }
        }
        if (z) {
            return true;
        }
        requestPermissions((String[]) arrayList.toArray(new String[0]), PERMISSION_REQUESTCODE);
        this.queueItem = list;
        this.queueMenuItemId = i;
        return false;
    }

    public boolean onCreateOptionsMenu(Menu menu2) {
        getMenuInflater().inflate(R.menu.settings_menu, menu2);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.favorites) {
            HolderActivity.startActivity(this, FavFragment.class, null);
            return true;
        } else if (itemId != R.id.settings) {
            return super.onOptionsItemSelected(menuItem);
        } else {
            HolderActivity.startActivity(this, SettingsFragment.class, null);
            return true;
        }
    }

    @Override // android.support.v4.app.FragmentActivity
    public void onBackPressed() {
        Fragment currentFragment = this.adapter != null ? this.adapter.getCurrentFragment() : null;
        if (this.drawer != null && this.drawer.isDrawerOpen(GravityCompat.START)) {
            this.drawer.closeDrawer(GravityCompat.START);
        } else if (!(currentFragment instanceof BackPressFragment)) {
            super.onBackPressed();
        } else if (!((BackPressFragment) currentFragment).handleBackPress()) {
            super.onBackPressed();
        }
    }

    /* access modifiers changed from: protected */
    @Override // android.support.v4.app.FragmentActivity
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        List<Fragment> fragments = getSupportFragmentManager().getFragments();
        if (fragments != null) {
            for (Fragment fragment : fragments) {
                if (fragment != null) {
                    fragment.onActivityResult(i, i2, intent);
                }
            }
        }
    }

    @Override // android.support.v7.app.AppCompatActivity, android.support.v4.app.FragmentActivity
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (this.adapter != null && !(this.adapter.getCurrentFragment() instanceof ConfigurationChangeFragment)) {
            recreate();
        }
    }

    /* access modifiers changed from: protected */
    @Override // android.support.v4.app.SupportActivity, android.support.v7.app.AppCompatActivity, android.support.v4.app.FragmentActivity
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (this.adapter != null) {
            int i = 0;
            Iterator<MenuItem> it = menu.getMenuItems().iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                MenuItem next = it.next();
                if (next.isChecked()) {
                    i = next.getItemId();
                    break;
                }
            }
            bundle.putSerializable(STATE_ACTIONS, (ArrayList) this.adapter.getActions());
            bundle.putInt(STATE_MENU_INDEX, i);
            bundle.putInt(STATE_PAGER_INDEX, this.viewPager.getCurrentItem());
        }
    }

    public boolean useTabletMenu() {
        return getResources().getBoolean(R.bool.isWideTablet);
    }

    public void applyDrawerLocks() {
        if (this.drawer != null) {
            this.drawer.setDrawerLockMode(0);
        }
    }

    private void lockAppBar() {
        ((AppBarLayout.LayoutParams) this.mToolbar.getLayoutParams()).setScrollFlags(0);
    }

    private void unlockAppBar() {
        ((AppBarLayout.LayoutParams) this.mToolbar.getLayoutParams()).setScrollFlags(5);
    }

    private void dynamicElevationAppBar(boolean z) {
        ((CustomScrollingViewBehavior) ((CoordinatorLayout.LayoutParams) ((RelativeLayout) this.viewPager.getParent()).getLayoutParams()).getBehavior()).setDynamicElevation(z);
        this.mToolbar.requestLayout();
    }
}

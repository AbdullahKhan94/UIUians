package com.thedaw.uiuians.util.layout;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ListView;
import android.widget.ScrollView;

public class TrackingScrollView extends ScrollView {
    private OnScrollChangedListener mOnScrollChangedListener;

    public interface OnScrollChangedListener {
        void onScrollChanged(TrackingScrollView trackingScrollView, int i, int i2, int i3, int i4);
    }

    public TrackingScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public TrackingScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public void setOnScrollChangedListener(OnScrollChangedListener onScrollChangedListener) {
        this.mOnScrollChangedListener = onScrollChangedListener;
    }

    /* access modifiers changed from: protected */
    public void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
        if (this.mOnScrollChangedListener != null) {
            this.mOnScrollChangedListener.onScrollChanged(this, i, i2, i3, i4);
        }
    }

    public void requestChildFocus(View view, View view2) {
        if (!(view2 instanceof ListView)) {
            super.requestChildFocus(view, view2);
        }
    }
}

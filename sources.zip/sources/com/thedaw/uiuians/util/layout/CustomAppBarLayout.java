package com.thedaw.uiuians.util.layout;

import android.content.Context;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.util.AttributeSet;
import java.util.ArrayList;
import java.util.List;

public class CustomAppBarLayout extends AppBarLayout implements AppBarLayout.OnOffsetChangedListener {
    private List<OnStateChangeListener> onStateChangeListeners;
    private State state;

    public interface OnStateChangeListener {
        void onStateChange(State state);
    }

    public enum State {
        COLLAPSED,
        EXPANDED,
        IDLE
    }

    public CustomAppBarLayout(Context context) {
        super(context);
    }

    public CustomAppBarLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean isToolbarHidden() {
        return this.state == State.COLLAPSED;
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!(getLayoutParams() instanceof CoordinatorLayout.LayoutParams) || !(getParent() instanceof CoordinatorLayout)) {
            throw new IllegalStateException("MyAppBarLayout must be a direct child of CoordinatorLayout.");
        }
        addOnOffsetChangedListener(this);
    }

    @Override // android.support.design.widget.AppBarLayout.OnOffsetChangedListener
    public void onOffsetChanged(AppBarLayout appBarLayout, int i) {
        if (i == 0) {
            if (this.state != State.EXPANDED) {
                notifyListeners(State.EXPANDED);
            }
            this.state = State.EXPANDED;
        } else if (Math.abs(i) >= appBarLayout.getTotalScrollRange()) {
            if (this.state != State.COLLAPSED) {
                notifyListeners(State.COLLAPSED);
            }
            this.state = State.COLLAPSED;
        } else {
            if (this.state != State.IDLE) {
                notifyListeners(State.IDLE);
            }
            this.state = State.IDLE;
        }
    }

    private void notifyListeners(State state2) {
        if (this.onStateChangeListeners != null) {
            for (OnStateChangeListener onStateChangeListener : this.onStateChangeListeners) {
                onStateChangeListener.onStateChange(state2);
            }
        }
    }

    public void addOnStateChangeListener(OnStateChangeListener onStateChangeListener) {
        if (this.onStateChangeListeners == null) {
            this.onStateChangeListeners = new ArrayList();
        }
        this.onStateChangeListeners.add(onStateChangeListener);
    }

    public void removeOnStateChangeListener(OnStateChangeListener onStateChangeListener) {
        if (this.onStateChangeListeners != null) {
            this.onStateChangeListeners.remove(onStateChangeListener);
        }
    }
}

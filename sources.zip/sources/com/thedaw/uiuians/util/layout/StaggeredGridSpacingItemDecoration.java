package com.thedaw.uiuians.util.layout;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;

public class StaggeredGridSpacingItemDecoration extends RecyclerView.ItemDecoration {
    private boolean headerItemNoSpacing;
    private int spacing;

    public StaggeredGridSpacingItemDecoration(int i, boolean z) {
        this.spacing = i;
        this.headerItemNoSpacing = z;
    }

    @Override // android.support.v7.widget.RecyclerView.ItemDecoration
    public void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
        int spanCount = ((StaggeredGridLayoutManager) recyclerView.getLayoutManager()).getSpanCount();
        StaggeredGridLayoutManager.LayoutParams layoutParams = (StaggeredGridLayoutManager.LayoutParams) view.getLayoutParams();
        int i = 0;
        if (!layoutParams.isFullSpan()) {
            int spanIndex = layoutParams.getSpanIndex();
            int viewLayoutPosition = layoutParams.getViewLayoutPosition();
            int itemCount = recyclerView.getAdapter().getItemCount();
            boolean z = true;
            boolean z2 = spanIndex == 0;
            boolean z3 = spanIndex == spanCount + -1;
            boolean z4 = spanIndex < spanCount;
            if (viewLayoutPosition < itemCount - spanCount) {
                z = false;
            }
            int i2 = this.spacing / 2;
            int i3 = z2 ? this.spacing : i2;
            int i4 = z4 ? this.spacing : i2;
            if (z3) {
                i2 = this.spacing;
            }
            if (z) {
                i = this.spacing;
            }
            rect.set(i3, i4, i2, i);
        } else if (this.headerItemNoSpacing) {
            rect.set(0, 0, 0, 0);
        } else {
            view.setPadding(this.spacing, this.spacing, this.spacing, this.spacing);
        }
    }
}

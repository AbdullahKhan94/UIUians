package com.thedaw.uiuians.util.layout;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.RectF;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;
import com.thedaw.uiuians.R;

public class RoundedImageView extends AppCompatImageView {
    private Path path;
    private RectF rect;

    public RoundedImageView(Context context) {
        super(context);
        init();
    }

    public RoundedImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    public RoundedImageView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }

    private void init() {
        this.path = new Path();
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        this.rect = new RectF(0.0f, 0.0f, (float) getWidth(), (float) getHeight());
        float dimension = getResources().getDimension(R.dimen.thumbnail_radius);
        this.path.addRoundRect(this.rect, dimension, dimension, Path.Direction.CW);
        canvas.clipPath(this.path);
        canvas.clipRect(this.rect);
        super.onDraw(canvas);
    }
}

package com.thedaw.uiuians.util.layout;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;

public class ExpandedListView extends ListView {
    private int oldCount = 0;
    private ViewGroup.LayoutParams params;

    public ExpandedListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        if (getCount() != 0) {
            ListAdapter adapter = getAdapter();
            if (adapter != null) {
                int count = adapter.getCount();
                int i = 0;
                for (int i2 = 0; i2 < count; i2++) {
                    View view = adapter.getView(i2, null, this);
                    view.measure(View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.makeMeasureSpec(getWidth(), 1073741824), Integer.MIN_VALUE), View.MeasureSpec.makeMeasureSpec(0, 0));
                    i += view.getMeasuredHeight();
                }
                ViewGroup.LayoutParams layoutParams = getLayoutParams();
                layoutParams.height = i + (getDividerHeight() * (adapter.getCount() - 1));
                setLayoutParams(layoutParams);
            } else {
                return;
            }
        }
        super.onDraw(canvas);
    }
}

package com.thedaw.uiuians.util;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.TypedValue;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.util.layout.TrackingScrollView;

public abstract class DetailActivity extends AppCompatActivity {
    boolean FadeBar = true;
    protected RelativeLayout coolblue;
    protected int latestAlpha;
    protected int mScrollableHeaderHeight;
    protected Toolbar mToolbar;
    protected ImageView thumb;

    @Override // android.support.v7.app.AppCompatActivity, android.support.v4.app.SupportActivity, android.support.v4.app.FragmentActivity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ThemeUtils.setTheme(this);
    }

    /* access modifiers changed from: protected */
    public void setUpHeader(String str) {
        if (isTablet()) {
            this.FadeBar = false;
        } else {
            this.coolblue.setVisibility(8);
        }
        if (str != null && !str.equals("") && !str.equals("null")) {
            setParralaxHeader();
        } else if (!isTablet()) {
            this.thumb.getLayoutParams().height = getActionBarHeight();
            this.FadeBar = false;
        } else if (isTablet()) {
            setParralaxHeader();
            this.thumb.getLayoutParams().height = 0;
        }
        if (this.FadeBar) {
            this.mToolbar.getBackground().mutate().setAlpha(0);
            Helper.setStatusBarColor(this, getStartColor(this));
            getSupportActionBar().setDisplayShowTitleEnabled(false);
            ThemeUtils.setToolbarContentColor(this.mToolbar, ContextCompat.getColor(this, R.color.white));
        }
    }

    private void setParralaxHeader() {
        if (isTablet()) {
            this.mScrollableHeaderHeight = this.coolblue.getLayoutParams().height;
        } else {
            this.mScrollableHeaderHeight = this.thumb.getLayoutParams().height;
            this.thumb.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                /* class com.thedaw.uiuians.util.DetailActivity.AnonymousClass1 */

                public void onGlobalLayout() {
                    DetailActivity.this.thumb.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    DetailActivity.this.mScrollableHeaderHeight = DetailActivity.this.thumb.getHeight();
                }
            });
        }
        ((TrackingScrollView) findViewById(R.id.scroller)).setOnScrollChangedListener(new TrackingScrollView.OnScrollChangedListener() {
            /* class com.thedaw.uiuians.util.DetailActivity.AnonymousClass2 */

            @Override // com.thedaw.uiuians.util.layout.TrackingScrollView.OnScrollChangedListener
            public void onScrollChanged(TrackingScrollView trackingScrollView, int i, int i2, int i3, int i4) {
                DetailActivity.this.handleScroll(i2);
            }
        });
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void handleScroll(int i) {
        int i2;
        ViewGroup.MarginLayoutParams marginLayoutParams;
        int min = !isTablet() ? Math.min(this.mScrollableHeaderHeight, Math.max(0, i)) : i;
        if (isTablet()) {
            marginLayoutParams = (ViewGroup.MarginLayoutParams) this.coolblue.getLayoutParams();
            i2 = this.mScrollableHeaderHeight - (min / 2);
        } else {
            marginLayoutParams = (ViewGroup.MarginLayoutParams) this.thumb.getLayoutParams();
            i2 = this.mScrollableHeaderHeight - min;
        }
        if (marginLayoutParams.height != i2) {
            marginLayoutParams.height = i2;
            if (!isTablet()) {
                marginLayoutParams.topMargin = min;
                this.thumb.setLayoutParams(marginLayoutParams);
            } else {
                this.coolblue.setLayoutParams(marginLayoutParams);
            }
        }
        if (this.FadeBar) {
            int height = this.thumb.getHeight() - getSupportActionBar().getHeight();
            float min2 = ((float) Math.min(Math.max(i, 0), height)) / ((float) height);
            int i3 = (int) (255.0f * min2);
            if (i3 != this.latestAlpha) {
                this.mToolbar.getBackground().mutate().setAlpha(i3);
                if (ThemeUtils.lightToolbarThemeActive(this)) {
                    ThemeUtils.setToolbarContentColor(this.mToolbar, blendToolbarContentColors(min2));
                } else {
                    Helper.setStatusBarColor(this, blendStatusBarColors(min2, this));
                }
            }
            this.latestAlpha = i3;
        }
    }

    /* access modifiers changed from: protected */
    public void onMenuItemsSet(Menu menu) {
        if (!this.FadeBar) {
            ThemeUtils.tintAllIcons(menu, this);
        }
    }

    private boolean isTablet() {
        return getResources().getBoolean(R.bool.isTablet);
    }

    private int getActionBarHeight() {
        int height = getSupportActionBar().getHeight();
        if (height != 0) {
            return height;
        }
        TypedValue typedValue = new TypedValue();
        return getTheme().resolveAttribute(16843499, typedValue, true) ? TypedValue.complexToDimensionPixelSize(typedValue.data, getResources().getDisplayMetrics()) : height;
    }

    private static int blendStatusBarColors(float f, Context context) {
        return blendColors(ThemeUtils.getPrimaryDarkColor(context), ContextCompat.getColor(context, R.color.black), f);
    }

    private static int blendToolbarContentColors(float f) {
        return blendColors(ViewCompat.MEASURED_STATE_MASK, -1, f);
    }

    private static int blendColors(int i, int i2, float f) {
        float f2 = 1.0f - f;
        return Color.rgb((int) ((((float) Color.red(i)) * f) + (((float) Color.red(i2)) * f2)), (int) ((((float) Color.green(i)) * f) + (((float) Color.green(i2)) * f2)), (int) ((((float) Color.blue(i)) * f) + (((float) Color.blue(i2)) * f2)));
    }

    private static int getStartColor(Context context) {
        if (ThemeUtils.lightToolbarThemeActive(context)) {
            return ThemeUtils.getPrimaryDarkColor(context);
        }
        return ContextCompat.getColor(context, R.color.black);
    }

    @Override // android.support.v4.app.FragmentActivity
    public void onPause() {
        super.onPause();
        this.mToolbar.getBackground().mutate().setAlpha(255);
    }

    @Override // android.support.v4.app.FragmentActivity
    public void onResume() {
        super.onResume();
        if (this.FadeBar) {
            this.mToolbar.getBackground().mutate().setAlpha(this.latestAlpha);
        }
    }
}

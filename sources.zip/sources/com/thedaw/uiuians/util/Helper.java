package com.thedaw.uiuians.util;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.util.CrashUtils;
import com.google.android.gms.security.ProviderInstaller;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.SettingsFragment;
import io.fabric.sdk.android.services.network.HttpRequest;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import org.json.JSONArray;
import org.json.JSONObject;

public class Helper {
    private static boolean DISPLAY_DEBUG = false;

    public static int getGradient(int i) {
        switch (i) {
            case 1:
                return R.drawable.gradient_one;
            case 2:
                return R.drawable.gradient_two;
            case 3:
                return R.drawable.gradient_five;
            case 4:
                return R.drawable.gradient_four;
            default:
                return R.drawable.gradient_three;
        }
    }

    public static void noConnection(Activity activity, String str) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        if (isOnline(activity)) {
            String str2 = "";
            if (str != null && DISPLAY_DEBUG) {
                str2 = "\n\n" + str;
            }
            builder.setMessage(activity.getResources().getString(R.string.dialog_connection_description) + str2);
            builder.setPositiveButton(activity.getResources().getString(R.string.ok), (DialogInterface.OnClickListener) null);
            builder.setTitle(activity.getResources().getString(R.string.dialog_connection_title));
        } else {
            builder.setMessage(activity.getResources().getString(R.string.dialog_internet_description));
            builder.setPositiveButton(activity.getResources().getString(R.string.ok), (DialogInterface.OnClickListener) null);
            builder.setTitle(activity.getResources().getString(R.string.dialog_internet_title));
        }
        if (!activity.isFinishing()) {
            builder.show();
        }
    }

    public static void noConnection(Activity activity) {
        noConnection(activity, null);
    }

    public static boolean isOnline(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public static boolean isOnlineShowDialog(Activity activity) {
        if (isOnline(activity)) {
            return true;
        }
        noConnection(activity);
        return false;
    }

    @Deprecated
    public static void admobLoader(Context context, Resources resources, View view) {
        admobLoader(context, view);
    }

    public static void admobLoader(Context context, View view) {
        if (!context.getResources().getString(R.string.admob_banner_id).equals("") && !SettingsFragment.getIsPurchased(context)) {
            AdView adView = (AdView) view;
            adView.setVisibility(0);
            AdRequest.Builder builder = new AdRequest.Builder();
            builder.addTestDevice("B3EEABB8EE11C2BE770B684D95219ECB");
            adView.loadAd(builder.build());
        }
    }

    @SuppressLint({"NewApi"})
    public static void setStatusBarColor(Activity activity, int i) {
        try {
            if (Build.VERSION.SDK_INT >= 21) {
                activity.getWindow().setStatusBarColor(i);
            }
        } catch (Exception e) {
            Log.printStackTrace(e);
        }
    }

    public static String loadJSONFromAsset(Context context, String str) {
        try {
            InputStream open = context.getAssets().open(str);
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            open.close();
            return new String(bArr, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void showEmptyView(Fragment fragment, int i, int i2) {
        if (fragment != null && fragment.getActivity() != null) {
            ViewGroup viewGroup = (ViewGroup) fragment.getView();
            viewGroup.findViewById(R.id.empty_view).setVisibility(0);
            viewGroup.findViewById(R.id.list).setVisibility(8);
            ((TextView) viewGroup.findViewById(R.id.title)).setText(fragment.getString(i));
            ((TextView) viewGroup.findViewById(R.id.subtitle)).setText(fragment.getString(i2));
        }
    }

    public static void hideEmptyView(Fragment fragment) {
        ViewGroup viewGroup = (ViewGroup) fragment.getView();
        if (viewGroup != null && viewGroup.findViewById(R.id.empty_view) != null) {
            viewGroup.findViewById(R.id.empty_view).setVisibility(8);
            viewGroup.findViewById(R.id.list).setVisibility(0);
        }
    }

    public static String formatValue(double d) {
        if (d <= 0.0d) {
            return "0";
        }
        DecimalFormat decimalFormat = new DecimalFormat("#,###.#");
        int log10 = ((int) StrictMath.log10(d)) / 3;
        String str = decimalFormat.format(d / Math.pow(10.0d, (double) (log10 * 3))) + " kmbt".charAt(log10);
        return str.length() > 4 ? str.replaceAll("\\.[0-9]+", "") : str;
    }

    public static String getDataFromUrl(String str) {
        Log.v("INFO", "Requesting: " + str);
        StringBuffer stringBuffer = new StringBuffer("");
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection.setRequestProperty("User-Agent", "Universal/2.0 (Android)");
            httpURLConnection.setRequestMethod(HttpRequest.METHOD_GET);
            httpURLConnection.setDoInput(true);
            httpURLConnection.connect();
            int responseCode = httpURLConnection.getResponseCode();
            if (responseCode != 200 && (responseCode == 302 || responseCode == 301 || responseCode == 303)) {
                String headerField = httpURLConnection.getHeaderField(HttpRequest.HEADER_LOCATION);
                String headerField2 = httpURLConnection.getHeaderField("Set-Cookie");
                HttpURLConnection httpURLConnection2 = (HttpURLConnection) new URL(headerField).openConnection();
                httpURLConnection2.setRequestProperty("Cookie", headerField2);
                httpURLConnection2.setRequestProperty("User-Agent", "Universal/2.0 (Android)");
                httpURLConnection2.setRequestMethod(HttpRequest.METHOD_GET);
                httpURLConnection2.setDoInput(true);
                Log.v("INFO", "Redirect to URL : " + headerField);
                httpURLConnection = httpURLConnection2;
            }
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                stringBuffer.append(readLine);
            }
        } catch (IOException e) {
            Log.printStackTrace(e);
        }
        return stringBuffer.toString();
    }

    public static JSONObject getJSONObjectFromUrl(String str) {
        try {
            return new JSONObject(getDataFromUrl(str));
        } catch (Exception e) {
            Log.e("INFO", "Error parsing JSON. Printing stacktrace now");
            Log.printStackTrace(e);
            return null;
        }
    }

    public static JSONArray getJSONArrayFromUrl(String str) {
        try {
            return new JSONArray(getDataFromUrl(str));
        } catch (Exception e) {
            Log.e("INFO", "Error parsing JSON. Printing stacktrace now");
            Log.printStackTrace(e);
            return null;
        }
    }

    public static void updateAndroidSecurityProvider(Activity activity) {
        if (Build.VERSION.SDK_INT < 21) {
            try {
                ProviderInstaller.installIfNeeded(activity);
            } catch (GooglePlayServicesRepairableException e) {
                GoogleApiAvailability.getInstance().getErrorDialog(activity, e.getConnectionStatusCode(), 0);
            } catch (GooglePlayServicesNotAvailableException unused) {
                Log.e("SecurityException", "Google Play Services not available.");
            }
        }
    }

    public static void download(Activity activity, String str) {
        if (hasPermissionToDownload(activity)) {
            if (str == null) {
                Toast.makeText(activity, activity.getResources().getString(R.string.download_unavailable), 1).show();
                return;
            }
            Uri parse = Uri.parse(str);
            String substring = str.substring(str.lastIndexOf("/"), str.length());
            DownloadManager.Request request = new DownloadManager.Request(parse);
            request.setAllowedNetworkTypes(3);
            request.setNotificationVisibility(1);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, substring);
            final Long valueOf = Long.valueOf(((DownloadManager) activity.getSystemService("download")).enqueue(request));
            activity.registerReceiver(new BroadcastReceiver() {
                /* class com.thedaw.uiuians.util.Helper.AnonymousClass1 */

                public void onReceive(Context context, Intent intent) {
                    long longExtra = intent.getLongExtra("extra_download_id", 0);
                    if (longExtra == valueOf.longValue()) {
                        context.unregisterReceiver(this);
                        DownloadManager downloadManager = (DownloadManager) context.getSystemService("download");
                        DownloadManager.Query query = new DownloadManager.Query();
                        query.setFilterById(longExtra);
                        Cursor query2 = downloadManager.query(query);
                        if (query2.moveToFirst()) {
                            if (8 != query2.getInt(query2.getColumnIndex("status"))) {
                                Toast.makeText(context, context.getResources().getString(R.string.download_failed), 1).show();
                                return;
                            }
                            String string = query2.getString(query2.getColumnIndex("local_uri"));
                            Uri uriForFile = FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".provider", new File(Uri.parse(string).getPath()));
                            Intent intent2 = new Intent("android.intent.action.VIEW");
                            intent2.setData(uriForFile);
                            intent2.setFlags(CrashUtils.ErrorDialogData.BINDER_CRASH).setFlags(1);
                            intent2.setDataAndType(uriForFile, downloadManager.getMimeTypeForDownloadedFile(longExtra));
                            if (context.getPackageManager().queryIntentActivities(intent2, 0).size() > 0) {
                                context.startActivity(intent2);
                            } else {
                                Toast.makeText(context, context.getResources().getString(R.string.download_open_failed), 1).show();
                            }
                        }
                    }
                }
            }, new IntentFilter("android.intent.action.DOWNLOAD_COMPLETE"));
        }
    }

    public static boolean hasPermissionToDownload(final Activity activity) {
        if (Build.VERSION.SDK_INT < 23 || ContextCompat.checkSelfPermission(activity, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            return true;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setMessage(R.string.download_permission_explaination);
        builder.setPositiveButton(R.string.download_permission_grant, new DialogInterface.OnClickListener() {
            /* class com.thedaw.uiuians.util.Helper.AnonymousClass2 */

            public void onClick(DialogInterface dialogInterface, int i) {
                if (Build.VERSION.SDK_INT >= 23) {
                    activity.requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 1);
                }
            }
        });
        builder.create().show();
        return false;
    }
}

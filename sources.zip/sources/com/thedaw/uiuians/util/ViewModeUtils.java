package com.thedaw.uiuians.util;

import android.content.Context;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import com.thedaw.uiuians.R;
import com.thedaw.uiuians.providers.rss.ui.RssFragment;
import com.thedaw.uiuians.providers.woocommerce.ui.WooCommerceFragment;
import com.thedaw.uiuians.providers.wordpress.ui.WordpressFragment;
import com.thedaw.uiuians.providers.youtube.ui.YoutubeFragment;

public class ViewModeUtils {
    public static final int COMPACT = 0;
    public static final int IMMERSIVE = 2;
    public static final int NORMAL = 1;
    public static final int UNKNOWN = -1;
    private Context context;
    private Class mClass;

    public interface ChangeListener {
        void modeChanged();
    }

    public void inflateOptionsMenu(Menu menu, MenuInflater menuInflater) {
    }

    public ViewModeUtils(Context context2, Class cls) {
        this.context = context2;
        this.mClass = cls;
    }

    private boolean immersiveSupported() {
        return this.mClass.equals(WordpressFragment.class) || this.mClass.equals(YoutubeFragment.class);
    }

    public boolean handleSelection(MenuItem menuItem, ChangeListener changeListener) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.compact) {
            menuItem.setChecked(true);
            saveToPreferences(0);
            changeListener.modeChanged();
            return true;
        } else if (itemId == R.id.immersive) {
            menuItem.setChecked(true);
            saveToPreferences(2);
            changeListener.modeChanged();
            return true;
        } else if (itemId != R.id.normal) {
            return false;
        } else {
            menuItem.setChecked(true);
            saveToPreferences(1);
            changeListener.modeChanged();
            return true;
        }
    }

    public void saveToPreferences(int i) {
        PreferenceManager.getDefaultSharedPreferences(this.context).edit().putInt(this.mClass.getName(), i).apply();
    }

    private int getFromPreferences() {
        return PreferenceManager.getDefaultSharedPreferences(this.context).getInt(this.mClass.getName(), -1);
    }

    public int getViewMode() {
        int i;
        if (!this.mClass.equals(WordpressFragment.class)) {
            if (this.mClass.equals(RssFragment.class)) {
                i = 2;
            } else if (!this.mClass.equals(YoutubeFragment.class) && !this.mClass.equals(WooCommerceFragment.class)) {
                i = -1;
            }
            if ((i == 2 || immersiveSupported()) && i != -1) {
                return i;
            }
            return 1;
        }
        i = 1;
        if (i == 2) {
        }
        return i;
    }
}

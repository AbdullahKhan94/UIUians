package com.thedaw.uiuians.util;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import com.thedaw.uiuians.R;

public abstract class InfiniteRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public static final int MODE_EMPTY = 2;
    public static final int MODE_LIST = 1;
    public static final int MODE_PROGRESS = 3;
    private static final int VIEW_TYPE_EMPTY = -3;
    private static final int VIEW_TYPE_LOAD_MORE = -1;
    private static final int VIEW_TYPE_PROGRESS = -2;
    private View.OnClickListener emptyViewButtonListener;
    private String emptyViewButtonTitle;
    private String emptyViewSubTitle;
    private String emptyViewTitle;
    private int mCurrentMode = 1;
    private int mEmptyResourceId;
    private boolean mHasMore;
    private LayoutInflater mInflater;
    private LoadMoreListener mListener;
    private int mMoreResourceId;
    private int mProgressResourceId;

    public interface LoadMoreListener {
        void onMoreRequested();
    }

    /* access modifiers changed from: protected */
    public abstract void doBindViewHolder(RecyclerView.ViewHolder viewHolder, int i);

    /* access modifiers changed from: protected */
    public abstract int getCount();

    /* access modifiers changed from: protected */
    public abstract RecyclerView.ViewHolder getViewHolder(ViewGroup viewGroup, int i);

    /* access modifiers changed from: protected */
    public abstract int getViewType(int i);

    public InfiniteRecyclerViewAdapter(Context context, LoadMoreListener loadMoreListener) {
        this.mInflater = LayoutInflater.from(context);
        this.mListener = loadMoreListener;
        this.mMoreResourceId = R.layout.listview_footer;
        this.mEmptyResourceId = R.layout.listview_empty;
        this.mProgressResourceId = R.layout.listview_loading;
    }

    @Override // android.support.v7.widget.RecyclerView.Adapter
    public final RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        if (i == -1) {
            return new RecyclerView.ViewHolder(this.mInflater.inflate(this.mMoreResourceId, viewGroup, false)) {
                /* class com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter.AnonymousClass1 */
            };
        }
        if (i == -3) {
            View inflate = this.mInflater.inflate(this.mEmptyResourceId, viewGroup, false);
            inflate.setMinimumHeight(viewGroup.getHeight());
            return new RecyclerView.ViewHolder(inflate) {
                /* class com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter.AnonymousClass2 */
            };
        } else if (i != -2) {
            return getViewHolder(viewGroup, i);
        } else {
            View inflate2 = this.mInflater.inflate(this.mProgressResourceId, viewGroup, false);
            inflate2.setMinimumHeight(viewGroup.getHeight());
            return new RecyclerView.ViewHolder(inflate2) {
                /* class com.thedaw.uiuians.util.InfiniteRecyclerViewAdapter.AnonymousClass3 */
            };
        }
    }

    @Override // android.support.v7.widget.RecyclerView.Adapter
    public final void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder.getItemViewType() == -1 || viewHolder.getItemViewType() == -3 || viewHolder.getItemViewType() == -2) {
            requestFullSpan(viewHolder);
        }
        if (!(viewHolder.getItemViewType() != -3 || this.emptyViewTitle == null || this.emptyViewSubTitle == null)) {
            ((TextView) viewHolder.itemView.findViewById(R.id.title)).setText(this.emptyViewTitle);
            ((TextView) viewHolder.itemView.findViewById(R.id.subtitle)).setText(this.emptyViewSubTitle);
        }
        if (!(viewHolder.getItemViewType() != -3 || this.emptyViewButtonTitle == null || this.emptyViewButtonListener == null)) {
            viewHolder.itemView.findViewById(R.id.cloud_footer).setVisibility(8);
            Button button = (Button) viewHolder.itemView.findViewById(R.id.empty_button);
            button.setVisibility(0);
            button.setText(this.emptyViewButtonTitle);
            button.setOnClickListener(this.emptyViewButtonListener);
        }
        if (viewHolder.getItemViewType() == -1) {
            if (this.mListener != null) {
                this.mListener.onMoreRequested();
            }
        } else if (this.mCurrentMode == 1) {
            doBindViewHolder(viewHolder, i);
        }
    }

    /* access modifiers changed from: protected */
    public void requestFullSpan(RecyclerView.ViewHolder viewHolder) {
        if (viewHolder.itemView.getLayoutParams() instanceof StaggeredGridLayoutManager.LayoutParams) {
            StaggeredGridLayoutManager.LayoutParams layoutParams = (StaggeredGridLayoutManager.LayoutParams) viewHolder.itemView.getLayoutParams();
            layoutParams.setFullSpan(true);
            viewHolder.itemView.setLayoutParams(layoutParams);
        }
    }

    @Override // android.support.v7.widget.RecyclerView.Adapter
    public final int getItemCount() {
        if (this.mCurrentMode == 2 || this.mCurrentMode == 3) {
            return 1;
        }
        if (this.mHasMore) {
            return getCount() + 1;
        }
        return getCount();
    }

    @Override // android.support.v7.widget.RecyclerView.Adapter
    public final int getItemViewType(int i) {
        if (this.mCurrentMode == 2) {
            return -3;
        }
        if (this.mCurrentMode == 3) {
            return -2;
        }
        if (i != getCount() || !this.mHasMore) {
            return getViewType(i);
        }
        return -1;
    }

    public void setModeAndNotify(int i) {
        this.mCurrentMode = i;
        notifyDataSetChanged();
    }

    public void setEmptyViewText(String str, String str2) {
        this.emptyViewSubTitle = str2;
        this.emptyViewTitle = str;
    }

    public void setEmptyViewButton(String str, View.OnClickListener onClickListener) {
        this.emptyViewButtonListener = onClickListener;
        this.emptyViewButtonTitle = str;
    }

    public void setHasMore(boolean z) {
        this.mHasMore = z;
    }
}

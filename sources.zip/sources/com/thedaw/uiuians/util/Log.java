package com.thedaw.uiuians.util;

public class Log {
    public static final boolean LOG = true;

    public static void i(String str, String str2) {
        android.util.Log.i(str, str2);
    }

    public static void e(String str, String str2) {
        android.util.Log.e(str, str2);
    }

    public static void e(String str, String str2, Exception exc) {
        android.util.Log.e(str, str2, exc);
    }

    public static void d(String str, String str2) {
        android.util.Log.d(str, str2);
    }

    public static void v(String str, String str2) {
        android.util.Log.v(str, str2);
    }

    public static void w(String str, String str2) {
        android.util.Log.w(str, str2);
    }

    public static void w(String str, String str2, Exception exc) {
        android.util.Log.w(str, str2, exc);
    }

    public static void printStackTrace(Exception exc) {
        exc.printStackTrace();
    }
}

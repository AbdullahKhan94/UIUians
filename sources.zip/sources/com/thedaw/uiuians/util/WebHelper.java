package com.thedaw.uiuians.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.preference.PreferenceManager;
import com.google.android.exoplayer2.text.ttml.TtmlNode;
import io.fabric.sdk.android.services.settings.SettingsJsonConstants;
import org.jsoup.nodes.Document;

public class WebHelper {
    @SuppressLint({"NewApi"})
    public static String docToBetterHTML(Document document, Context context) {
        try {
            document.select("img[src]").removeAttr(SettingsJsonConstants.ICON_WIDTH_KEY);
        } catch (Exception e) {
            Log.printStackTrace(e);
        }
        try {
            document.select("a[href]").removeAttr(TtmlNode.TAG_STYLE);
        } catch (Exception e2) {
            Log.printStackTrace(e2);
        }
        try {
            document.select(TtmlNode.TAG_DIV).removeAttr(TtmlNode.TAG_STYLE);
        } catch (Exception e3) {
            Log.printStackTrace(e3);
        }
        try {
            document.select("iframe").attr(SettingsJsonConstants.ICON_WIDTH_KEY, "100%");
        } catch (Exception e4) {
            Log.printStackTrace(e4);
        }
        String str = (Build.VERSION.SDK_INT < 17 || context.getResources().getConfiguration().getLayoutDirection() != 1) ? "" : "direction:RTL; unicode-bidi:embed;";
        document.head().append("<style>img{max-width: 100%; width: auto; height: auto;} p{max-width: 100%; width:auto; height: auto;}@font-face {font-family: 'Currents-Light-Sans';font-style: normal;font-weight: normal;src: local('sans-serif-light'), url('file:///android_asset/fonts/Roboto-Light.ttf') format('truetype');} body p {  font-family: 'Currents-Light-Sans', serif;} .list-inline {display: inline;list-style: none;} body {  max-width: 100% !important;font-family: 'Currents-Light-Sans', serif;margin: 0;padding: 0;" + str + "}</style>");
        return document.toString();
    }

    public static int getWebViewFontSize(Context context) {
        return Integer.parseInt(PreferenceManager.getDefaultSharedPreferences(context).getString(TtmlNode.ATTR_TTS_FONT_SIZE, "16"));
    }

    public static int getTextViewFontSize(Context context) {
        int parseInt = Integer.parseInt(PreferenceManager.getDefaultSharedPreferences(context).getString(TtmlNode.ATTR_TTS_FONT_SIZE, "16"));
        if (parseInt >= 16) {
            return parseInt - 2;
        }
        if (parseInt == 7) {
            return parseInt + 1;
        }
        return parseInt < 16 ? parseInt - 1 : parseInt;
    }
}

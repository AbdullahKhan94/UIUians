package com.thedaw.uiuians.util;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.thedaw.uiuians.R;

public class CustomScrollingViewBehavior extends AppBarLayout.ScrollingViewBehavior implements View.OnLayoutChangeListener {
    private static final int SCROLL_DIRECTION_UP = -1;
    private View appBarLayout;
    private boolean dynamicElevation;
    private boolean isElevated;

    public CustomScrollingViewBehavior() {
    }

    public CustomScrollingViewBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override // android.support.design.widget.AppBarLayout.ScrollingViewBehavior, android.support.design.widget.CoordinatorLayout.Behavior
    public boolean layoutDependsOn(CoordinatorLayout coordinatorLayout, View view, View view2) {
        coordinatorLayout.addOnLayoutChangeListener(this);
        if (view2 instanceof AppBarLayout) {
            this.appBarLayout = view2;
        }
        return super.layoutDependsOn(coordinatorLayout, view, view2);
    }

    @Override // android.support.design.widget.CoordinatorLayout.Behavior
    public boolean onStartNestedScroll(@NonNull CoordinatorLayout coordinatorLayout, @NonNull View view, @NonNull View view2, @NonNull View view3, int i, int i2) {
        return i == 2 || super.onStartNestedScroll(coordinatorLayout, view, view2, view3, i, i2);
    }

    @Override // android.support.design.widget.CoordinatorLayout.Behavior
    public void onNestedPreScroll(@NonNull CoordinatorLayout coordinatorLayout, @NonNull View view, @NonNull View view2, int i, int i2, @NonNull int[] iArr, int i3) {
        View view3 = view2;
        if (this.dynamicElevation) {
            if (view3 instanceof SwipeRefreshLayout) {
                SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) view3;
                if (swipeRefreshLayout.getChildCount() > 0 && (swipeRefreshLayout.getChildAt(0) instanceof RecyclerView)) {
                    view3 = swipeRefreshLayout.getChildAt(0);
                }
            }
            if (view3 instanceof RecyclerView) {
                if (!((RecyclerView) view3).canScrollVertically(-1)) {
                    if (this.isElevated && ((ViewGroup) view.getParent()) != null) {
                        setElevated(false, view.getContext());
                    }
                    this.isElevated = false;
                } else {
                    if (!this.isElevated && ((ViewGroup) view.getParent()) != null) {
                        setElevated(true, view.getContext());
                    }
                    this.isElevated = true;
                }
            }
        }
        super.onNestedPreScroll(coordinatorLayout, view, view3, i, i2, iArr, i3);
    }

    public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        if (this.dynamicElevation) {
            setElevated(false, view.getContext());
            this.isElevated = false;
            return;
        }
        setElevated(true, view.getContext());
        this.isElevated = true;
    }

    private void setElevated(boolean z, Context context) {
        if (this.appBarLayout != null) {
            ViewCompat.setElevation(this.appBarLayout, z ? toolbarElevation(context) : 0.0f);
        }
    }

    public void setDynamicElevation(boolean z) {
        this.dynamicElevation = z;
    }

    private static float toolbarElevation(Context context) {
        return context.getResources().getDimension(R.dimen.toolbar_elevation);
    }
}

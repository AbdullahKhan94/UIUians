package com.thedaw.uiuians;

import android.content.Intent;
import android.support.multidex.MultiDexApplication;
import android.text.TextUtils;
import com.crashlytics.android.Crashlytics;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.onesignal.OSNotificationOpenResult;
import com.onesignal.OneSignal;
import io.fabric.sdk.android.Fabric;
import org.json.JSONObject;

public class App extends MultiDexApplication {
    public void onCreate() {
        super.onCreate();
        Fabric.with(this, new Crashlytics());
        FirebaseApp.initializeApp(this, new FirebaseOptions.Builder().setApiKey("<VAL>").setApplicationId("<VAL>").build());
        if (!TextUtils.isEmpty(getString(R.string.onesignal_app_id))) {
            OneSignal.init(this, getString(R.string.onesignal_google_project_number), getString(R.string.onesignal_app_id), new NotificationHandler());
        }
    }

    private class NotificationHandler implements OneSignal.NotificationOpenedHandler {
        private NotificationHandler() {
        }

        @Override // com.onesignal.OneSignal.NotificationOpenedHandler
        public void notificationOpened(OSNotificationOpenResult oSNotificationOpenResult) {
            try {
                JSONObject jSONObject = oSNotificationOpenResult.notification.payload.additionalData;
                String str = null;
                if (jSONObject != null) {
                    str = jSONObject.optString("url", null);
                }
                String str2 = oSNotificationOpenResult.notification.payload.launchURL;
                if (str == null) {
                    if (str2 == null) {
                        if (!oSNotificationOpenResult.notification.isAppInFocus) {
                            Intent intent = new Intent(App.this, MainActivity.class);
                            intent.addFlags(268566528);
                            App.this.startActivity(intent);
                            return;
                        }
                        return;
                    }
                }
                if (str != null) {
                    HolderActivity.startWebViewActivity(App.this, str, false, false, null, 268566528);
                } else {
                    HolderActivity.startWebViewActivity(App.this, str2, true, false, null, 268566528);
                }
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
    }
}
